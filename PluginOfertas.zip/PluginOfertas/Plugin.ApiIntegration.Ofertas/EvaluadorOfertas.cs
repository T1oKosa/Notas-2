﻿extern alias GComponents;

using GComponents::Axxon.GlobalComponents;
using GComponents::Axxon.GlobalComponents.Configuraciones;
using GComponents::Axxon.GlobalComponents.Helper;
using GComponents::Axxon.GlobalComponents.Model;
using Microsoft.Xrm.Sdk;
using Org.BouncyCastle.Security.Certificates;
using Plugin.ApiIntegration.Ofertas.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Runtime.Remoting.Contexts;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Threading.Tasks;
using System.Web;

namespace Plugin.ApiIntegration.Ofertas
{
    public class EvaluadorOfertas : PluginApiIntegrationBase
    {
        private PluginContext ctx;
        #region Secure/Unsecure Configuration Setup
        private string _secureConfig = null;
        private string _unsecureConfig = null;
        private object configuraciones;
        public EvaluadorOfertas(string unsecureConfig, string secureConfig)
        {
            _secureConfig = secureConfig;
            _unsecureConfig = unsecureConfig;
        }
        public EvaluadorOfertas()
        {

        }
        #endregion
        public override WebHeaderCollection GetHeader(PluginContext ctx)
        {
            this.ctx = ctx;
            ctx.Trace("WebHeaderCollection");
            WebHeaderCollection wh = new WebHeaderCollection();
            string _nombreservicio = ctx.Context.InputParameters["Api_ApiIntegration_Ofertas_Evaluador_In_Configuracion"].ToString();
            string json_input = ctx.Context.InputParameters["json"].ToString();
            ctx.Trace($"json: {json_input}");
            string clienteid = ctx.Context.InputParameters["idcliente"].ToString();
            switch (_nombreservicio)
            {
                case "Ofertas AE":
                    break;
                case "Ofertas SAE":
                    GComponents::Axxon.GlobalComponents.Model.Oferta selecionada_sae = JsonSerializer.Deserialize<GComponents::Axxon.GlobalComponents.Model.Oferta>(json_input);
                    wh.Add("id-cliente", clienteid);
                    wh.Add("id-oferta", selecionada_sae.id_oferta.ToString());
                    wh.Add("id-cuenta", selecionada_sae.id_activo);
                    wh.Add("monto", selecionada_sae.monto.valor.ToString());
                    break;
                case "Ofertas tarjeta":
                    GComponents::Axxon.GlobalComponents.Model.Oferta selecionada_ot = JsonSerializer.Deserialize<GComponents::Axxon.GlobalComponents.Model.Oferta>(json_input);
                    wh.Add("id-cliente", clienteid);
                    wh.Add("id-oferta", selecionada_ot.id_oferta);
                    wh.Add("monto", selecionada_ot.monto.valor.ToString());
                    break;
                case "Ofertas Traspaso":
                    break;
                case "Ofertas aumento cupo":
                    GComponents::Axxon.GlobalComponents.Model.Oferta selecionada = JsonSerializer.Deserialize<GComponents::Axxon.GlobalComponents.Model.Oferta>(json_input);
                    wh.Add("id-oferta", selecionada.id_oferta);
                    wh.Add("processor", "tsys");

                    break;
                case "UrlOfertasComplementarias":
                    break;
            }
            return wh;
        }
        public override ConfiguracionServicio GetServicio(PluginContext ctx, ConfiguracionesServicios configuraciones)
        {
            ctx.Trace("ConfiguracionServicio");
            string _nombreservicio = ctx.Context.InputParameters["Api_ApiIntegration_Ofertas_Evaluador_In_Configuracion"].ToString();
            ConfiguracionServicio config = new ConfiguracionServicio(new Entity());
            switch (_nombreservicio)
            {
                case "Ofertas AE":
                    break;
                case "Ofertas SAE":
                    config = configuraciones.OMDMSAE;
                    break;
                case "Ofertas tarjeta":
                    config = configuraciones.OMDMTarjeta;
                    break;
                case "Ofertas Traspaso":
                    break;
                case "Ofertas aumento cupo":
                    config = configuraciones.OMDMAumentoCupo;
                    break;
                case "UrlOfertasComplementarias":
                    break;
            }
            return config;
        }
        public override String ProcesarJson(PluginContext ctx, String json)
        {
            ctx.Trace("ProcesarJson");
            ResponseEvaluacion response = new ResponseEvaluacion();
            response.id_card = ctx.Context.InputParameters["idcard"].ToString();
            string _nombreservicio = ctx.Context.InputParameters["Api_ApiIntegration_Ofertas_Evaluador_In_Configuracion"].ToString();
            try
            {
                switch (_nombreservicio)
                {
                    case "Ofertas AE":
                        break;
                    case "Ofertas SAE":
                        EOSAE _omdmsae = JsonSerializer.Deserialize<EOSAE>(json);
                        if (_omdmsae != null)
                        {
                            switch (_omdmsae?.data?.estado?.estado)
                            {
                                case "INICIADO":
                                    ctx.Trace("INICIADO");
                                    response.estado = "RECHAZADO";
                                    response.mensaje = "No responde OMDM";
                                    break;

                                case "APROBADA":
                                    ctx.Trace("APROBADA");
                                    response.estado = "APROBADO";
                                    response.mensaje = _omdmsae.data.estado.mensaje;
                                    response.id_autorizacion = _omdmsae.data.id;
                                    break;
                                case "APROBADO":
                                    ctx.Trace("APROBADO");
                                    response.estado = "APROBADO";
                                    response.mensaje = _omdmsae.data.estado.mensaje;
                                    response.id_autorizacion = _omdmsae.data.id;
                                    break;
                                case "RECHAZADO":
                                    ctx.Trace("RECHAZADO");
                                    response.estado = "RECHAZADO";
                                    List<RechazoOMDM> rechazos = _omdmsae.data.estado.rechazo_omdm;
                                    response.mensaje = rechazos.Count > 0 ? OMDMHelper.DescripcionOMDMSAE(rechazos) 
                                                        : (!string.IsNullOrEmpty(_omdmsae.data.estado.mensaje) ? _omdmsae.data.estado.mensaje : "sin información");

                                    break;
                            }
                        }
                        break;
                    case "Ofertas tarjeta":
                        ctx.Trace("contiene ofertas tarjetas");
                        EOTarjetas _omdmtarjeta = JsonSerializer.Deserialize<EOTarjetas>(json);
                        switch (_omdmtarjeta.data.estado.despcripcion)
                        {
                            case "INICIADO":
                                response.estado = "RECHAZADO";
                                response.mensaje = "No responde OMDM";
                                break;
                            case "APROBADO":
                                response.estado = "APROBADO";
                                response.mensaje = _omdmtarjeta.data.estado.despcripcion;
                                response.id_autorizacion = _omdmtarjeta.data.id_token;
                                break;
                            case "APROBADA":
                                response.estado = "APROBADO";
                                response.mensaje = _omdmtarjeta.data.estado.despcripcion;
                                response.id_autorizacion = _omdmtarjeta.data.id_token;
                                break;
                            case "RECHAZADA":
                                response.estado = "RECHAZADA";
                                //if (_omdmtarjeta.data.estado.rechazos.Where(x => x.rechazo_blando.HasValue && x.rechazo_blando.Value).FirstOrDefault() != null && _omdmtarjeta.data.estado.rechazos.Where(x => x.rechazo_blando.HasValue && !x.rechazo_blando.Value).FirstOrDefault() == null)
                                if(_omdmtarjeta.data.estado.rechazos.Count == 1 && _omdmtarjeta.data.estado.rechazos.Exists(x => x.codigo.Equals("CM")))
                                {
                                    response.estado = "RBLANDO";
                                    response.mensaje = _omdmtarjeta.data.estado.despcripcion;
                                    response.codigo_rblando = !string.IsNullOrEmpty(_omdmtarjeta.data.estado.rechazos[0].codigo) ? _omdmtarjeta.data.estado.rechazos[0].codigo : "";
                                }
                                else
                                {
                                    string rechazos = string.Join(" ", _omdmtarjeta.data.estado.rechazos.Select(x => x.mensaje).ToArray());
                                    ctx.Trace("pase por aca");
                                    if (_omdmtarjeta.data.estado.rechazos.Where(x => x.codigo != null && x.codigo.Equals("122")).FirstOrDefault() != null)
                                    {
                                        response.mensaje = "Faltan datos mínimos que son requeridos para la evaluación";
                                    }
                                    else
                                    {
                                        ctx.Trace("pase por aca2");
                                        response.mensaje = !string.IsNullOrEmpty(rechazos) ? rechazos : "sin información";

                                    }
                                }
                                break;
                        }
                        break;
                    case "Ofertas Traspaso":
                        break;
                    case "Ofertas aumento cupo":
                        ctx.Trace($"json: {json}");
                        ResponseEOTarjetas responseEOTarjetas = JsonSerializer.Deserialize<ResponseEOTarjetas>(json);
                        ctx.Trace($"ofertas-aumento-cupo  - responseEOTarjetas: {JsonSerializer.Serialize(responseEOTarjetas)}");
                        ctx.Trace($"ofertas-aumento-cupo  - id: {responseEOTarjetas.id}");
                        ctx.Trace($"ofertas-aumento-cupo  - data: {JsonSerializer.Serialize(responseEOTarjetas.data)}");
                        ctx.Trace($"ofertas-aumento-cupo  - estado: {JsonSerializer.Serialize(responseEOTarjetas.data.estado)}");
                        ctx.Trace($"ofertas-aumento-cupo  - despcripcion: {responseEOTarjetas.data.estado.descripcion}");
                        switch (responseEOTarjetas.data.estado.descripcion)
                        {
                            case "APPROVE_STARTED":
                                response.estado = "RECHAZADA";
                                response.mensaje = "No responde OMDM";
                                break;
                            case "APPROVE":
                                response.estado = "APROBADO";
                                response.mensaje = responseEOTarjetas.data.estado.descripcion;
                                break;
                            case "READY_TO_CURSE":
                                response.estado = "APROBADO";
                                response.mensaje = responseEOTarjetas.data.estado.descripcion;
                                break;
                            case "APPROVE_ERROR":
                                response.estado = "RECHAZADA";
                                string rechazo = string.Join(" ", responseEOTarjetas.data.estado.rechazos.Select(x => x.mensaje).ToArray());
                                response.mensaje = !string.IsNullOrEmpty(rechazo) ? rechazo : "sin información";
                                break;
                            case "OFFER_REJECTED":
                                response.estado = "RECHAZADA";
                                response.mensaje = responseEOTarjetas.data.estado.rechazos[0].mensaje;
                                break;
                        }
                        break;
                    case "UrlOfertasComplementarias":
                        break;
                }
            }
            catch (Exception ex)
            {
                ctx.Trace($"Error: {ex.Message}");
            }
            try
            {
                var evaluaresponse = JsonSerializer.Serialize<ResponseEvaluacion>(response);
                ctx.Trace($"json serializado: {evaluaresponse}");
            }
            catch (Exception ex)
            {
                ctx.Trace($"error serializa: {ex.Message}");
            }


            return JsonSerializer.Serialize<ResponseEvaluacion>(response);
        }
        public override string GetHttpMethod()
        {
            string method = "GET";
            string _nombreservicio = this.ctx.Context.InputParameters["Api_ApiIntegration_Ofertas_Evaluador_In_Configuracion"].ToString();
            switch (_nombreservicio)
            {
                case "Ofertas AE":
                    break;
                case "Ofertas SAE":
                    break;
                case "Ofertas tarjeta":
                    break;
                case "Ofertas Traspaso":
                    break;
                case "Ofertas aumento cupo":
                    method = "POST";
                    break;
                case "UrlOfertasComplementarias":
                    break;
            }
            return method;
        }
        public override bool ValidarSesion()
        {
            return false;
        }
        public override string GetDato(PluginContext ctx)
        {
            ctx.Trace("Get Dato");
            string json_input = ctx.Context.InputParameters["json"].ToString();
            string _nombreservicio = ctx.Context.InputParameters["Api_ApiIntegration_Ofertas_Evaluador_In_Configuracion"].ToString();
            string _body = string.Empty;
            switch (_nombreservicio)
            {
                case "Ofertas AE":
                    break;
                case "Ofertas SAE":
                    break;
                case "Ofertas tarjeta":
                    break;
                case "Ofertas Traspaso":
                    break;
                case "Ofertas aumento cupo":
                    GComponents::Axxon.GlobalComponents.Model.Oferta selecionada = JsonSerializer.Deserialize<GComponents::Axxon.GlobalComponents.Model.Oferta>(json_input);
                    ctx.Trace("model ok!");
                    OMDMAC aumentocupo = new OMDMAC()
                    {
                        id_cuenta = int.Parse(selecionada.id_cuenta),
                        cod_canal = int.Parse(selecionada.id_canal),
                        id_logo = int.Parse(selecionada.id_logo),
                        id_cliente = int.Parse(selecionada.id_cliente),
                        monto = (decimal)selecionada.cupo_total_cuenta.valor
                    };
                    _body = JsonSerializer.Serialize<OMDMAC>(aumentocupo);
                    ctx.Trace("body");
                    ctx.Trace(_body);
                    break;
                case "UrlOfertasComplementarias":
                    break;
            }
            return _body;
        }

    }
}