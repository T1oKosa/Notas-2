﻿extern alias GComponents;

using GComponents::Axxon.GlobalComponents;
using GComponents::Axxon.GlobalComponents.Helper;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Plugin.ApiIntegration.Ofertas.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plugin.ApiIntegration.Ofertas
{
    public class RutasOfertas : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            #region Base context
            // Obtain the tracing service
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            // Obtain the execution context from the service provider.  
            IPluginExecutionContext context = (IPluginExecutionContext)
                serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = factory.CreateOrganizationService(context.UserId);
            PluginContext ctx = new PluginContext(serviceProvider);

            
            #endregion

            try
            {
                ctx.Trace("1");
                ConfiguracionesServicios configuraciones = new ConfiguracionesServicios(ctx.IntegrationUserService, ctx.TracingService.TracingService, ctx.Context.OrganizationName);
                ctx.Trace("2");
                var listaConfiguraciones = configuraciones.ServiciosOfertador;

                List<Producto> listaProductos = new List<Producto>();
                if (listaConfiguraciones.Any())
                {

                    foreach (var item in listaConfiguraciones)
                    {
                        ctx.Trace($"Producto {item.Producto.Name} con url {item.UrlInterna}");
                        listaProductos.Add(new Producto()
                        {
                            Id = item.Producto.Id.ToString(),
                            Nombre = item.Producto.Name,
                            URL = item.UrlInterna,
                            ER = (item.configEvaluador != null) ? item.configEvaluador.Value.ToString() : string.Empty,
                            Orden = item.Orden.Value,
                            Configuracion = item.Servicio,
                            CompraDatos = item.CompraDatos
                        });
                    }
                }
                context.OutputParameters["Response"] = JsonSerializer.Serialize<List<Producto>>(listaProductos);  
            }
            catch (Exception ex)
            {
                tracingService.Trace("Rutas de las Ofertas/Productos: {0}", ex.ToString());
                context.OutputParameters["Error"] = $"Error rutas de ofertas - ${ex.Message}"; //new string(input.Reverse().ToArray());
            }

        }
    }
}