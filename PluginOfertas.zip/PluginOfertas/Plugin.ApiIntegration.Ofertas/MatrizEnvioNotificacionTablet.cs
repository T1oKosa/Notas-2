﻿extern alias GComponents;

using GComponents::Axxon.GlobalComponents.Helper;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Plugin.ApiIntegration.Ofertas.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Remoting.Contexts;

namespace Plugin.ApiIntegration.Ofertas
{
    public class MatrizEnvioNotificacionTablet : IPlugin
    {
        public async void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracer = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = factory.CreateOrganizationService(context.UserId);
            PluginContext ctx = new PluginContext(serviceProvider);
            var IdNotificacionPos = (String)context.InputParameters["IdNotificacionPos"];
            var IdProducto = (String)context.InputParameters["IdProducto"];
            var IdCaja = (String)context.InputParameters["IdCaja"];
            var Mensaje = (String)context.InputParameters["Mensaje"];

            try
            {
                EntityCollection usuariosEncontrados = buscarUsuariosCaja(IdCaja, ctx);
                string nombreConfig = "Url-Flow-EnvioNotificacion-Captadores";
                string urlServicio = buscaConfiguracion(nombreConfig, ctx);
                if (usuariosEncontrados.Entities.Count > 0)
                {
                    foreach (Entity usuarios in usuariosEncontrados.Entities)
                    {
                        ctx.Trace("foreach usuarios: " + usuarios["domainname"].ToString());
                        EnvioNotificacionPA(Mensaje, IdNotificacionPos, usuarios["domainname"].ToString(), ctx, urlServicio);
                    }
                    ctx.Context.OutputParameters["Response"] = "fin llamado asincrono flow notificaciones";
                }
            }
            catch (Exception e)
            {
                ctx.Context.OutputParameters["Error"] = e.Message;
            }



        }
        public async Task EnvioNotificacionPA(string mensaje, string notificacionid, string correoDestino, PluginContext ctx, string urlServicio)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(urlServicio);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                ctx.Trace("EnvioNotificacionPA");
                HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, client.BaseAddress);
                var body = $"{{\"mensaje\": \"{mensaje}\",\"idNotificacion\":\"{notificacionid}\",\"correodestinatario\":\"{correoDestino}\"}}";
                var content = new StringContent(body, Encoding.UTF8, "application/json");
                request.Content = content;
                ctx.Trace("EnvioNotificacionPA content: " + body.ToString());
                var response = await EnvioFlowNotificacion(request, client, ctx);
                ctx.Trace("EnvioNotificacionPA - response: " + response);
                ctx.Context.OutputParameters["Response"] = response;
            }
            catch (Exception e)
            {
                ctx.Context.OutputParameters["Error"] = e.Message;
                ctx.Trace("Error: " + e.Message);
            }
        }
        public async Task<string> EnvioFlowNotificacion(HttpRequestMessage getRequest, HttpClient client, PluginContext ctx)
        {
            var response = await client.SendAsync(getRequest).ConfigureAwait(false);
            var responseString = string.Empty;
            try
            {
                ctx.Trace("Llama Flow Envio");
                response.EnsureSuccessStatusCode();
                responseString = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                ctx.Trace("EnvioFlowNotificacion - responseString : " + responseString);
            }
            catch (HttpRequestException e)
            {
                ctx.Trace("Error: " + e.Message);
            }

            return responseString;
        }

        public string buscaConfiguracion(string nombreConfig, PluginContext ctx)
        {
            EntityCollection configuracion;
            string urlConfig = "";
            var query = new QueryExpression("mcs_configuracionservicio");
            query.ColumnSet.AddColumn("mcs_urlservicio");
            query.Criteria.AddCondition("mcs_nombreconfiguracion", ConditionOperator.Equal, nombreConfig);
            configuracion = ctx.Service.RetrieveMultiple(query);
            try
            {
                if (configuracion.Entities.Count > 0)
                    urlConfig = configuracion.Entities[0].Attributes["mcs_urlservicio"].ToString();
            }
            catch (Exception e)
            {
                ctx.Trace("error buscar configuracion: " + e.Message);
            }
            return urlConfig;
        }

        public EntityCollection buscarUsuariosCaja(string idCaja, PluginContext ctx)
        {
            EntityCollection UsuariosCaja;
            var query_isdisabled = false;
            var query = new QueryExpression("systemuser");
            query.ColumnSet.AddColumns(
                "businessunitid",
                "title",
                "address1_telephone1",
                "positionid",
                "systemuserid",
                "domainname",
                "fullname",
                "mcs_rut");
            query.Criteria.AddCondition("isdisabled", ConditionOperator.Equal, query_isdisabled);
            query.AddOrder("fullname", OrderType.Descending);
            var ah = query.AddLink("mcs_sucursal", "mcs_sucursalid", "mcs_sucursalid");
            ah.EntityAlias = "ah";

            var ai = ah.AddLink("axx_cajapos", "mcs_sucursalid", "axx_sucursal");
            ai.EntityAlias = "ai";

            ai.LinkCriteria.AddCondition("axx_cajaposid", ConditionOperator.Equal, idCaja);

            UsuariosCaja = ctx.Service.RetrieveMultiple(query);
            return UsuariosCaja;
        }
    }
}
