# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Qué es
Assembly de plugins para Dataverse / Dynamics 365 (.NET Framework 4.7.1, firmado con `Plugin.ApiIntegration.Ofertas.snk`). No es una API: no se ejecuta localmente y no tiene tests. Se valida compilando localmente y publicando el plugin con XrmToolBox, revisando luego el Plugin Trace Log.

## Build
- `dotnet build Plugin.ApiIntegration.Ofertas.csproj`
- Requiere acceso a los feeds privados de Azure Artifacts de `nuget.config` (paquete `Apolo.GlobalComponents`). Si falla el restore, es un problema de autenticación, no del código.
- No cambiar el `.snk` ni la identidad del assembly: rompe el registro existente en Dataverse.

## Git / despliegue
- Ramas `fb/APOLO-<n>` creadas desde `develop`; PR a `develop` en Azure DevOps (no GitHub; `gh` no aplica).
- **Nunca hacer `git push` sin que el usuario lo pida explícitamente**: `pipeline.yaml` despliega a Dev en cada push a `develop` y `fb/*`.
- Mensajes de commit en español, en minúscula, descriptivos ("se agrega …", "correcciones …").

## Convenciones de código
- Todo en español: nombres de clases/métodos, trazas, mensajes de error y comentarios.
- Todo archivo que use GlobalComponents debe empezar con `extern alias GComponents;` y referenciar tipos como `GComponents::Axxon.GlobalComponents...`.
- Plugins de integración HTTP heredan de `PluginApiIntegrationBase` (GlobalComponents) y sobrescriben `GetServicio`, `GetDato`, `GetHttpMethod`, `GetHeader`, `EjecutarValidaciones`, `ValidarSesion`. Mantener constructor `(unsecureConfig, secureConfig)`.
- Errores: capturar y escribir el mensaje en `OutputParameters["Error"]`; `InvalidPluginExecutionException` solo para validaciones. Respuesta en `OutputParameters["Response"]`.
- Trazas con `ctx.Trace(...)` / `TracingService.Trace(...)`, siguiendo el estilo detallado existente.
- Parámetros Custom API con el formato `Api_ApiIntegration_Ofertas_<Clase>_In_<Nombre>`.
- Configuración (URLs, endpoints) se lee de Dataverse (`ConfiguracionesServicios`) o de la config del step; no hay appsettings. No hardcodear URLs ni API keys (el `apikey` existente en `PlantillaProducto.cs` es deuda, no un patrón a copiar).
- Prefijo de publisher en entidades/campos: `axx_`.
