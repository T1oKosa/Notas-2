---
name: verificar-build
description: Compila el plugin con dotnet build y resume errores/warnings. Usar después de modificar archivos .cs o .csproj, o cuando el usuario pida verificar que compila.
---

1. Ejecuta `dotnet build Plugin.ApiIntegration.Ofertas.csproj -nologo -v q` desde la raíz del repo.
2. Si falla el restore (NU1301, 401, feed de Azure Artifacts): informa que es un problema de autenticación con los feeds privados de `nuget.config`, no del código, y detente.
3. Si hay errores de compilación: agrúpalos por archivo con `archivo:línea`, mensaje y causa probable. Revisa en especial si falta `extern alias GComponents;` cuando aparecen errores de tipos de `Axxon.GlobalComponents`.
4. Lista solo los warnings nuevos en archivos modificados (`git diff --name-only develop...HEAD` + cambios sin commitear); no listes los warnings preexistentes del resto del proyecto.
5. Termina con una línea: compila OK / falla, y qué falta. No hagas push ni publiques.
