﻿extern alias GComponents;

using GComponents::Axxon.GlobalComponents.Helper;
using Plugin.ApiIntegration.Ofertas.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plugin.ApiIntegration.Ofertas.Contract
{
    public interface IPlantillaProducto
    {
        List<Plantilla> GetProducto(Producto producto, PluginContext ctx);
    }
}
