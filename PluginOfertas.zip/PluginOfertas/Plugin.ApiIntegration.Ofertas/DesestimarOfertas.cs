﻿extern alias GComponents;

using GComponents::Axxon.GlobalComponents;
using Microsoft.Xrm.Sdk;
using System;
using GComponents::Axxon.GlobalComponents.Helper;
using GComponents::Axxon.GlobalComponents.Configuraciones;
using System.Text;

namespace Plugin.ApiIntegration.Ofertas
{

    public class DesestimarOfertas : PluginApiIntegrationBase
    {
        #region Secure/Unsecure Configuration Setup
  

        public DesestimarOfertas(string unsecureConfig, string secureConfig) : base(unsecureConfig, secureConfig)
        {
           
        }

        public DesestimarOfertas()
        { 
        }
        #endregion

        public override ConfiguracionServicio GetServicio(PluginContext ctx, ConfiguracionesServicios configuraciones)
        {
            var cliente = ctx.CachedEntities.GetClient(((EntityReference)ctx.Context.InputParameters["Target"]).Id);
            var config = configuraciones.ServicioDesestimarOferta;
            config.Url = config.Url.Replace("{numero_documento}", cliente.NumeroIdentificacion.Replace(".", "").Replace("-", ""));
            config.Url = config.Url.Replace("{tipo_documento}", cliente.TipoDoc.Codigo);
            config.Url = config.Url.Replace("{pais}", cliente.Pais.Codigo);
            config.Url = config.Url.Replace("{id_oferta}", ctx.Context.InputParameters["IdOferta"].ToString());
            return config;
        }

        public override String GetDato(PluginContext ctx)
        {
            var body = "{\"codigo\": \"" + ctx.Context.InputParameters["Motivo"].ToString() + "\"}";
            return body;
        }
        public override string GetHttpMethod()
        {
            return "POST";
        }

        
    }
}