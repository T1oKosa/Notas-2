﻿extern alias GComponents;

using GComponents::Axxon.GlobalComponents;
using Microsoft.Xrm.Sdk;
using System;
using GComponents::Axxon.GlobalComponents.Helper;
using GComponents::Axxon.GlobalComponents.Configuraciones;
using System.Text;
using GComponents::Axxon.GlobalComponents.Model.Sesion;

namespace Plugin.ApiIntegration.Ofertas
{

    public class ConsultaOfertasComplementarias : PluginApiIntegrationBase
    {
        #region Secure/Unsecure Configuration Setup
  

        public ConsultaOfertasComplementarias(string unsecureConfig, string secureConfig) : base(unsecureConfig, secureConfig)
        {
           
        }

        public ConsultaOfertasComplementarias()
        { 
        }
        #endregion

        public override ConfiguracionServicio GetServicio(PluginContext ctx, ConfiguracionesServicios configuraciones)
        {
            var cliente = ctx.CachedEntities.GetClient(((EntityReference)ctx.Context.InputParameters["Target"]).Id);
            var config = configuraciones.ServicioObtenerOfertasComplementarias;
            config.Url = config.Url.Replace("{numero_documento}", cliente.IdCliente);
            config.Url = config.Url.Replace("{tipo_documento}", cliente.TipoDoc.Codigo);
            config.Url = config.Url.Replace("{pais}", cliente.Pais.Codigo);          
            return config;
        }

        public override String GetDato(PluginContext ctx)
        {
           return base.GetDato(ctx);
        }
        public override string GetHttpMethod()
        {
            return "GET";
        }

        public override string EjecutarValidaciones(PluginContext ctx, Sesion sesion)
        {
            String msg = null;
            var ejecutivo = ctx.CachedEntities.GetUser(ctx.Context.InitiatingUserId);
            var cliente = ctx.CachedEntities.GetClient(((EntityReference)ctx.Context.InputParameters["Target"]).Id);
            if (cliente.Permanencia == null
               || cliente.Nacionalidad == null
               || cliente.FechaNacimiento.Year <= 1753 || ejecutivo.RolPrimario == null)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("No cuenta con los datos mínimos para ver ofertas: ");
                sb.Append(cliente.Permanencia == null ? "Permanencia, " : "");
                sb.Append(cliente.Nacionalidad == null ? "Nacionalidad, " : "");
                sb.Append(cliente.FechaNacimiento.Year <= 1753 ? "Fecha de nacimiento, " : "");
                sb.Append(ejecutivo.RolPrimario == null ? "Rol principal, " : "");
                msg = sb.ToString();
                msg = msg.Substring(0, msg.Length - 2);
            }
            return msg;
        }
    }
}