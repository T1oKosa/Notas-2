﻿using System;
using System.Collections.Generic;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class ContenidoActivo
    {
        public int id { get; set; }
        public string descripcion { get; set; }
        public string numero_cuenta { get; set; }
        public string imagen_activo { get; set; }
        public int cupo_actual { get; set; }
    }

    public class ActivosResponse
    {
        public object errores { get; set; }
        public int maximo { get; set; }
        public int pagina { get; set; }
        public int cantidad_elementos { get; set; }
        public List<ContenidoActivo> contenido { get; set; }
        public int cantidad_paginas { get; set; }
        public object estado_preventivo { get; set; }
    }
}
