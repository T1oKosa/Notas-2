﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class Reemision
    {
        /// <summary>
        /// Codigo de Pickup
        /// </summary>
        public int Motivo { get; set; }

        /// <summary>
        /// Id
        /// </summary>
        public string NumeroSolicitud { get; set; }

        /// <summary>
        /// Estado reemision
        /// </summary>
        public int ReemisionEstado { get; set; }

        /// <summary>
        /// Nro de tarjeta a reemitir
        /// </summary>
        public string NumeroTarjetaAnterior { get; set; }

        /// <summary>
        /// Codigo de Pickup
        /// </summary>
        public Guid Ejecutivo { get; set; }

        /// <summary>
        /// Codigo de Pickup
        /// </summary>
        public Guid SolicitanteReemision { get; set; }


        public Guid IdCrm { get; set; }

        //"nombre_cliente": "string",
        /// <summary>
        /// nombre_cliente
        /// </summary>
        public string Nombre_cliente { get; set; }
        //"rut_cliente": "string",
        /// <summary>
        /// rut_cliente
        /// </summary>
        public string RutCliente { get; set; }
        //"tipo_cliente": "string",
        /// <summary>
        /// tipo_cliente
        /// </summary>
        public string TipoCliente { get; set; }
        /// <summary>
        /// "PuntosCenco": "bool",
        /// </summary>
        public string PuntosCenco { get; set; }
        //"nombre_titular": "string",
        /// <summary>
        /// nombre_titular
        /// </summary>
        public string NombreTitular { get; set; }
        //"id_cuenta": "string",
        /// <summary>
        /// id_cuenta
        /// </summary>
        public string IdCuenta { get; set; }
        //"nro_cuenta": "string",
        /// <summary>
        /// nro_cuenta
        /// </summary>
        public string NroCuenta { get; set; }
        //"id_tarjeta": "string",
        /// <summary>
        /// id_tarjeta
        /// </summary>
        public string IdTarjeta { get; set; }
        //"nro_tarjeta": "string",
        /// <summary>
        /// nro_tarjeta
        /// </summary>
        public string NroTarjeta { get; set; }
        //"logo": "string",
        /// <summary>
        /// logo
        /// </summary>
        public string Logo { get; set; }
        //"fecha_emision": "string",
        /// <summary>
        /// fecha_emision
        /// </summary>
        public string FechaEmision { get; set; }

        /// <summary>
        /// nombre_cliente
        /// </summary>
        public string Nombre_embozado { get; set; }

        /// <summary>
        /// nombre_cliente
        /// </summary>
        public string Apellido_embozado { get; set; }
        //"fecha_activacion": "string",
        /// <summary>
        /// fecha_activacion
        /// </summary>
        public string FechaActivacion { get; set; }
        //"codigo_bloqueo": "string",
        /// <summary>
        /// codigo_bloqueo
        /// </summary>
        public string CodigoBloqueo { get; set; }
        //"bloqueo": "string",
        /// <summary>
        /// bloqueo
        /// </summary>        
        public string Bloqueo { get; set; }
        //"fecha_bloqueo": "string"
        /// <summary>
        /// fecha_bloqueo
        /// </summary>
        public string FechaBloqueo { get; set; }

        /// <summary>
        /// Indica si puede seleccionarse en el interfaz de usuario.
        /// </summary>
        public bool Seleccionable { get; set; }

        /// <summary>
        /// Id Tarjeta vieja
        /// </summary>
        public string IdTarjetaAntigua { get; set; }
        public string MotivoError { get; set; }

        /// <summary>
        /// Estado Tokenización
        /// </summary>
        public string EstadoTokenizacion { get; set; }

        /// <summary>
        /// Producto tokenizado
        /// </summary>
        public bool ProductoTokenizado { get; set; }

        /// <summary>
        /// name de la entidad generada
        /// </summary>
        public string Name { get; set; }

        public string TitularTarjetaRut { get; set; }
        public Guid TitularTarjeta { get; set; }
    }
}
