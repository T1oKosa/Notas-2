﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class ResponseEvaluacion
    {
        public string estado { get; set; }
        public string mensaje { get; set; }
        public string id_autorizacion { get; set; }
        public string id_card { get; set; }
        public string codigo_rblando { get; set; }
    }
}
