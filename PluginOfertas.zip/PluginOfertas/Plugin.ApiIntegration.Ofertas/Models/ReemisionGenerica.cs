﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class ReemisionGenerica
    {
        public string Nombre_cliente { get; set; }
        public string Rut_cliente { get; set; }
        public string Tipo_cliente { get; set; }
        public string Nombre_titular { get; set; }
        public string Id_cuenta { get; set; }
        public string Nro_cuenta { get; set; }
        public string Id_tarjeta { get; set; }
        public string Logo { get; set; }
        public string NumeroTarjetaAnterior { get; set; }
        public string Estado_tokenizacion { get; set; }
        public bool Producto_tokenizado { get; set; }
        public int ReemisionEstado { get; set; }

        [DisplayName("Estado reemisión")]
        public string ReemisionEstadoString
        {
            get
            {
                switch (ReemisionEstado)
                {
                    case 10:
                        return "Listo para Reemitir";
                    case 20:
                        return "En Proceso de Reemisión";
                    case 30:
                        return "Reemisión Realizada con Exito";
                    case 40:
                        return "Caducado";
                    case 50:
                        return "Error";
                    case 60:
                        return "Reemisión exitosa";
                    default:
                        return "Estado no especificado";
                };
            }
        }

        public string Codigo_bloqueo { get; set; }
        public string Bloqueo { get; set; }
        public string Motivo { get; set; }
        public string MotivoError { get; set; }
        public string NroSolicitud { get; set; }
        public Guid GuidCrm { get; set; }
    }

    public enum ReemisionMotivo
    {
        Mantención = 282270000,
        Perdida = 282270001
    }
}
