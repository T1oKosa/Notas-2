﻿extern alias GComponents;

using GComponents::Axxon.GlobalComponents.Helper;
using Plugin.ApiIntegration.Ofertas.Contract;
using Plugin.ApiIntegration.Ofertas.Service;
using System;
using System.Collections.Generic;
using System.Globalization;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class OfertaAE : Oferta, IPlantillaProducto
    {
        public List<DataAE> data { get; set; }
        public string Gebody(DataAE data, Producto producto)
        {
            char caracter = '"';
            return $@"
                 <input type={caracter}hidden{caracter} data-back={caracter}{producto.Id}{data.logo}{caracter}>
                   <div class={caracter}row text-monto{caracter}>
                        <div class={caracter}col-5{caracter}>Monto</div>
                        <div class={caracter}col-7{caracter}>{data.monto.ToString("C", new CultureInfo("es-CL"))}</div>
                   </div>
                  <div class={caracter}row{caracter}>
                        <div class={caracter}col-5{caracter}>N. de cuenta</div>
                        <div class={caracter}col-7{caracter}>{data.numero_cuenta}</div>
                  </div>";

        }
        public OfertaSelecionada ToOfertaSimular(DataAE data, Producto producto, PluginContext ctx)
        {
            OfertaSelecionada oferta = new OfertaSelecionada();
            oferta.numero_cuenta = data.numero_cuenta;
            oferta.codigo = int.Parse(producto.Codigo);
            oferta.id_oferta = null;
            oferta.id_activo = data.id_cuenta;
            //Monto
            Monto monto = new Monto()
            {
                moneda = "CLP",
                simbolo = "$",
                valor = !string.IsNullOrEmpty(data.monto.ToString()) ? ((int?)Math.Round(data.monto)) : null
            };
            Monto monto_oferta_neto = new Monto()
            {
                moneda = "CLP",
                simbolo = "$",
                valor = !string.IsNullOrEmpty(data.monto_oferta_neto.ToString()) ? ((int?)Math.Round(data.monto_oferta_neto)) : null
            };
            Monto monto_oferta_neto_ratificable = new Monto()
            {
                moneda = "CLP",
                simbolo = "$",
                valor = !string.IsNullOrEmpty(data.monto_oferta_neto_ratificable.ToString()) ? ((int?)Math.Round(data.monto_oferta_neto_ratificable)) : null
            };
            Monto monto_oferta_neto_no_ratificable = new Monto()
            {
                moneda = "CLP",
                simbolo = "$",
                valor = !string.IsNullOrEmpty(data.monto_oferta_neto_no_ratificable.ToString()) ? ((int?)Math.Round(data.monto_oferta_neto_no_ratificable)) : null
            };
            oferta.monto = monto;
            oferta.monto_oferta_neto = monto_oferta_neto;
            oferta.monto_oferta_neto_ratificable = monto_oferta_neto_ratificable;
            oferta.monto_oferta_neto_no_ratificable = monto_oferta_neto_no_ratificable;
            oferta.descripcion = string.Empty;
            oferta.producto = $"{producto.Nombre} {ctx.CachedEntities.GetProductByCodigoLogo(data.codigo_logo).Name}";
            oferta.id_producto = !string.IsNullOrEmpty(producto.Codigo) ? (int?)int.Parse(producto.Codigo) : null;
            oferta.requiere_simulacion = producto.Simulable;
            oferta.tipo_oferta = !string.IsNullOrEmpty(producto.ER) ? "PRE-APROBADA" : "APROBADA";
            oferta.categorizacion_afinidad = false;
            oferta.fecha_inicio = null;
            oferta.fecha_fin = null;
            oferta.seleccionable = producto.Selecionable;
            //Cupo
            CupoTotalCuenta cupototal = new CupoTotalCuenta()
            {
                moneda = "CLP",
                simbolo = "",
                valor = null
            };
            oferta.cupo_total_cuenta = cupototal;
            oferta.traspaso_tarjeta_cerrada = false;
            oferta.productId = producto.Id.ToString();
            oferta.propiedades = new List<string>();
            oferta.url_servicio_simulacion = "Axx_Api.ApiIntegracion.SimulacionAe";
            return oferta;
        }
        public GComponents::Axxon.GlobalComponents.Model.Oferta ToOfertaSelecionada(DataAE data, Producto producto)
        {
            GComponents::Axxon.GlobalComponents.Model.Oferta oferta = new GComponents::Axxon.GlobalComponents.Model.Oferta();
            oferta.numero_cuenta = data.numero_cuenta;
            oferta.codigo = producto.Codigo;
            oferta.id_oferta = "";
            //Monto
            GComponents::Axxon.GlobalComponents.Model.Currency monto = new GComponents::Axxon.GlobalComponents.Model.Currency()
            {
                moneda = "CLP",
                simbolo = "$",
                valor = int.Parse(data.monto.ToString())
            };
            oferta.monto = monto;
            oferta.descripcion = string.Empty;
            oferta.producto = producto.Nombre + " " + data.logo;
            oferta.id_producto = producto.Codigo;
            //oferta.requiere_simulacion = producto.Simulable;
            oferta.tipo_oferta = !string.IsNullOrEmpty(producto.ER) ? "PRE-APROBADA" : "APROBADA";
            oferta.categorizacion_afinidad = false;
            oferta.id_activo = "";
            oferta.fecha_inicio = null;
            oferta.fecha_fin = null;
            //oferta.seleccionable = producto.Selecionable;
            //Cupo
            GComponents::Axxon.GlobalComponents.Model.Currency cupototal = new GComponents::Axxon.GlobalComponents.Model.Currency()
            {
                moneda = "CLP",
                simbolo = "",
                valor = 0
            };
            oferta.cupo_total_cuenta = cupototal;
            //oferta.traspaso_tarjeta_cerrada = false;
            oferta.productId = Guid.Parse(producto.Id);
            //oferta.propiedades = new List<string>();
            return oferta;
        }

        public List<Plantilla> GetProducto(Producto producto, PluginContext ctx)
        {
            List<Plantilla> lista = new List<Plantilla>();
            foreach (var oferta in this.data)
            {
                Plantilla plantilla = new Plantilla();
                var tarjeta = ctx.CachedEntities.GetProductByCodigoLogo(oferta.codigo_logo);
                ctx.Trace($"plantilla");
                string json = JsonSerializer.Serialize<OfertaSelecionada>(ToOfertaSimular(oferta, producto, ctx));
                ctx.Trace($"plantilla - json");
                string idcard = $"{oferta.logo}{DateTime.Now.Ticks}";
                ctx.Trace($"plantilla - idcard");
                string logo = $"{producto.Nombre} {tarjeta.Name}";
                ctx.Trace($"plantilla - logo");
                try
                {
                    ctx.Trace($"plantilla - get logo");
                    producto.Logo = tarjeta.Logo;
            }
                catch (Exception ex)
            {
                    ctx.Trace($"plantilla - get logo {ex.Message}");
            }
                plantilla.Selecionable = producto.Selecionable;
                ctx.Trace($"plantilla - selecionable");
                plantilla.Simulable = producto.Simulable;
                ctx.Trace($"plantilla - simulable");
                plantilla.HTML = PlantillaHelper.Card(Gebody(oferta, producto), logo, idcard, producto);
                ctx.Trace($"plantilla - html");
                plantilla.Id = $"{producto.Id}{oferta.logo}";
                ctx.Trace($"plantilla - id");
                plantilla.JSON = json;
                ctx.Trace($"plantilla - jn");

                lista.Add(plantilla);
            }
            return lista;
        }
    }

    public class DataAE
    {
        public string numero_cuenta { get; set; }
        public int id_cuenta { get; set; }
        public string codigo_logo { get; set; }
        public string logo { get; set; }
        public int id_logo { get; set; }
        public double monto { get; set; }
        public double monto_oferta_neto { get; set; }
        public double monto_oferta_neto_ratificable { get; set; }
        public double monto_oferta_neto_no_ratificable { get; set; }
        public string fecha_ult_actualizacion { get; set; }
    }
}