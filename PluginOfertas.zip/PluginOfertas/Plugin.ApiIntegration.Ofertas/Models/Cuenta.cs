﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class Cuenta
    {
        public int id_cuenta { get; set; }
        public string numero_cuenta { get; set; }
        public SaldosCuposCuenta saldos_cupos_cuenta { get; set; }
    }
}
