﻿extern alias GComponents;

using GComponents::Axxon.GlobalComponents.Helper;
using GComponents::Axxon.GlobalComponents.Model;
using Plugin.ApiIntegration.Ofertas.Contract;
using Plugin.ApiIntegration.Ofertas.Service;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static GComponents::Axxon.GlobalComponents.Helper.Enums;
using static Plugin.ApiIntegration.Ofertas.Models.OfertaUpgrade;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class OfertaUpgrade : IPlantillaProducto
    {
        private const string dateFormat = "dd-MM-yyyy";
        public string Gebody(Data data, Producto producto, PluginContext ctx)
        {
            char caracter = '"';
            return $@"
                  <input type={caracter}hidden{caracter} data-back={caracter}{producto.Id}{GetLogo(data.logo.id.Value)}{caracter}>
                   <div class={caracter}row text-monto{caracter}>
                       <div class={caracter}col-5{caracter}>Monto</div>
                       <div class={caracter}col-7{caracter}>{data.cuenta.saldos_cupos_cuenta.cupo_nacional_cupo_virtual.Value.ToString("C", new CultureInfo("es-CL"))}</div>
                   </div>";
        }
        public List<Plantilla> GetProducto(Producto producto, PluginContext ctx)
        {
            //producto = producto CRM - Upgrade CRM
            //producto Unitario = producto data json
            //oferta = json traspaso
            ctx.Trace($"GetProducto");
            List<Plantilla> lista = new List<Plantilla>();
            foreach (var oferta in this.data)
            {

                Producto productoActual = new Producto();
                Product productActual = ctx.CachedEntities.GetProductByCodigoLogo(oferta.logo.codigo);
                if (productActual == null)
                {
                    ctx.Trace($"Producto Actual no existe en CRM - Codigo: {oferta.logo.codigo}");
                    continue;
                }
                else
                {
                    ctx.Trace($"Producto Actual SI existe en CRM - Codigo: {oferta.logo.codigo}");
                    productoActual = CRMQueries.GetProducto(ctx, productActual.ProductId);
                }

                Producto productoUpgrade = CRMQueries.GetProducto(ctx, ctx.CachedEntities.GetProductByCodigo(producto.Codigo).ProductId);

                if (oferta.logos_objetivo.Count > 0)
                {
                    int contador = 0;
                    List<string> numerosGUID =  Utils.GeneraGuidListas(oferta.logos_objetivo.Count);

                    foreach (var logosObjetivos in oferta.logos_objetivo)
                    {
                        Producto productoDestinoUpgrade = new Producto();
                        Product productDestinoUpgrade = ctx.CachedEntities.GetProductByCodigoLogo(logosObjetivos.codigo);
                        if (productDestinoUpgrade == null)
                        {
                            ctx.Trace($"Producto Ojetivo no existe en CRM - Codigo: {logosObjetivos.codigo}");
                            continue;
                        }
                        else
                        {
                            ctx.Trace($"Producto Ojetivo SI existe en CRM - Codigo: {logosObjetivos.codigo}");
                            productoDestinoUpgrade = CRMQueries.GetProducto(ctx, productDestinoUpgrade.ProductId);
                        }
                      
                        productoUpgrade.ER = producto.ER;
                        productoUpgrade.Orden = producto.Orden;
                        Random rnd = new Random();
                        string idcard = productoDestinoUpgrade.Nombre.Replace(" ", "") + numerosGUID[contador];
                        string logo = "Upgrade " + productoDestinoUpgrade.Nombre;
                        contador++;

                        List<AdicionalUpgrade> datosAdicionales = new List<AdicionalUpgrade>();
                        if (oferta.rol.codigo_titularidad == "10")
                        {
                            foreach (var ofertaAdicionales in this.data)
                            {
                                if (ofertaAdicionales.rol.codigo_titularidad != null && ofertaAdicionales.rol.codigo_titularidad == "20" && oferta.cuenta.id_cuenta == ofertaAdicionales.cuenta.id_cuenta)
                                {
                                    AdicionalUpgrade adicionalNuevo = new AdicionalUpgrade();
                                    adicionalNuevo.id_cliente_adicional = ofertaAdicionales.id_cliente_adicional.ToString();
                                    adicionalNuevo.logo_codigo_adicional = ofertaAdicionales.logo.codigo != null ? ofertaAdicionales.logo.codigo.ToString() : "";
                                    adicionalNuevo.logo_id_adicional = ofertaAdicionales.logo.id.ToString();
                                    adicionalNuevo.logo_descripcion_adicional = ofertaAdicionales.logo.descripcion != null ? ofertaAdicionales.logo.descripcion.ToString() : "";
                                    adicionalNuevo.id_tarjeta_adicional = ofertaAdicionales.id_tarjeta.ToString();
                                    adicionalNuevo.id_cuenta_titular = ofertaAdicionales.cuenta.id_cuenta.ToString();
                                    adicionalNuevo.numero_tarjeta = ofertaAdicionales.numero_tarjeta.ToString();
                                    adicionalNuevo.numero_cuenta = ofertaAdicionales.cuenta.numero_cuenta.ToString();
                                    adicionalNuevo.bloqueo = ofertaAdicionales.bloqueos_tarjeta.descripcion;
                                    adicionalNuevo.fecha_activacion = ofertaAdicionales.fecha_activacion;
                                    adicionalNuevo.fecha_emision_tarjeta = ofertaAdicionales.fecha_emision_tarjeta;
                                    adicionalNuevo.fecha_bloqueo = ofertaAdicionales.fecha_vencimiento_tarjeta;
                                    adicionalNuevo.adicional_visible = ofertaAdicionales.adicional_visible;

                                    if (ofertaAdicionales.logo.codigo != null)
                                    {
                                        var prodActual = CRMQueries.GetProducto(ctx, ctx.CachedEntities.GetProductByCodigoLogo(ofertaAdicionales.logo.codigo).ProductId);
                                        adicionalNuevo.id_producto_actual = prodActual.Id;
                                    }

                                    if (logosObjetivos.codigo != null)
                                    {
                                        var prodUpgrade = CRMQueries.GetProducto(ctx, ctx.CachedEntities.GetProductByCodigoLogo(logosObjetivos.codigo).ProductId);
                                        adicionalNuevo.id_producto_upgrade = prodUpgrade.Id;
                                    }
                                    datosAdicionales.Add(adicionalNuevo);
                                }
                            }
                            string json = JsonSerializer.Serialize<OfertaSelecionada>(ToOfertaSeleccionada(ctx, oferta, datosAdicionales, productoUpgrade, productoDestinoUpgrade, productoActual));
                            producto.Logo = ctx.CachedEntities.GetProductByCodigoLogo(oferta.logo.codigo).Name;//CRMQueries.getLogo(ctx, parseGrupo(oferta.logo.id.Value));

                            productoDestinoUpgrade.Selecionable = producto.Selecionable;
                            productoDestinoUpgrade.Simulable = producto.Simulable;
                            lista.Add(new Plantilla()
                            {
                                Selecionable = producto.Selecionable,//productoUpgrade.ProductoSeleccionableOpcional,
                                Simulable = producto.Simulable,//productoUpgrade.ProductoSimulableOpcional,
                                HTML = PlantillaHelper.Card(Gebody(oferta, productoUpgrade, ctx), logo, idcard, productoDestinoUpgrade),
                                Id = idcard,
                                JSON = json
                            });
                           
                        }
                    }
                }
            }
            return lista;
        }
        public string GetLogo(int id)
        {
            string logo = string.Empty;
            switch (id)
            {
                case 1:
                    logo = "Mastercard";
                    break;
                case 2:
                    logo = "Platinium";
                    break;
                case 3:
                    logo = "Black";
                    break;
            }
            return logo;
        }

        public OfertaSelecionada ToOfertaSeleccionada(PluginContext ctx, Data data, List<AdicionalUpgrade> datosAdicionales, Producto producto, Producto productoUpgrade, Producto productoActual)
        {
            OfertaSelecionada oferta = new OfertaSelecionada();
            oferta.numero_cuenta = data.cuenta.numero_cuenta;
            oferta.codigo = int.Parse(producto?.Codigo);
            oferta.id_oferta = null; //cambiar id de oferta
            //Monto
            Monto monto = new Monto()
            {
                moneda = "CLP",
                simbolo = "$",
                valor = data.cuenta.saldos_cupos_cuenta.cupo_nacional_cupo_virtual
            };
            oferta.monto = monto;
            oferta.descripcion = string.Empty;
            oferta.producto = $"{producto?.Nombre}";
            oferta.id_producto = int.Parse(producto.Codigo);
            oferta.requiere_simulacion = producto.Simulable;
            oferta.tipo_oferta = !string.IsNullOrEmpty(producto.ER) ? "PRE-APROBADA" : "APROBADA";
            oferta.categorizacion_afinidad = false;
            oferta.seleccionable = producto.Selecionable;
            CupoTotalCuenta cupototal = new CupoTotalCuenta()
            {
                moneda = "CLP",
                simbolo = "",
                valor = data.cuenta.saldos_cupos_cuenta.cupo_nacional_cupo_virtual
            };
            oferta.cupo_total_cuenta = cupototal;
            oferta.traspaso_tarjeta_cerrada = false;
            oferta.productId = producto.Id;
            oferta.propiedades = new List<string>();
            oferta.adicionales_upgrade = datosAdicionales;
            oferta.producto_upgrade_id = productoUpgrade.Id;
            oferta.producto_upgrade = productoUpgrade.Nombre;
            oferta.numero_tarjeta = data.numero_tarjeta.ToString();
            oferta.id_cuenta = data.cuenta.id_cuenta.ToString();
            oferta.producto_actual = productoActual.Nombre;
            oferta.producto_actual_id = productoActual.Id;
            oferta.bloqueo = data.bloqueos_tarjeta.descripcion;
            oferta.fecha_activacion = data.fecha_activacion;
            oferta.fecha_emision_tarjeta = data.fecha_emision_tarjeta;
            oferta.fecha_bloqueo = data.fecha_vencimiento_tarjeta;
            oferta.id_cliente = data.id_cliente.ToString();
            oferta.id_tarjeta_antigua = data.id_tarjeta.ToString();
            oferta.fecha_vencimiento_facturacion = data.cuenta.fecha_vencimiento_facturacion;
            oferta.pct = data.cuenta.pct.ToString();
            oferta.seguro_actual = data.seguro_actual.ToString(); 
            return oferta;
        }


        /// <summary>
        /// comienza la declaracion de la clase
        /// </summary>

        public string id { get; set; }
        public int? status { get; set; }
        public string resource { get; set; }
        public List<Data> data { get; set; }
        public Metadata metadata { get; set; }


        public class Metadata
        {
            public string XB3SpanId { get; set; }
            public string XB3TraceId { get; set; }
        }

        public class Data
        {
            public int? id_tarjeta { get; set; }
            public int? id_cliente { get; set; }
            public int? id_cliente_adicional { get; set; }
            public bool? adicional_visible { get; set; }
            public string numero_tarjeta { get; set; }
            public string nombres_tarjeta { get; set; }
            public string fecha_hora_estado_autorizador { get; set; }
            public string fecha_apertura { get; set; }
            public int? tarjeta_purgada { get; set; }
            public int? indicador_vigente { get; set; }
            public Cuenta cuenta { get; set; }
            public string fecha_emision_tarjeta { get; set; }
            public string fecha_activacion { get; set; }
            public string fecha_vencimiento_tarjeta { get; set; }
            public bool es_digital { get; set; }
            public Logo logo { get; set; }
            public List<Logos_Objetivo> logos_objetivo { get; set; }
            public Rol rol { get; set; }
            public Bloqueos_Tarjeta bloqueos_tarjeta { get; set; }
            public Estado_Autorizador_Tarjeta estado_autorizador_tarjeta { get; set; }
            public string icono_on { get; set; }
            public string icono_off { get; set; }
            public Organizacion organizacion { get; set; }
            public string pin_ofset_tarjeta { get; set; }
            public string message { get; set; }
            public string principal { get; set; }
            public string seguro_actual { get; set; }
    }

        public class Cuenta
        {
            public int? id_cuenta { get; set; }
            public string numero_cuenta { get; set; }
            public int? indicador_vigente { get; set; }
            public string fecha_vencimiento_facturacion { get; set; }
            public int? dias_mora_real { get; set; }
            public string fecha_ult_actualizacion { get; set; }
            public string fecha_apertura { get; set; }
            public Bloqueos_Cuenta bloqueos_cuenta { get; set; }
            public Estado_Autorizador_Cuenta estado_autorizador_cuenta { get; set; }
            public Saldos_Cupos_Cuenta saldos_cupos_cuenta { get; set; }
            public string fecha_hora_estado_autorizador { get; set; }
            public bool es_castigada { get; set; }
            public int? cuenta_purgada { get; set; }
            public string pct { get; set; }
            public string segmento { get; set; }
            public string id_cuenta_anterior { get; set; }
            public string id_traspaso_cuenta { get; set; }
        }

        public class Bloqueos_Cuenta
        {
            public int? id_tipo_bloqueo_cuenta_1 { get; set; }
            public string codigo_bloqueo_cuenta_1 { get; set; }
            public string descripcion_bloqueo_cuenta_1 { get; set; }
            public int? id_tipo_bloqueo_cuenta_2 { get; set; }
            public string codigo_bloqueo_cuenta_2 { get; set; }
            public string descripcion_bloqueo_cuenta_2 { get; set; }
        }

        public class Estado_Autorizador_Cuenta
        {
            public int? id { get; set; }
            public int? codigo { get; set; }
            public string descripcion { get; set; }
        }

        public class Saldos_Cupos_Cuenta
        {
            public int? monto_saldo_pendiente { get; set; }
            public int? cupo_nacional_cupo_virtual { get; set; }
            public int? deuda_total_nacional { get; set; }
            public int? dispo_total_en_clp { get; set; }
            public int? dispo_total_en_us { get; set; }
            public string cupo_total_avance_efectivo { get; set; }
            public int? dispo_para_avances { get; set; }
            public int? utilizado_calculado { get; set; }
        }

        public class Logo
        {
            public int? id { get; set; }
            public string codigo { get; set; }
            public string descripcion { get; set; }
            public string orden_despliegue { get; set; }
            public string sam { get; set; }
        }
       
        public class Rol
        {
            public string codigo_titularidad { get; set; }
            public string titularidad { get; set; }
        }

        public class Bloqueos_Tarjeta
        {
            public int? id { get; set; }
            public string codigo { get; set; }
            public string descripcion { get; set; }
            public bool? permite_compra { get; set; }
        }

        public class Estado_Autorizador_Tarjeta
        {
            public int? id { get; set; }
            public string code { get; set; }
            public string descripcion { get; set; }
        }

        public class Organizacion
        {
            public int? id { get; set; }
            public string code { get; set; }
            public string descripcion { get; set; }
        }
        public class Logos_Objetivo
        {
            public object id { get; set; }
            public string codigo { get; set; }
            public string descripcion { get; set; }
            public object orden_despliegue { get; set; }
            public object sam { get; set; }
        }
    }
}
