﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class ResponseReemisionTarjetas
    {
        public string id { get; set; }
        public int status { get; set; }
        public string resource { get; set; }
        public Data data { get; set; }
        public object metadata { get; set; }


        public class Data
        {
            public int id { get; set; }
            public object fecha { get; set; }
            public string id_correlativo { get; set; }
            public object rut { get; set; }
            public string numero_cuenta { get; set; }
            public string numero_tarjeta { get; set; }
            public string nombre_bloqueo_actual { get; set; }
            public object nombre_bloqueo_anterior { get; set; }
            public string tipo_cliente { get; set; }
            public string duenio_plastico { get; set; }
            public int nuevo_id_tarjeta { get; set; }
            public string nuevo_numero_tarjeta { get; set; }
        }
    }
}


