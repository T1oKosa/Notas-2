﻿extern alias GComponents;

using System;
using System.Collections.Generic;
using GComponents::Axxon.GlobalComponents.Helper;
using Plugin.ApiIntegration.Ofertas.Contract;
using Plugin.ApiIntegration.Ofertas.Service;
using System.Globalization;
using GComponents::Axxon.GlobalComponents.Model;


namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class OfertasAdicionales : Oferta, IPlantillaProducto
    {
        public List<DataOfertaAdicional> data { get; set; }

        public string Gebody(DataOfertaAdicional data, Producto producto)
        {
            char caracter = '"';
            return $@"
                <input type={caracter}hidden{caracter} data-back={caracter}{producto.Id}{data.logo.codigo}{caracter}>
                <div class={caracter}row{caracter}>
                    <div class={caracter}col-5{caracter}>N. de tarjeta</div>
                    <div class={caracter}col-7{caracter}>{data.numero_tarjeta}</div>
                </div>";
        }

        public OfertaSelecionada ToOfertaSeleccionable(DataOfertaAdicional data, Producto producto, PluginContext ctx)
        {
            ctx.Trace("Ingreso a ToOfertaSeleccionable, data:" +data.cuenta.numero_cuenta + " producto: " + producto.Codigo);
            OfertaSelecionada oferta = new OfertaSelecionada();
            oferta.numero_cuenta = data.cuenta.numero_cuenta;
            oferta.numero_tarjeta = data.numero_tarjeta;
            oferta.codigo = int.Parse(producto.Codigo);
            oferta.id_oferta = null;
            oferta.id_activo = data.cuenta.id_cuenta;
            oferta.id_tarjeta = data.id_tarjeta;
            //Monto
            Monto monto = new Monto()
            {
                moneda = "CLP",
                simbolo = "$",
                valor = Convert.ToInt32(data.cuenta.saldos_cupos_cuenta.cupo_nacional_cupo_virtual)
            };
            oferta.monto = monto;
            oferta.descripcion = string.Empty;
            oferta.producto = $"{producto.Nombre} {data.logo.descripcion}";
            oferta.id_producto = !string.IsNullOrEmpty(producto.Codigo) ? (int?)int.Parse(producto.Codigo) : null;
            oferta.requiere_simulacion = producto.Simulable;
            oferta.tipo_oferta = !string.IsNullOrEmpty(producto.ER) ? "PRE-APROBADA" : "APROBADA";
            oferta.categorizacion_afinidad = false;
            oferta.fecha_inicio = null;
            oferta.fecha_fin = null;
            oferta.seleccionable = producto.Selecionable;
            //Cupo
            CupoTotalCuenta cupototal = new CupoTotalCuenta()
            {
                moneda = "CLP",
                simbolo = "$",
                valor = Convert.ToInt32(data.cuenta.saldos_cupos_cuenta.cupo_nacional_cupo_virtual)
            };
            oferta.cupo_total_cuenta = cupototal;
            oferta.traspaso_tarjeta_cerrada = false;
            oferta.productId = producto.Id.ToString();
            oferta.propiedades = new List<string>();
            oferta.descripcion = data.mensaje;
            return oferta;
        }

        public List<Plantilla> GetProducto(Producto producto, PluginContext ctx)
        {
            int contador = 0;
            ctx.Trace($"Genera Lista de Ids Unicos");
            List<string> numerosGUID = Utils.GeneraGuidListas(this.data.Count);

            ctx.TracingService.Trace("ingreso a GetProducto - Cantidad de datos: {0} - Producto {1}", data.Count, producto.Codigo);
            List<Plantilla> lista = new List<Plantilla>();
            foreach (var oferta in this.data)
            {
                Plantilla plantilla = new Plantilla();
                string json = JsonSerializer.Serialize<OfertaSelecionada>(ToOfertaSeleccionable(oferta, producto, ctx));
                string idcard = $"{oferta.logo.descripcion}" + numerosGUID[contador];
                contador++;
                string logo = $"{producto.Nombre} - {ctx.CachedEntities.GetProductByCodigoLogo(oferta.logo.codigo).Name}";
               
                try
                {
                    producto.Logo = ctx.CachedEntities.GetProductByCodigoLogo(oferta.logo.codigo).Logo;
                }
                catch (Exception ex)
                {
                    ctx.Trace($"Error GetProductByCodigoLogo: {ex.Message}");
                }
                plantilla.Selecionable = producto.Selecionable;
                plantilla.Simulable = producto.Simulable;

                if (!String.IsNullOrEmpty(oferta.mensaje))
                {
                    producto.ER = "espera";
                    plantilla.Simulable = false;
                    plantilla.Selecionable = false;
                    plantilla.HTML = PlantillaHelper.CardAlert(Gebody(oferta, producto), logo, idcard, producto, oferta);
                }
                else
                {
                    plantilla.HTML = PlantillaHelper.Card(Gebody(oferta, producto), logo, idcard, producto);
                }
                plantilla.Id = $"{producto.Id}{oferta.logo}";
                plantilla.JSON = json;
                lista.Add(plantilla);
            }

            return lista;
        }
    }

    public class DataOfertaAdicional
    {
        public int id_tarjeta { get; set; }
        public int id_cliente { get; set; }
        public Cuenta id_cuenta { get; set; }
        public Cuenta cuenta { get; set; }
        public string numero_tarjeta { get; set; }
        public Logo logo { get; set; }
        public string mensaje { get; set; }
    }
}

