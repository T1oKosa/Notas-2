﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class EOTarjetas
    {
        public string id { get; set; }
        public int status { get; set; }
        public string resource { get; set; }
        public Data2 data { get; set; }
        public Metadata metadata { get; set; }
    }

    public class Data2
    {
        public string id_token { get; set; }
        public Estado2 estado { get; set; }
        public Ofertas ofertas { get; set; }
    }

    public class Estado2
    {
        public string despcripcion { get; set; }
        public List<Rechazo> rechazos { get; set; }
    }
  
    public class Ofertas
    {
        [IgnoreDataMember]
        public int? id_cliente { get; set; }
        public int? id_oferta { get; set; }
        public int? id_grupo { get; set; }
        public int? cupo { get; set; }
        //public DateTime? fecha_vigencia_inicial { get; set; }
        //public DateTime? fecha_vigencia_final { get; set; }
    }
    public class Rechazo
    {
        public string codigo { get; set; }
        public string mensaje { get; set; }
        public bool? rechazo_blando { get; set; }
    }
}
