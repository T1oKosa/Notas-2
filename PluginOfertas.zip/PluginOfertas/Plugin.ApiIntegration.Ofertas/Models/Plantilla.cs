﻿extern alias GComponents;

using GComponents::Axxon.GlobalComponents.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class Plantilla
    {
        public bool Selecionable { get; set; }
        public bool Simulable { get; set; }
        public string HTML { get; set; }
        public string JSON { get; set; }
        public string Id { get; set; }
        public int Orden { get; set; }
    }
    public static class PlantillaHelper
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="body">html </param>
        /// <param name="titulo">texto del titulo</param>
        /// <param name="er">url evaluador de riesgo</param>
        /// <param name="order">N del orden de la card</param>
        /// <returns></returns>
        public static string Card(string body, string titulo, string idcard, Producto producto)
        {
            char caracter = '"';
            string tarjetaactiva = producto.Selecionable || producto.Simulable ? "card-link" : string.Empty;
            string _OMDM = !string.IsNullOrEmpty(producto.ER) ? "espera" : "aprobado"; //Estado para Evaluar el riesgo
            string imgg = $@"<img class={caracter}icon-header{caracter} src={caracter}{producto.Logo}{caracter} alt={caracter}{caracter}>";
            return $@"
                    <div class={caracter}col-xxl-3 col-xl-4 col-lg-4 col-md-6 col-sm-16 my-3 order-{producto.Orden} {caracter} id={caracter}{idcard}{caracter}>
                        <div class={caracter}card border-0 h-100 position-relative{caracter}>
                            <div class={caracter}card-oferta h-100 estado-{_OMDM} {tarjetaactiva} {caracter}>
                                <div class={caracter}card-header{caracter}>
                                    <div class={caracter}row justify-content-between mb-3{caracter}>
                                        <div class={caracter}col-auto g-0{caracter}><span class={caracter}icono{caracter}></span></div>
                                        <div class={caracter}col text-uppercase{caracter}>{_OMDM}</div>
                                        <div class={caracter}col-auto{caracter}><span class={caracter}alerta{caracter}></span></div>
                                    </div>
                                    <div class={caracter}row{caracter}>
                                        <div class={caracter}col-12 g-0{caracter}>
                                            <h3 class={caracter}title-producto{caracter}>{imgg}{titulo}</h3>
                                        </div>
                                    </div>
                                </div>

                             <div class={caracter}card-body p-0{caracter}>
                                {body}
                             </div>


                            </div>
                        </div>
                    </div>";
        }

        public static string CardCoplementarias(string body, string titulo, string idcard, Producto producto)
        {
            char caracter = '"';
            string estado = producto.ER == "aprobado" ? producto.ER : "espera";
            string tarjetaactiva = producto.Selecionable || producto.Simulable ? "card-link" : string.Empty;
            string imgg = $@"<img class={caracter}icon-header{caracter} src={caracter}{producto.Logo}{caracter} alt={caracter}{caracter}>";
            return $@"
                    <div class={caracter}col-xxl-3 col-xl-4 col-lg-4 col-md-6 col-sm-16 my-3 order-{producto.Orden} {caracter} id={caracter}{idcard}{caracter}>
                        <div class={caracter}card border-0 h-100 position-relative{caracter}>
                            <div class={caracter}card-oferta h-100 estado-{estado} {tarjetaactiva} {caracter}>
                                <div class={caracter}card-header{caracter}>
                                    <div class={caracter}row justify-content-between mb-3{caracter}>
                                        <div class={caracter}col-auto g-0{caracter}><span class={caracter}icono{caracter}></span></div>
                                        <div class={caracter}col text-uppercase{caracter}>{producto.ER}</div>                                        
                                    </div>
                                    <div class={caracter}row{caracter}>
                                        <div class={caracter}col-12 g-0{caracter}>
                                            <h3 class={caracter}title-producto{caracter}>{imgg}{titulo}</h3>
                                        </div>
                                    </div>
                                </div>

                             <div class={caracter}card-body p-0{caracter}>
                                {body}
                             </div>


                            </div>
                        </div>
                    </div>";
        }

        public static string Card1peso(string body, string titulo, string idcard, Producto producto)
        {
            char caracter = '"';
            string tarjetaactiva = producto.Selecionable || producto.Simulable ? "card-link" : string.Empty;
            string _OMDM = !string.IsNullOrEmpty(producto.ER) ? "espera" : "aprobado"; //Estado para Evaluar el riesgo
            string imgg = $@"<img class={caracter}icon-header{caracter} src={caracter}{producto.Logo}{caracter} alt={caracter}{caracter}>";
            return $@"
                    <div class={caracter}col-xxl-3 col-xl-4 col-lg-4 col-md-6 col-sm-16 my-3 order-{producto.Orden} {caracter} id={caracter}{idcard}_1peso{caracter}>
                        <div class={caracter}card border-0 h-100 position-relative{caracter}>
                            <div class={caracter}card-oferta h-100 estado-espera {tarjetaactiva} {caracter}>
                                <div class={caracter}card-header{caracter}>
                                    <div class={caracter}row justify-content-between mb-3{caracter}>
                                        <div class={caracter}col-auto g-0{caracter}><span class={caracter}icono{caracter}></span></div>
                                        <div class={caracter}col text-uppercase{caracter}>Pre-Aprobado</div>
                                       
                                    </div>
                                    <div class={caracter}row{caracter}>
                                        <div class={caracter}col-12 g-0{caracter}>
                                            <h3 class={caracter}title-producto{caracter}>{imgg}{titulo}</h3>
                                        </div>
                                    </div>
                                </div>

                             <div class={caracter}card-body p-0{caracter}>
                                {body}
                             </div>


                            </div>
                        </div>
                    </div>";
        }
        public static string CardAlert(string body, string titulo, string idcard, Producto producto, DataOfertaAdicional oferta)
        {
            char caracter = '"';
            string tarjetaactiva = producto.Selecionable || producto.Simulable ? "card-link" : string.Empty;
            string _OMDM = !string.IsNullOrEmpty(producto.ER) ? "espera" : "aprobado"; //Estado para Evaluar el riesgo
            string imgg = $@"<img class={caracter}icon-header{caracter} src={caracter}{producto.Logo}{caracter} alt={caracter}{caracter}>";
            return $@"
                    <div class={caracter}col-xxl-3 col-xl-4 col-lg-4 col-md-6 col-sm-16 my-3 order-{producto.Orden} {caracter} id={caracter}{idcard}{caracter}>
                        <div class={caracter}card border-0 h-100 position-relative{caracter}>
                            <div class={caracter}card-oferta h-100 estado-rechazado{caracter}>
                                <div class={caracter}card-header{caracter}>
                                    <div class={caracter}row justify-content-between mb-3{caracter}>
                                        <div class={caracter}col-auto g-0{caracter}><span class={caracter}icono{caracter}></span></div>
                                        <div class={caracter}col text-uppercase{caracter}>Tarjeta Bloqueada</div>
                                        <span class={caracter}{caracter} data-tooltip={caracter}Incumplimiento previo de una obligación contraída con la empresa, sus filiales o relacionadas{caracter} data-flow={caracter}top{caracter} style={caracter}
                                        background: url('../Ofertador/icons/Icon_Info.svg')!important;
                                        width: 24px;
                                        height: 24px;
                                        display: flex;
                                        {caracter}>
                                        </ span >
                                    </div>
                                    <div class={caracter}row{caracter}>
                                        <div class={caracter}col-12 g-0{caracter}>
                                            <h3 class={caracter}title-producto{caracter}>{imgg}{titulo}</h3>
                                        </div>
                                    </div>
                                </div>

                             <div class={caracter}card-body p-0{caracter}>
                                {body}
                             </div>


                            </div>
                        </div>
                    </div>";
        }
        public static string CardError(Producto producto)
        {
            string idcard = string.Format("{0}{1}", producto.Nombre, DateTime.Now.Ticks);
            char caracter = '"';
            string imgg = $@"<img class={caracter}icon-header{caracter} src={caracter}{producto.Logo}{caracter} alt={caracter}{caracter}>";
            return $@"<div class={caracter}col-xxl-3 col-xl-4 col-lg-4 col-md-6 col-sm-16 my-3{caracter} id={caracter}${idcard}{caracter}>
                                <div class={caracter}card-oferta h-100 estado-error card-link{caracter}>
                                    <div class={caracter}card-header{caracter}>
                                        <div class={caracter}row justify-content-between mb-3{caracter}>
                                            <div class={caracter}col-auto g-0{caracter}><span class={caracter}icono{caracter}></span></div>
                                            <div class={caracter}col text-uppercase{caracter}>Error de servicio</div>
                                            <div class={caracter}col-auto{caracter}><span class={caracter}alerta{caracter}><img src={caracter}./axx_/icons/icon_refresh.svg{caracter} alt={caracter}{caracter}></span></div>
                                        </div>
                                        <div class={caracter}row{caracter}>
                                            <div class={caracter}col-12 g-0{caracter}>
                                                <h3 class={caracter}title-producto m-0{caracter}><img class={caracter}icon-header{caracter} src={caracter}./axx_/icons/t-black.svg{caracter} alt={caracter}{caracter}> Super Avance
                                                </h3>
                                            </div>
                                        </div>
                                    </div>
                                    <div class={caracter}card-body p-1{caracter}>
                                        <div class={caracter}row{caracter}>
                                            <div class={caracter}col-12 text-start{caracter}>Se ha producido un error durante la operación que deseaba realizar</div>
                                        </div>
                                        <div class={caracter}row{caracter}>
                                            <div class={caracter}col-12 text-end{caracter}><a href={caracter}#{caracter} title={caracter}{caracter} class={caracter}text-danger{caracter}> Reintentar</a></div>
                                        </div>
                                    </div>
                                    <a href={caracter}#{caracter} title={caracter}{caracter} class={caracter}linkFull{caracter}></a>
                                </div>
                            </div>";
        }
        public static string CardComplementariaSinActividad(string body, string titulo, string idCard)
        {
            char caracter = '"';

            return $@"<div class={caracter}col-xxl-3 col-xl-4 col-lg-4 col-md-6 col-sm-16 my-3{caracter} id={caracter}${idCard}{caracter}>
                        <div class={caracter}card-oferta estado-sin-actividad h-100 card-link{caracter}>
                            <div class={caracter}card-header{caracter}>
                                <div class={caracter}row justify-content-between mb-3{caracter}>
                                    <div class={caracter}col-auto g-0{caracter}><span class={caracter}icono{caracter}></span></div>
                                    <div class={caracter}col text-uppercase{caracter}>SIN OFERTA</div>

                                </div>
                                <div class={caracter}row{caracter}>
                                    <div class={caracter}col-12 g-0{caracter}>
                                        <h3 class={caracter}title-producto{caracter}>{titulo}</h3>
                                    </div>
                                </div>
                            </div>

                            <div class={caracter}card-body p-0{caracter}>
                                {body}
                            </div>

                        </div>
                    </div>
                    ";
        }

        public static string CardAutomotrizInformativa(string url, Producto producto, bool habilitada = true)
        {
            const string titulo = "Auto Full cobertura";
            const string subtitulo = "Seguros";

            char c = '"';
            bool cardActiva = habilitada && !string.IsNullOrWhiteSpace(url);
            string claseEstado = cardActiva ? "card-link" : "estado-sin-actividad";
            string linkFull = cardActiva
                ? $"<a href={c}{url}{c} class={c}linkFull{c} style={c}position:absolute;inset:0;z-index:2;{c}></a>"
                : string.Empty;

            return $@"
                <div class={c}col-xxl-3 col-xl-4 col-lg-4 col-md-6 col-sm-16 my-3 order-{producto.Orden}{c} id={c}{producto.Id}{c}>
                    <div class={c}card border-0 h-100 position-relative{c}>
                        <div class={c}card-oferta h-100 {claseEstado}{c}>
                            {linkFull}

                            <div class={c}card-header{c} style={c}background:transparent;border:0;padding:0;margin:0;{c}>
                                <div class={c}row justify-content-between align-items-center{c} style={c}margin:0 0 0.6rem 0;display:flex;align-items:center;gap:0.5rem;{c}>
                                    <div class={c}col-auto{c} style={c}padding:0;{c}>
                                        <span class={c}icono{c} style={c}display:inline-flex;align-items:center;justify-content:center;width:2.1rem;height:2.1rem;border-radius:10px;background:#eaf4ff;color:#1d8ddf;font-size:1.1rem;line-height:1;{c}>
                                            <img src={c}./icons/Ico-car.svg{c} alt={c}{c} style={c}width:1.3rem;height:1.3rem;filter:brightness(0) saturate(100%) invert(34%) sepia(68%) saturate(1361%) hue-rotate(177deg) brightness(92%) contrast(101%);{c} />
                                        </span>
                                    </div>
                                    <div class={c}col text-uppercase{c} style={c}padding:0;display:flex;align-items:center;color: var(--color-blue-6, #22A7FF);font-family: Nunito Sans;font-size: 14px;font-style: normal;font-weight: 800;line-height: 20px;letter-spacing: normal;{c}>OFERTA DE SEGURO</div>
                                </div>

                                <div class={c}row{c} style={c}margin:0;{c}>
                                    <div class={c}col-12 g-0{c} style={c}padding:0;{c}>
                                        <h3 class={c}title-producto{c} style={c}margin:0;color: var(--csfund-colors-credit-card-csb-default, #1A1A1F);font-family: Nunito Sans;font-size: 22px;font-style: normal;font-weight: 700;line-height: 28px;letter-spacing: normal;{c}>{titulo}</h3>
                                    </div>
                                </div>
                            </div>

                            <div class={c}card-body p-0{c} style={c}background:transparent;padding:0 !important;margin-top:0.45rem;{c}>
                                <div class={c}row{c} style={c}margin:0;{c}>
                                    <div class={c}col-12{c} style={c}padding:0;color: var(--csfund-colors-text-dark-400, #2F5776);font-family: Nunito Sans;font-size: 16px;font-style: italic;font-weight: 400;line-height: 22px;{c}>{subtitulo}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>";
        }

        public static string CardAutomotrizAviso(Producto producto, string etiqueta, string mensaje)
        {
            const string titulo = "Auto Full cobertura";

            char c = '"';

            return $@"
                <div class={c}col-xxl-3 col-xl-4 col-lg-4 col-md-6 col-sm-16 my-3 order-{producto.Orden}{c} id={c}{producto.Id}{c}>
                    <div class={c}card border-0 h-100 position-relative{c}>
                        <div class={c}card-oferta h-100 estado-sin-actividad{c}>

                            <div class={c}card-header{c} style={c}background:transparent;border:0;padding:0;margin:0;{c}>
                                <div class={c}row justify-content-between align-items-center{c} style={c}margin:0 0 0.6rem 0;display:flex;align-items:center;gap:0.5rem;{c}>
                                    <div class={c}col-auto{c} style={c}padding:0;{c}>
                                        <span class={c}icono{c} style={c}display:inline-flex;align-items:center;justify-content:center;width:2.1rem;height:2.1rem;border-radius:10px;background:#eaf4ff;color:#1d8ddf;font-size:1.1rem;line-height:1;{c}>
                                            <img src={c}./icons/Ico-car.svg{c} alt={c}{c} style={c}width:1.3rem;height:1.3rem;filter:brightness(0) saturate(100%) invert(34%) sepia(68%) saturate(1361%) hue-rotate(177deg) brightness(92%) contrast(101%);{c} />
                                        </span>
                                    </div>
                                    <div class={c}col text-uppercase{c} style={c}padding:0;display:flex;align-items:center;color: var(--color-blue-6, #22A7FF);font-family: Nunito Sans;font-size: 14px;font-style: normal;font-weight: 800;line-height: 20px;letter-spacing: normal;{c}>{etiqueta}</div>
                                </div>

                                <div class={c}row{c} style={c}margin:0;{c}>
                                    <div class={c}col-12 g-0{c} style={c}padding:0;{c}>
                                        <h3 class={c}title-producto{c} style={c}margin:0;color: var(--csfund-colors-credit-card-csb-default, #1A1A1F);font-family: Nunito Sans;font-size: 22px;font-style: normal;font-weight: 700;line-height: 28px;letter-spacing: normal;{c}>{titulo}</h3>
                                    </div>
                                </div>
                            </div>

                            <div class={c}card-body p-0{c} style={c}background:transparent;padding:0 !important;margin-top:0.45rem;{c}>
                                <div class={c}row{c} style={c}margin:0;{c}>
                                    <div class={c}col-12{c} style={c}padding:0;color: var(--csfund-colors-text-dark-400, #2F5776);font-family: Nunito Sans;font-size: 16px;font-style: italic;font-weight: 400;line-height: 22px;{c}>{mensaje}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>";
        }

    }
}