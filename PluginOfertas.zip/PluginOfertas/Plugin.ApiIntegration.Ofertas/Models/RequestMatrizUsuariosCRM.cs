﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class RequestMatrizUsuariosCRM
    {
        public int statusCode { get; set; }
        public Headers headers { get; set; }
        public Body body { get; set; }
    }

    public class Headers
    {
        public string CacheControl { get; set; }
        public string Vary { get; set; }
        public string SetCookie { get; set; }
        public string xmsservicerequestid { get; set; }
        public string StrictTransportSecurity { get; set; }
        public string REQ_ID { get; set; }
        public string CRMServiceId { get; set; }
        public string AuthActivityId { get; set; }
        public string xmsdophint { get; set; }
        public string xmsratelimittimeremainingxrmrequests { get; set; }
        public string xmsratelimitburstremainingxrmrequests { get; set; }
        public string misecorrelationid { get; set; }
        public string XContentTypeOptions { get; set; }
        public string ODataVersion { get; set; }
        public string PreferenceApplied { get; set; }
        public string XSource { get; set; }
        public string Public { get; set; }
        public string Date { get; set; }
        public string Allow { get; set; }
        public string ContentType { get; set; }
        public string Expires { get; set; }
        public string ContentLength { get; set; }
    }

    public class Body
    {
        public string odatacontext { get; set; }
        public int MicrosoftDynamicsCRMtotalrecordcount { get; set; }
        public bool MicrosoftDynamicsCRMtotalrecordcountlimitexceeded { get; set; }
        public string MicrosoftDynamicsCRMglobalmetadataversion { get; set; }
        public string ahODataCommunityDisplayV1CurrentEntityField { get; set; }

        [DataMember(Name = "value")]
        public Valor[] valor { get; set; }
    }

    public class Valor
    {
        public string odataetag { get; set; }
        public string ownerid { get; set; }
        public string _businessunitid_valueODataCommunityDisplayV1FormattedValue { get; set; }
        public string _businessunitid_valueMicrosoftDynamicsCRMassociatednavigationproperty { get; set; }
        public string _businessunitid_valueMicrosoftDynamicsCRMlookuplogicalname { get; set; }
        public string _businessunitid_value { get; set; }
        public string fullname { get; set; }
        public string systemuserid { get; set; }
        public string mcs_rut { get; set; }
        public string title { get; set; }
        public string domainname { get; set; }
    }
}