﻿extern alias GComponents;

using GComponents::Axxon.GlobalComponents.Helper;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;
using Plugin.ApiIntegration.Ofertas.Contract;
using Plugin.ApiIntegration.Ofertas.Service;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class OfertaSAE : Oferta, IPlantillaProducto
    {
        public List<DataSAE> data { get; set; }
        public List<Plantilla> GetProducto(Producto producto, PluginContext ctx)
        {
            List<Plantilla> lista = new List<Plantilla>();
            foreach (var oferta in this.data)
            {

                ctx.Trace($"oferta: {JsonSerializer.Serialize(oferta)}");

                var tarjeta = ctx.CachedEntities.GetProductByCodigoLogo(oferta.logo.codigo);
                ctx.Trace($"tarjeta: {JsonSerializer.Serialize(tarjeta)}");

                string logo = $"{producto.Nombre} {tarjeta.Name}";
                ctx.Trace($"logo: {logo}");

                string idcard = $"{logo}{DateTime.Now.Ticks + oferta.id_oferta.ToString()}";
                ctx.Trace($"idcard: {idcard}");

                string json = producto.Selecionable ? JsonSerializer.Serialize<OfertaSelecionada>(ToOfertaSelecionada(oferta, producto, ctx)) :
                JsonSerializer.Serialize<GComponents::Axxon.GlobalComponents.Model.Oferta>(ToOfertaSimulada(oferta, producto));

                ctx.Trace($"json: {json}");

                try
                {
                    ctx.Trace($"plantilla - get logo");
                    producto.Logo = tarjeta.Logo;
                }
                catch (Exception ex)
                {
                    ctx.Trace($"plantilla - get logo {ex.Message}");
                }
                ctx.Trace($"plantilla json: " + json);
                lista.Add(new Plantilla()
                {
                    Selecionable = producto.Selecionable,
                    Simulable = producto.Simulable,
                    HTML = PlantillaHelper.Card(Gebody(oferta, producto), logo, idcard, producto),
                    Id = $"{producto.Id}Super avance",
                    JSON = json
                });

            }
            return lista;
        }
        public List<Plantilla> GetProductoOfertaEspecial(Producto producto, string rutPersona, PluginContext ctx)
        {
            List<Plantilla> lista = new List<Plantilla>();
            foreach (var oferta in this.data)
            {

                ctx.Trace($"oferta: {JsonSerializer.Serialize(oferta)}");

                var tarjeta = ctx.CachedEntities.GetProductByCodigoLogo(oferta.logo.codigo);
                ctx.Trace($"tarjeta: {JsonSerializer.Serialize(tarjeta)}");

                Entity ofertaEspecial = ObtenerOfertaEspecial(rutPersona, Guid.Parse(producto.Id), ctx);

                string mensajeOfertaEspecial = ofertaEspecial != default && ofertaEspecial.Contains("axx_mensajepersonalizado") 
                                                ? $" - {ofertaEspecial.GetAttributeValue<string>("axx_mensajepersonalizado")}"
                                                : string.Empty;
                string logo = $"{producto.Nombre} {tarjeta.Name}{mensajeOfertaEspecial}";
                ctx.Trace($"logo: {logo}");

                string idcard = $"{logo}{DateTime.Now.Ticks + oferta.id_oferta.ToString()}";
                ctx.Trace($"idcard: {idcard}");

                string json = producto.Selecionable ? JsonSerializer.Serialize<OfertaSelecionada>(ToOfertaSelecionada(oferta, producto, ctx)) :
                JsonSerializer.Serialize<GComponents::Axxon.GlobalComponents.Model.Oferta>(ToOfertaSimulada(oferta, producto));

                ctx.Trace($"json: {json}");

                try
                {
                    ctx.Trace($"plantilla - get logo");
                    producto.Logo = tarjeta.Logo;
                }
                catch (Exception ex)
                {
                    ctx.Trace($"plantilla - get logo {ex.Message}");
                }
                ctx.Trace($"plantilla json: " + json);
                lista.Add(new Plantilla()
                {
                    Selecionable = producto.Selecionable,
                    Simulable = producto.Simulable,
                    HTML = PlantillaHelper.Card(Gebody(oferta, producto), logo, idcard, producto),
                    Id = $"{producto.Id}Super avance",
                    JSON = json
                });

            }
            return lista;
        }
        public string Gebody(DataSAE data, Producto producto)
        {
            char caracter = '"';
            string input = string.Empty;  
            return $@"
                <input type={caracter}hidden{caracter} data-back={caracter}{producto.Id}Super avance{caracter}>
                <div class={caracter}row text-monto{caracter}>
                    <div class={caracter}col-5{caracter}>Monto</div>
                    <div class={caracter}col-7{caracter}>{data.monto.ToString("C", new CultureInfo("es-CL"))}</div>
                </div>
                <div class={caracter}row{caracter}>
                    <div class={caracter}col-5{caracter}>Vigencia</div>
                    <div class={caracter}col-7{caracter}>{Convert.ToDateTime(data.vigencia.fecha_hasta):dd-MM-yyyy}</div>
                </div>";
        }
        public OfertaSelecionada ToOfertaSelecionada(DataSAE data, Producto producto, PluginContext ctx)
        {
            OfertaSelecionada oferta = new OfertaSelecionada();
            oferta.numero_cuenta = null;
            oferta.codigo = int.Parse(producto.Codigo);
            oferta.id_oferta = data.id_oferta;
            //Monto
            Monto monto = new Monto()
            {
                moneda = "CLP",
                simbolo = "$",
                valor = data.monto
            };
            oferta.monto = monto;
            oferta.descripcion = string.Empty;
            oferta.producto = $"{producto.Nombre} {ctx.CachedEntities.GetProductByCodigoLogo(data.logo.codigo).Name}";
            oferta.id_producto = int.Parse(producto.Codigo);
            oferta.requiere_simulacion = producto.Simulable;
            oferta.tipo_oferta = !string.IsNullOrEmpty(producto.ER) ? "PRE-APROBADA" : "APROBADA";
            oferta.categorizacion_afinidad = false;
            oferta.id_activo = data.id_cuenta;
            oferta.fecha_inicio = oferta.fecha_inicio;
            oferta.fecha_fin = oferta.fecha_fin;
            oferta.seleccionable = producto.Selecionable;
            //Cupo
            CupoTotalCuenta cupototal = new CupoTotalCuenta()
            {
                moneda = "CLP",
                simbolo = "",
                valor = null
            };
            oferta.cupo_total_cuenta = cupototal;
            oferta.traspaso_tarjeta_cerrada = false;
            oferta.productId = producto.Id.ToString();
            oferta.propiedades = new List<string>();
            oferta.url_servicio_simulacion = "axx_ApiIntegracion.Simulacion.SimulacionSae";
            return oferta;
        }

        public GComponents::Axxon.GlobalComponents.Model.Oferta ToOfertaSimulada(DataSAE data, Producto producto)
        {
            GComponents::Axxon.GlobalComponents.Model.Oferta oferta = new GComponents::Axxon.GlobalComponents.Model.Oferta();
            oferta.numero_cuenta = "";
            oferta.codigo = producto.Codigo;
            oferta.id_oferta = data.id_oferta.ToString();
            //Monto
            GComponents::Axxon.GlobalComponents.Model.Currency monto = new GComponents::Axxon.GlobalComponents.Model.Currency()
            {
                moneda = "CLP",
                simbolo = "$",
                valor = int.Parse(data.monto.ToString())
            };
            oferta.monto = monto;
            oferta.descripcion = string.Empty;
            oferta.producto = $"{producto.Nombre} {data.logo.descripcion}";
            oferta.id_producto = producto.Codigo;
            //oferta.requiere_simulacion = producto.Simulable;
            oferta.tipo_oferta = !string.IsNullOrEmpty(producto.ER) ? "PRE-APROBADA" : "APROBADA";
            oferta.categorizacion_afinidad = false;
            oferta.id_activo = data.id_cuenta.ToString();
            oferta.fecha_inicio = oferta.fecha_inicio;
            oferta.fecha_fin = oferta.fecha_fin;
            //oferta.seleccionable = producto.Selecionable;
            //Cupo
            GComponents::Axxon.GlobalComponents.Model.Currency cupototal = new GComponents::Axxon.GlobalComponents.Model.Currency()
            {
                moneda = "CLP",
                simbolo = "",
                valor = null
            };
            oferta.cupo_total_cuenta = cupototal;
            //oferta.traspaso_tarjeta_cerrada = false;
            oferta.productId = Guid.Parse(producto.Id);
            //oferta.propiedades = new List<string>();
            return oferta;
        }


        public Entity ObtenerOfertaEspecial(string rut, Guid productoId, PluginContext ctx)
        {
            QueryExpression queryOfertasEspeciales = new QueryExpression("axx_ofertaespecial");
            queryOfertasEspeciales.ColumnSet = new ColumnSet("axx_mensajepersonalizado");
            queryOfertasEspeciales.Criteria.AddCondition("axx_producto", ConditionOperator.Equal, productoId);
            queryOfertasEspeciales.Criteria.AddCondition("axx_rutdelcliente", ConditionOperator.Equal, rut);
            queryOfertasEspeciales.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);

            return ctx.Service.RetrieveMultiple(queryOfertasEspeciales).Entities.FirstOrDefault();
        }

    }
    public class DataSAE
    {
        public int id_oferta { get; set; }
        public int id_cuenta { get; set; }
        public int monto { get; set; }
        public Vigencia vigencia { get; set; }
        public Logo logo { get; set; }
    }

    public class Vigencia
    {
        public string fecha_desde { get; set; }
        public string fecha_hasta { get; set; }
        public string periodo_vigencia { get; set; }
    }
}