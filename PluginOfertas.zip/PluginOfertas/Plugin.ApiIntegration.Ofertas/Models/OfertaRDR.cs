﻿extern alias GComponents;

using GComponents::Axxon.GlobalComponents.Helper;
using GComponents::Axxon.GlobalComponents.Model;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Org.BouncyCastle.Asn1.Ocsp;
using Org.BouncyCastle.Crypto.Tls;
using Plugin.ApiIntegration.Ofertas.Contract;
using Plugin.ApiIntegration.Ofertas.Service;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class OfertaRDR : IPlantillaProducto
    {
        public DataRDR data { get; set; }
        public string Gebody(DataRDR data, Producto producto, PluginContext ctx)
        {

            char caracter = '"';
            string input = string.Empty;
            return $@"
                  <input type={caracter}hidden{caracter} data-back={caracter}{producto.Nombre}{caracter}>
                   <div class={caracter}row text-monto{caracter}>
                       <div class={caracter}col-5{caracter}>Deuda Total</div>
                       <div class={caracter}col-7{caracter}>{(data.monto_total_deudas.HasValue ? Convert.ToInt32(data.monto_total_deudas).ToString("C", new CultureInfo("es-CL")) : "0")}</div>
                   </div>
                    <div class={caracter}row{caracter} id=div{data.id_tarjeta}_{data.deuda_linea_uno}>
                        <div class={caracter}col-5{caracter}>Línea 1:</div>
                        <div class={caracter}col-7{caracter}>{(data.deuda_linea_uno.HasValue ? Convert.ToInt32(data.deuda_linea_uno).ToString("C", new CultureInfo("es-CL")) : "0")}</div>
                  </div>
                  <div class={caracter}row{caracter} id=div{data.id_tarjeta}_{data.deuda_linea_dos}>
                        <div class={caracter}col-5{caracter}>Línea 2:</div>
                        <div class={caracter}col-7{caracter}>{(data.deuda_linea_dos.HasValue ? Convert.ToInt32(data.deuda_linea_dos).ToString("C", new CultureInfo("es-CL")) : "0")}</div>
                  </div>";

        }
        public List<Plantilla> GetProducto(Producto producto, PluginContext ctx)
        {
            ctx.Trace($"GetProducto");
            Product productoEntidad = new Product();
            if (data.titulo == "Repactacion")
            {
                ctx.Trace($"producto: " + data.titulo);
                productoEntidad = ctx.CachedEntities.GetProductByProductNumber("10001");
            }

            if (data.titulo == "Renegociación")
            {
                ctx.Trace($"producto: " + data.titulo);
                productoEntidad = ctx.CachedEntities.GetProductByProductNumber("10002");
            }
            string guidCliente = (string)ctx.Context.InputParameters["Api_ApiIntegration_Ofertas_PlantillaProducto_In_GuidCliente"];
            User usuario = ctx.CachedEntities.GetUser(ctx.Context.InitiatingUserId);
            Client cliente = ctx.CachedEntities.GetClient(new Guid(guidCliente), true);

            //Obtiene los productos seguros
            ctx.Trace($"ObtenerProductoSeguros: idcliente: " + cliente.IdCliente + " - Producto Codigo: " + productoEntidad.Codigo + " - Canal Codigo: " + usuario.Canal.Codigo);
            string jsonProductos = ObtenerProductoSeguros("Axx_Api.ApiIntegracion.SimuladorProducto", ctx, cliente.IdCliente, productoEntidad.Codigo, usuario.Canal.Codigo);

            ProductoSegurosResponse ResponseProductoSeguros = JsonSerializer.Deserialize<ProductoSegurosResponse>(jsonProductos);

            ctx.Trace($" seleccionable ---------> {ctx.CachedEntities.ProductoSucursal(productoEntidad.ProductId, ctx.Context.UserId).Seleccionable} ");
            producto.Selecionable = ctx.CachedEntities.ProductoSucursal(productoEntidad.ProductId, ctx.Context.UserId).Seleccionable;
            producto.Simulable = productoEntidad.RequiereSimulacion;
            producto.Codigo = productoEntidad.ProductNumber;
            producto.Nombre = productoEntidad.Name;
            producto.Id = productoEntidad.ProductId.ToString();

            List<Plantilla> lista = new List<Plantilla>();
            if (data != null)
            {
                ctx.Trace($"ingresa a la oferta seleccionada");
                string idcard = producto.Nombre + Guid.NewGuid().ToString().Replace("-", "");
                string logo = producto.Nombre;
                string json = JsonSerializer.Serialize<OfertaSelecionada>(ToOfertaSeleccionada(ctx, data, ResponseProductoSeguros, producto, cliente, usuario));
                lista.Add(new Plantilla()
                {
                    Selecionable = producto.Selecionable,
                    Simulable = producto.Simulable,
                    HTML = PlantillaHelper.Card(Gebody(data, producto, ctx), logo, idcard, producto),
                    Id = $"{producto.Nombre}",
                    JSON = json
                });
                ctx.Trace($"json to front: " + json);
            }
            return lista;
        }
        public List<Plantilla> GetProductoOfertaEspecial(Producto producto, string rutPersona, PluginContext ctx)
        {
            ctx.Trace($"GetProducto");
            Product productoEntidad = new Product();
            if (data.titulo == "Repactacion")
            {
                ctx.Trace($"producto: " + data.titulo);
                productoEntidad = ctx.CachedEntities.GetProductByProductNumber("10001");
            }

            if (data.titulo == "Renegociación")
            {
                ctx.Trace($"producto: " + data.titulo);
                productoEntidad = ctx.CachedEntities.GetProductByProductNumber("10002");
            }
            string guidCliente = (string)ctx.Context.InputParameters["Api_ApiIntegration_Ofertas_PlantillaProducto_In_GuidCliente"];
            User usuario = ctx.CachedEntities.GetUser(ctx.Context.InitiatingUserId);
            Client cliente = ctx.CachedEntities.GetClient(new Guid(guidCliente), true);

            //Obtiene los productos seguros
            ctx.Trace($"ObtenerProductoSeguros: idcliente: " + cliente.IdCliente + " - Producto Codigo: " + productoEntidad.Codigo + " - Canal Codigo: " + usuario.Canal.Codigo);
            string jsonProductos = ObtenerProductoSeguros("Axx_Api.ApiIntegracion.SimuladorProducto", ctx, cliente.IdCliente, productoEntidad.Codigo, usuario.Canal.Codigo);

            ProductoSegurosResponse ResponseProductoSeguros = JsonSerializer.Deserialize<ProductoSegurosResponse>(jsonProductos);

            ctx.Trace($" seleccionable ---------> {ctx.CachedEntities.ProductoSucursal(productoEntidad.ProductId, ctx.Context.UserId).Seleccionable} ");
            producto.Selecionable = ctx.CachedEntities.ProductoSucursal(productoEntidad.ProductId, ctx.Context.UserId).Seleccionable;
            producto.Simulable = productoEntidad.RequiereSimulacion;
            producto.Codigo = productoEntidad.ProductNumber;
            producto.Nombre = productoEntidad.Name;
            producto.Id = productoEntidad.ProductId.ToString();

            List<Plantilla> lista = new List<Plantilla>();
            if (data != null)
            {
                ctx.Trace($"ingresa a la oferta seleccionada");
                string idcard = producto.Nombre + Guid.NewGuid().ToString().Replace("-", "");

                ctx.Trace($"Obteniendo oferta especial");
                Entity ofertaEspecial = ObtenerOfertaEspecial(rutPersona, Guid.Parse(producto.Id), ctx);
                ctx.Trace($"Encontro oferta especial?: {ofertaEspecial != default}");
                string mensajeOfertaEspecial = ofertaEspecial != default && ofertaEspecial.Contains("axx_mensajepersonalizado")
                                                ? $" - {ofertaEspecial.GetAttributeValue<string>("axx_mensajepersonalizado")}"
                                                : string.Empty;
                ctx.Trace($"mensajeOfertaEspecial: {mensajeOfertaEspecial}");

                string logo = $"{producto.Nombre}{mensajeOfertaEspecial}";
                string json = JsonSerializer.Serialize<OfertaSelecionada>(ToOfertaSeleccionada(ctx, data, ResponseProductoSeguros, producto, cliente, usuario));
                lista.Add(new Plantilla()
                {
                    Selecionable = producto.Selecionable,
                    Simulable = producto.Simulable,
                    HTML = PlantillaHelper.Card(Gebody(data, producto, ctx), logo, idcard, producto),
                    Id = $"{producto.Nombre}",
                    JSON = json
                });
                ctx.Trace($"json to front: " + json);
            }
            return lista;
        }
        public OfertaSelecionada ToOfertaSeleccionada(PluginContext ctx, DataRDR data, ProductoSegurosResponse ProductoSeguros, Producto producto, Client Cliente, User Usuario)
        {
            ctx.Trace($"To Oferta Seleccionada");
            string nombreLogo = ctx.CachedEntities.GetProductByCodigoLogo(data.logo).Name;
            OfertaSelecionada oferta = new OfertaSelecionada();
            ReneRepa objetoReneRepa = new ReneRepa();
            Monto deuda_linea_dos = new Monto()
            {
                moneda = "CLP",
                simbolo = "$",
                valor = data.deuda_linea_dos
            };
            objetoReneRepa.deuda_linea_dos = deuda_linea_dos;
            Monto deuda_linea_uno = new Monto()
            {
                moneda = "CLP",
                simbolo = "$",
                valor = data.deuda_linea_uno
            };
            objetoReneRepa.deuda_linea_uno = deuda_linea_uno;
            objetoReneRepa.tramo_mora = data.tramo_mora;
            objetoReneRepa.plan_cobranza = data.plan_cobranza;
            objetoReneRepa.dias_mora = data.dias_mora;
            objetoReneRepa.afinidad = data.afinidad;
            Monto pie = new Monto()
            {
                moneda = "CLP",
                simbolo = "$",
                valor = data.pie
            };
            objetoReneRepa.pie = pie;
            Monto monto_total_deudas = new Monto()
            {
                moneda = "CLP",
                simbolo = "$",
                valor = data.monto_total_deudas
            };
            objetoReneRepa.monto_total_deudas = monto_total_deudas;
            objetoReneRepa.titulo = data.titulo;
            objetoReneRepa.meses_gracia = data.meses_gracia;
            objetoReneRepa.id_tarjeta = data.id_tarjeta;
            objetoReneRepa.logo = data.logo;
            objetoReneRepa.descripcion_producto = data.descripcion_producto;
            ctx.Trace($"1");
            objetoReneRepa.numero_cuenta_ofuscado = data.numero_cuenta_ofuscado;
            ctx.Trace($"2");
            objetoReneRepa.numero_tarjeta_ofuscado = data.numero_tarjeta_ofuscado;
            objetoReneRepa.tipo_producto = data.tipo_producto;
            oferta.id_oferta = null;
            oferta.id_canal = Usuario.Canal.Codigo;
            oferta.producto = $"{producto?.Nombre}";
            oferta.id_producto = int.Parse(producto.Codigo);
            oferta.requiere_simulacion = producto.Simulable;
            oferta.tipo_oferta = !string.IsNullOrEmpty(producto.ER) ? "PRE-APROBADA" : "APROBADA";
            oferta.seleccionable = producto.Selecionable;
            oferta.productId = producto.Id;            
            objetoReneRepa.rut_cliente = Cliente.NumeroIdentificacion;
            objetoReneRepa.nombre_cliente = Cliente.Name.Trim();
            ctx.Trace($"Previo ObtenerCuotaSugerida");
            objetoReneRepa.simulacion_cuotas = ObtenerCuotaSugerida(producto.Id, data.monto_total_deudas.Value, ctx);
            objetoReneRepa.ip_cliente = "127.0.0.1";
            objetoReneRepa.nombre_logo = ctx.CachedEntities.GetProductByCodigoLogo(data.logo).Name;
            Monto pie_ejecutivo = new Monto()
            {
                moneda = "CLP",
                simbolo = "$",
                valor = data.pie
            };
            objetoReneRepa.tasa_ejecutivo = 0;
            oferta.ofertaRdr = objetoReneRepa;
            objetoReneRepa.ProductoSeguros = ProductoSeguros;
            var configProductos = ObtenerCuotaMinMax(producto.Id, ctx);
            if (configProductos != null)
            {
                objetoReneRepa.cuota_maxima = configProductos.GetAttributeValue<int>("mcs_cuotamximadelproducto");
                objetoReneRepa.cuota_minima = configProductos.GetAttributeValue<int>("mcs_cuotaminimadelproducto");
            }

            return oferta;

            //nombrePersona
            //Rut
        }

        private string ObtenerProductoSeguros(string nombreCustomAPI, PluginContext ctx, string codCliente, string codProducto, string canalUsuario)
        {
            //"Axx_Api.ApiIntegracion.SimuladorProducto"            
            OrganizationRequest request = new OrganizationRequest(nombreCustomAPI);
            string responseName = "Response";

            request.Parameters.Add("Id_Cliente", codCliente.ToString());
            request.Parameters.Add("Id_Producto", codProducto.ToString());
            request.Parameters.Add("Id_Canal", canalUsuario.ToString());

            OrganizationResponse organizationResponse = ctx.Service.Execute(request);
            ctx.Trace($"return producto Seguros: " + organizationResponse.Results[responseName].ToString());

            return organizationResponse.Results[responseName].ToString();
        }


        public int ObtenerCuotaSugerida(string productId, int montoTotalDeudas, PluginContext ctx)
        {
            var query = new QueryExpression("mcs_configuraciondecuotasportramo");
            query.ColumnSet.AllColumns = true;
            query.Criteria.AddCondition("axx_productocat", ConditionOperator.Equal, productId);
            query.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);

            EntityCollection cuotasTramo = ctx.Service.RetrieveMultiple(query);

            int cuotaSugerida = 0;
            decimal minimo = 0;
            decimal maximo = 0;

            if (cuotasTramo.Entities.Count > 0)
            {
                foreach (Entity tramo in cuotasTramo.Entities)
                {
                    if (tramo.Contains("mcs_montominimo") && tramo.Contains("mcs_montomaximo"))
                    {
                        ctx.Trace($"Minimo y Maximo: " + cuotaSugerida);
                        minimo = ((Money)tramo.Attributes["mcs_montominimo"]).Value;
                        maximo = ((Money)tramo.Attributes["mcs_montomaximo"]).Value;

                        if (montoTotalDeudas > minimo && montoTotalDeudas < maximo)
                        {
                            if (tramo.Contains("mcs_cuotasugerida"))
                            {
                                cuotaSugerida = Convert.ToInt32(tramo["mcs_cuotasugerida"]);
                                ctx.Trace($"Cuota Sugerida: " + cuotaSugerida);
                                return cuotaSugerida;
                            }
                        }
                    }
                }

            }
            return cuotaSugerida;
        }

        public Entity ObtenerCuotaMinMax(string productId, PluginContext ctx)
        {

            var query = new QueryExpression("mcs_configuraciondecuotasportramo");
            query.ColumnSet = new ColumnSet("mcs_cuotaminimadelproducto", "mcs_cuotamximadelproducto");
            query.Criteria.AddCondition("axx_productocat", ConditionOperator.Equal, productId);
            query.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);

            EntityCollection cuotas = ctx.Service.RetrieveMultiple(query);
            if(cuotas.Entities.Count > 0)
            {
                var configProducto = cuotas.Entities.FirstOrDefault();
                return configProducto;
            }
            else
            {
                return null;
            }
        }

        public Entity ObtenerOfertaEspecial(string rut, Guid productoId, PluginContext ctx)
        {
            QueryExpression queryOfertasEspeciales = new QueryExpression("axx_ofertaespecial");
            queryOfertasEspeciales.ColumnSet = new ColumnSet("axx_mensajepersonalizado");
            queryOfertasEspeciales.Criteria.AddCondition("axx_producto", ConditionOperator.Equal, productoId);
            queryOfertasEspeciales.Criteria.AddCondition("axx_rutdelcliente", ConditionOperator.Equal, rut);
            queryOfertasEspeciales.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);

            return ctx.Service.RetrieveMultiple(queryOfertasEspeciales).Entities.FirstOrDefault();
        }

        public class DataRDR
        {
            public string estado { get; set; }
            public int? id_cliente { get; set; }
            public string titulo { get; set; }
            public int? monto_total_deudas { get; set; }
            public int? meses_gracia { get; set; }
            public int? pie { get; set; }
            public int? id_tarjeta { get; set; }
            public string numero_cuenta_ofuscado { get; set; }
            public string numero_tarjeta_ofuscado { get; set; }
            public string tipo_producto { get; set; }
            public string descripcion_producto { get; set; }
            public string logo { get; set; }
            public string plan_cobranza { get; set; }
            public string afinidad { get; set; }
            public int? dias_mora { get; set; }
            public string tramo_mora { get; set; }
            public int? deuda_linea_uno { get; set; }
            public int? deuda_linea_dos { get; set; }
            public string code { get; set; }
            public string desc { get; set; }
            public bool? es_reintentable { get; set; }
        }
    }
}
