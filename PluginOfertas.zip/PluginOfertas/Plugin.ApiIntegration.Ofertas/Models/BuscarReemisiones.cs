﻿using System;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class BuscarReemisiones : ReemisionGenerica
    {
        public bool Seleccionado { get; set; }
        public int Indice { get; set; }
        public string Nombre_embozado { get; set; }
        public string Apellido_embozado { get; set; }
        public string Fecha_emision { get; set; }
        public string Fecha_activacion { get; set; }
        public string Fecha_bloqueo { get; set; }
        public bool PuntosCenco { get; set; }
        public Guid Solicitante { get; set; }
        public Guid TitularTarjetaGuid { get; set; }
        public Guid Sucursal { get; set; }
        public int SucursalId { get; set; }
        public string EjecutivoRut { get; set; }
    }
}

public class TiposMotivo
{
    public int Id { get; set; }
    public string CodigoMotivo { get; set; }
}

