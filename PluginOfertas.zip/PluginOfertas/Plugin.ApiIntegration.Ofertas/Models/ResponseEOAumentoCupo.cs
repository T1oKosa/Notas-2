﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class ResponseEOTarjetas
    {
        [JsonPropertyName("id")]
        public string id { get; set; }

        [JsonPropertyName("status")]
        public int status { get; set; }

        [JsonPropertyName("resource")]
        public string resource { get; set; }

        [JsonPropertyName("data")]
        public DataResponseEOTarjetas data { get; set; }

        [JsonPropertyName("metadata")]
        public MetadataResponseEOTarjetas metadata { get; set; }
    }

    public class DataResponseEOTarjetas
    {
        [JsonPropertyName("id_autorizacion")]
        public string id_autorizacion { get; set; }

        [JsonPropertyName("estado")]
        public EstadoResponseEOTarjetas estado { get; set; }

        [JsonPropertyName("oferta")]
        public OfertaResponseEOTarjetas oferta { get; set; }
    }

    public class EstadoResponseEOTarjetas
    {
        [JsonPropertyName("descripcion")]
        public string descripcion { get; set; }

        [JsonPropertyName("rechazos")]
        public List<RechazoResponseEOTarjetas> rechazos { get; set; }
    }

    public class OfertaResponseEOTarjetas
    {
        [JsonPropertyName("id")]
        public int id { get; set; }

        [JsonPropertyName("monto")]
        public int monto { get; set; }
    }
    public class RechazoResponseEOTarjetas
    {
        [JsonPropertyName("codigo")]
        public string codigo { get; set; }

        [JsonPropertyName("mensaje")]
        public string mensaje { get; set; }
    }

    public class MetadataResponseEOTarjetas
    {
        [JsonPropertyName("X-B3-SpanId")]
        public string XB3SpanId { get; set; }


        [JsonPropertyName("X-B3-TraceId")]
        public string XB3TraceId { get; set; }
    }
}
