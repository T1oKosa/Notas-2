﻿extern alias GComponents;

using GComponents::Axxon.GlobalComponents.Helper;
using Plugin.ApiIntegration.Ofertas.Contract;
using Plugin.ApiIntegration.Ofertas.Service;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class OfertasComplementaria : IPlantillaProducto
    {
        public int? maximo { get; set; }
        public int? pagina { get; set; }
        public int? cantidad_elementos { get; set; }
        public List<Contenido> data { get; set; }
        public int? cantidad_paginas { get; set; }
        public List<Plantilla> GetProducto(Producto producto, PluginContext ctx)
        {
            ctx.Trace("GetProducto");
            List<Plantilla> lista = new List<Plantilla>();
            ctx.Trace($"GetProducto - cantidad de contenido - {this.data.Count}");
            int contador = 0;
            List<string> numerosGUID = Utils.GeneraGuidListas(this.data.Count);
            foreach (var oferta in this.data)
            {
                try
                {
                    ctx.Trace($"GetProducto - oferta.codigo - {oferta.codigo}");
                    ctx.Trace($"GetProducto - oferta.producto - {oferta.producto}");
                    string idcard = $"{oferta.producto}{numerosGUID[contador]}";
                    string json = string.Empty;
                    contador++;

                    try
                    {
                        json = JsonSerializer.Serialize(oferta);

                    }
                    catch (Exception ex)
                    {
                        ctx.Trace($"Error al deserializar -> {ex.Message}");
                    }
                    try
                    {
                        ctx.Trace($"oferta.producto to lower: " + oferta.producto);
                        producto.Logo = CRMQueries.getLogo(ctx, parseGrupo(oferta.producto));

                    }
                    catch (Exception ex)
                    {
                        ctx.Trace($"Error get logo -> {ex.Message}");
                    }
                    producto.Selecionable = oferta.seleccionable;
                    ctx.Trace($"ID -> {idcard}");

                    Plantilla _plantilla = new Plantilla();
                    _plantilla.Id = idcard;
                    _plantilla.JSON = json;
                    _plantilla.Selecionable = oferta.seleccionable;
                    _plantilla.Simulable = producto.Simulable;
                    _plantilla.HTML = PlantillaHelper.Card(Gebody(oferta, producto), oferta.producto, idcard, producto);
                    lista.Add(_plantilla);
                }
                catch (Exception ex)
                {
                    ctx.Trace($"GetProducto - oferta.codigo - Error : {ex.Message}");
                }

            }

            return lista;
        }
        public string Gebody(Contenido data, Producto producto)
        {
            char caracter = '"';
            //var json_data = ToOferta(data, producto);
            //var input = JsonSerializer.Serialize<OfertaSelecionada>(json_data);
            Propiedade nro_cuenta = data.propiedades.FirstOrDefault(x => x.nombre == "nro_cuenta");
            Propiedade info_complementaria = data.propiedades.FirstOrDefault(x => x.nombre == "info_complementaria");
            string ntar = nro_cuenta != null ? nro_cuenta.valor : "s/n";
            string nombresubdetalle = data.tipo_producto == "SEGURO" ? "UF" : "Detalle";
            string valorsubdetalle = data.tipo_producto == "SEGURO" ? info_complementaria?.valor : data.descripcion;
            return $@"
                <div class={caracter}row text-monto{caracter}>
                    <div class={caracter}col-5{caracter}>N. de cuenta</div>
                    <div class={caracter}col-7{caracter}>{ntar}</div>
                </div>
                <div class={caracter}row{caracter}>
                    <div class={caracter}col-5{caracter}>{nombresubdetalle}</div>
                    <div class={caracter}col-7{caracter}>{valorsubdetalle}</div>
                </div>";
        }
        public OfertaSelecionada ToOferta(Contenido data, Producto producto, PluginContext ctx)
        {
            ctx.Trace("Generando Oferta xx");
            OfertaSelecionada oferta = new OfertaSelecionada();
            ctx.Trace("Generando Oferta xx- step 1 ");
            oferta.numero_cuenta = "";
            ctx.Trace("Generando Oferta xx- step 2 ");
            oferta.codigo = !string.IsNullOrEmpty(data.producto) ? int.Parse(data.codigo) : 0;
            ctx.Trace("Generando Oferta xx- step 3 ");
            oferta.id_oferta = !string.IsNullOrEmpty(data.id_oferta.ToString()) ? data.id_oferta : 0;
            ctx.Trace("Generando Oferta xx- step 4 ");
            //Monto
            Monto monto = new Monto()
            {
                moneda = "CLP",
                simbolo = "$",
                valor = 0
            };
            ctx.Trace("Generando Oferta xx- step 5 ");
            oferta.monto = monto;
            ctx.Trace("Generando Oferta xx- step 6 ");
            oferta.descripcion = data.descripcion;
            ctx.Trace("Generando Oferta xx- step 7 ");
            oferta.producto = data.producto;
            ctx.Trace("Generando Oferta xx- step 8 ");
            oferta.id_producto = int.Parse(data.codigo);
            ctx.Trace("Generando Oferta xx- step 9 ");
            oferta.requiere_simulacion = producto.Simulable;
            ctx.Trace("Generando Oferta xx- step 10 ");
            oferta.tipo_oferta = data.tipo_oferta;
            ctx.Trace("Generando Oferta xx- step 11 ");
            oferta.categorizacion_afinidad = false;
            ctx.Trace("Generando Oferta xx- step 12 ");
            oferta.id_activo = data.id_activo;
            ctx.Trace("Generando Oferta xx- step 13 ");
            oferta.fecha_inicio = data.fecha_inicio;
            ctx.Trace("Generando Oferta xx- step 14 ");
            oferta.fecha_fin = data.fecha_fin;
            ctx.Trace("Generando Oferta xx- step 15 ");
            oferta.seleccionable = data.seleccionable;
            ctx.Trace("Generando Oferta xx- step 16 ");

            //Cupo
            CupoTotalCuenta cupototal = new CupoTotalCuenta()
            {
                moneda = data.monto.moneda,
                simbolo = data.monto.simbolo,
                valor = (int?)data.monto.valor
            };
            ctx.Trace("Generando Oferta xx- step 17 ");
            oferta.cupo_total_cuenta = cupototal;
            ctx.Trace("Generando Oferta xx- step 18 ");
            oferta.traspaso_tarjeta_cerrada = false;
            ctx.Trace("Generando Oferta xx- step 19 ");
            oferta.productId = producto.Id.ToString();
            ctx.Trace("Generando Oferta xx- step 20 ");
            oferta.propiedades = new List<string>();
            ctx.Trace("Generando: obtener numero de tarjeta ");
            Propiedade numero_tarjeta_data = data.propiedades.FirstOrDefault(x => x.nombre == "nro_tarjeta_asegurado");
            oferta.numero_tarjeta = numero_tarjeta_data != null ? numero_tarjeta_data.valor : "s/n";
            ctx.Trace($"Generando Oferta 3 -> {JsonSerializer.Serialize(oferta)}");
            return oferta;
        }

        private int parseGrupo(string titulo)
        {
            int logo = 99;
            if (titulo.ToLower().Contains("mastercard"))
            {
                logo = 1;
            }
            if (titulo.ToLower().Contains("platinum"))
            {
                logo = 2;
            }
            if (titulo.ToLower().Contains("black"))
            {
                logo = 3;
            }
            if (titulo.ToLower().Contains("visa"))
            {
                logo = 0;
            }
            return logo;
        }
    }
    public class Contenido
    {
        public string codigo { get; set; }
        public string producto { get; set; }
        public string descripcion { get; set; }
        public bool seleccionable { get; set; }
        public string numero_producto { get; set; }
        public int? id_oferta { get; set; }
        public string tipo_oferta { get; set; }
        public int? id_activo { get; set; }
        public Monto2 monto { get; set; }
        public object fecha_inicio { get; set; }
        public object fecha_fin { get; set; }
        public List<Propiedade> propiedades { get; set; }
        public string tipo_producto { get; set; }
    }
    public class Propiedade
    {
        public string nombre { get; set; }
        public string valor { get; set; }
    }
    public class Monto2
    {
        public double? valor { get; set; }
        public string moneda { get; set; }
        public string simbolo { get; set; }
    }

}