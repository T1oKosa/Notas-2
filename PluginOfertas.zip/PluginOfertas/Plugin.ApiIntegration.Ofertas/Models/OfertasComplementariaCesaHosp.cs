﻿extern alias GComponents;

using GComponents::Axxon.GlobalComponents.Helper;
using GComponents::Axxon.GlobalComponents.Model;
using Microsoft.Xrm.Sdk;
using Newtonsoft.Json;
using Plugin.ApiIntegration.Ofertas.Contract;
using Plugin.ApiIntegration.Ofertas.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Activities.Statements;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class OfertasComplementariaCesaHosp : IPlantillaProducto
    {
        public List<DataComplementariaCesaHosp> data { get; set; }

        public List<Plantilla> GetProducto(Producto producto, PluginContext ctx)
        {
            int contador = 0;
            List<Plantilla> lista = new List<Plantilla>();
            List<string> numerosGUID = Utils.GeneraGuidListas(this.data.Count);

            string guidCliente = (string)ctx.Context.InputParameters["Api_ApiIntegration_Ofertas_PlantillaProducto_In_GuidCliente"];
            ctx.Trace($"ofertas-compCesaHosp - getproducto - guidCliente: {guidCliente}");
            HandleObtenerActividadLaboral(ctx, guidCliente);

            foreach (var oferta in this.data)
            {
                try
                {
                    oferta.codigo = oferta.cod_producto;
                    oferta.producto = oferta.tipo_seguro;
                    oferta.monto = new Monto2();
                    oferta.seleccionable = true;
                    oferta.tipo_oferta = "APROBADA";

                    ctx.Trace($"GetProducto - oferta.producto - {oferta.producto}");
                    string idcard = $"{oferta.producto}{numerosGUID[contador]}";
                    string json = string.Empty;

                    Product seguro = ctx.CachedEntities.GetProductByCodigo(oferta.codigo);
                    ctx.Trace($"GetProducto - oferta.codigo - {oferta.codigo}");

                    contador++;

                    try
                    {
                        json = System.Text.Json.JsonSerializer.Serialize(oferta);

                    }
                    catch (Exception ex)
                    {
                        ctx.Trace($"Error al deserializar -> {ex.Message}");
                    }

                    producto.Selecionable = true;
                    ctx.Trace($"ID -> {idcard}");

                    Plantilla _plantilla = new Plantilla();
                    _plantilla.Id = idcard;
                    _plantilla.JSON = json;
                    _plantilla.Selecionable = true;
                    _plantilla.Simulable = producto.Simulable;
                    ctx.Trace($"GetProducto - creacion card - {oferta.codigo}");
                    _plantilla.HTML = PlantillaHelper.Card(GetBody(oferta, seguro), oferta.producto, idcard, producto);
                    lista.Add(_plantilla);

                }
                catch (Exception ex)
                {
                    ctx.Trace($"GetProducto - oferta.codigo - Error : {ex.Message}");
                }
            }

            return lista;
        }

        public List<Plantilla> GetProductoSinActividad(PluginContext ctx)
        {
            List<Plantilla> lista = new List<Plantilla>();
            string guidCliente = (string)ctx.Context.InputParameters["Api_ApiIntegration_Ofertas_PlantillaProducto_In_GuidCliente"];

            try
            {
                //Entity actividad = CRMQueries.GetActividadLaboral(ctx, guidCliente);

                string idcard = $"CesaHosp{Utils.GeneraGuidAleatorio()}";
                string json = "{}";
                string titulo = "Seguro de Cesantía/Hospitalización";

                Plantilla _plantilla = new Plantilla();
                _plantilla.Id = idcard;
                ctx.Trace($"GetProductoSinActividad {idcard}");

                _plantilla.JSON = json;
                _plantilla.Selecionable = false;
                _plantilla.Simulable = false;
                //string actividadLab = actividad?.GetAttributeValue<EntityReference>("mcs_ocupacionid")?.Name ?? "Indefinido";
                ctx.Trace($"GetProductoSinActividad Indefinido");
                _plantilla.HTML = PlantillaHelper.CardComplementariaSinActividad(GetBody("Indefinido", guidCliente.ToString()), titulo, idcard);
                lista.Add(_plantilla);
            }
            catch (Exception ex)
            {
                ctx.Trace($"GetProductoSinActividad {ex.Message}");
            }


            return lista;

        }

        public string GetBody(DataComplementariaCesaHosp data, Product product)
        {
            char caracter = '"';
            string actividad = char.ToUpper(data.tipo_actividad_laboral[0]) + data.tipo_actividad_laboral.Substring(1).ToLower();
            string nroCuenta = data.GetPropiedad("nro_cuenta");

            return $@"
                <div class={caracter}row text-monto{caracter}>
                    <div class={caracter}col-5{caracter}>N. de cuenta</div>
                    <div class={caracter}col-7{caracter}>{nroCuenta}</div>
                </div>
                <div class={caracter}row{caracter}>
                    <div class={caracter}col-5{caracter}>UF</div>
                    <div class={caracter}col-7{caracter}>Prima mensual {product.PrecioUF}</div>
                </div>
                <div class={caracter}row{caracter}>
                    <div class={caracter}col-5{caracter}>Actividad Laboral</div>
                    <div class={caracter}col-7{caracter}>{actividad}</div>
                </div>";
        }

        public string GetBody(string actividad, string idCliente)
        {
            char caracter = '"';

            return $@"
                <div>
                    <div>Para revisar una oferta, necesitamos contar con información de la actividad laboral.</div>
                </div>
                <div class={caracter}row text-actividad{caracter}>
                    <div class={caracter}col-6{caracter}>Actividad Laboral</div>
                    <span class={caracter}col-6{caracter}>{actividad}</span>
                </div>
                <div class={caracter}nav-actividad{caracter}>
                    <a class={caracter}link-actividad{caracter} data-id={caracter}{idCliente}{caracter}>Actualizar actividad laboral</a>
                </div>
";
        }

        public void HandleObtenerActividadLaboral(PluginContext ctx, string guidCliente)
        {
            int reintento = 0;
            int maxIntentos = 20;
            int delay = 1000;
            EntityCollection actividad = null;

            while (reintento < maxIntentos)
            {
                actividad = CRMQueries.GetActividadLaboral(ctx, guidCliente);

                if(actividad.Entities.Count > 0) break;

                System.Threading.Thread.Sleep(delay);
                reintento++;
            }
            if(actividad == null) throw new Exception("Actividad Laboral no encontrada");
        }

        public class DataComplementariaCesaHosp
        {
            public string tipo_seguro { get; set; }
            public string cod_producto { get; set; }
            public string producto { get; set; }
            public string codigo { get; set; }
            public string numero_cuenta { get; set; }
            public string descripcion { get; set; }
            public string tipo_actividad_laboral { get; set; }
            public Monto2 monto { get; set; }
            public List<Propiedade> propiedades { get; set; }
            public int? id_activo { get; set; }
            public bool seleccionable { get; set; }
            public string tipo_oferta { get; set; }
            public string GetPropiedad(string nombre)
            {
                if (propiedades == null)
                {
                    return null;
                }

                return propiedades.Where((Propiedade x) => x.nombre == nombre).FirstOrDefault()?.valor;
            }
        }
    }
}
