﻿extern alias GComponents;

using GComponents::Axxon.GlobalComponents.Helper;
using Plugin.ApiIntegration.Ofertas.Contract;
using Plugin.ApiIntegration.Ofertas.Service;
using System;
using System.Collections.Generic;
using System.Globalization;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class OfertaAumentoCupo : Oferta, IPlantillaProducto
    {
        public Datax data { get; set; }
        public string Gebody(DataOferta data, Producto producto)
        {
            char caracter = '"';
            string logo = $"{producto.Id}{data.logo.descripcion}";
            string cupo = string.IsNullOrEmpty(data.cupo) ? "0" : Math.Round(decimal.Parse(data.cupo), 0).ToString("C", new CultureInfo("es-CL"));
            return $@"
                   <input type={caracter}hidden{caracter} data-back={caracter}{logo}{caracter}>
                   <div class={caracter}row text-monto{caracter}>
                        <div class={caracter}col-5{caracter}>Monto</div>
                        <div class={caracter}col-7{caracter}>{cupo}</div>
                   </div>  ";
        }
        public List<Plantilla> GetProducto(Producto producto, PluginContext ctx)
        {
            List<Plantilla> lista = new List<Plantilla>();
            int contador = 0;
            List<string> numerosGUID = Utils.GeneraGuidListas(this.data.ofertas.Count);

            foreach (var oferta in this.data.ofertas)
            {                
                string idcard = $"{oferta.logo.descripcion}{numerosGUID[contador]}";
                string logo = $"{producto.Nombre} {oferta.logo.descripcion}";
                string JSON = string.Empty;
                contador++;

                try
                {
                    ctx.Trace($"plantilla - get logo");
                    producto.Logo = CRMQueries.getLogo(ctx, Logo.parseGrupo(Convert.ToInt32(oferta.logo.codigo)));
                }
                catch (Exception ex)
                {
                    ctx.Trace($"plantilla - get logo {ex.Message}");
                }
                try
                {
                    JSON = JsonSerializer.Serialize(ToOferta(data.id_cuenta, oferta, producto, ctx));
                }
                catch (Exception ex)
                {
                    ctx.Trace($"GetProducto -> JSON -> Error -> {ex} ");
                }

                lista.Add(new Plantilla()
                {
                    Selecionable = producto.Selecionable,
                    Simulable = producto.Simulable,
                    HTML = PlantillaHelper.Card(Gebody(oferta, producto), logo, idcard, producto),
                    Id = $"{producto.Id}{oferta.logo}",
                    JSON = JSON
                });
            }
            return lista;
        }
        public GComponents::Axxon.GlobalComponents.Model.Oferta ToOferta(int idcuenta, DataOferta data, Producto producto, PluginContext ctx)
        {
            GComponents::Axxon.GlobalComponents.Model.Oferta oferta = new GComponents::Axxon.GlobalComponents.Model.Oferta();
            ctx.Trace("OfertaSelecionada");
            oferta.numero_cuenta = null;
            ctx.Trace($"OfertaSelecionada - numero_cuenta - {oferta.numero_cuenta}");
            oferta.codigo = string.IsNullOrEmpty(producto.Codigo) ? "0": producto.Codigo;
            ctx.Trace($"OfertaSelecionada - codigo - { oferta.codigo}");
            oferta.id_oferta = data.id.ToString();
            ctx.Trace($"OfertaSelecionada - id_oferta - {oferta.id_oferta}");

            oferta.monto = new GComponents::Axxon.GlobalComponents.Model.Currency() { moneda = "CLP", simbolo = "$", valor = 0 };
            oferta.descripcion = string.Empty;
            ctx.Trace($"OfertaSelecionada - producto.Nombre - {producto.Nombre}");
            string logo = data?.logo?.descripcion;
            ctx.Trace($"OfertaSelecionada - producto.logo - {logo}");
            oferta.producto = $"{producto.Nombre} {logo}";
            ctx.Trace($"OfertaSelecionada - producto - {producto}");
            oferta.id_producto = string.IsNullOrEmpty(producto.Codigo) ? "0" : producto.Codigo;
            ctx.Trace($"OfertaSelecionada -  oferta.id_producto - { oferta.id_producto}");
            oferta.requiere_simulacion = producto.Simulable.ToString();
            oferta.tipo_oferta = !string.IsNullOrEmpty(producto.ER) ? "PRE-APROBADA" : "APROBADA";
            oferta.categorizacion_afinidad = false;
            oferta.id_activo = data.id.ToString();
            ctx.Trace($"OfertaSelecionada -  oferta.id_activo - { oferta.id_activo}");
            oferta.fecha_inicio = data.vigencia.fecha_desde;
            oferta.fecha_fin = data.vigencia.fecha_hasta;
            oferta.Selecionable = producto.Selecionable;
          
            oferta.cupo_total_cuenta = new GComponents::Axxon.GlobalComponents.Model.Currency() {
                moneda = "CLP",
                simbolo = "",
                valor = !string.IsNullOrEmpty(data.cupo) ? (int?)Math.Round(decimal.Parse(data.cupo), 0) : null
            };
            oferta.productId = Guid.Parse(producto.Id);
            oferta.propiedades = new List<GComponents::Axxon.GlobalComponents.Model.Propiedade>();
            oferta.id_cliente = $"{data.id_cliente}";
            oferta.id_cuenta = $"{idcuenta}";
            oferta.id_logo = $"{data.logo.id}";
            oferta.id_canal = "120";
            return oferta;
        }
    }
    public class Datax
    {
        public int id_cuenta { get; set; }
        public List<DataOferta> ofertas { get; set; }
        public string email_principal { get; set; }
        public object mensaje { get; set; }
    }
    public class DataOferta
    {
        public int id { get; set; }
        public int id_cliente { get; set; }
        public Logo logo { get; set; }
        public string cupo { get; set; }
        public Vigencia2 vigencia { get; set; }
        public bool emision_digital { get; set; }
        public bool firma_contrato { get; set; }
        public bool cupo_desde_sae { get; set; }
    }
    public class Vigencia2
    {
        public string fecha_desde { get; set; }
        public string fecha_hasta { get; set; }
    }
}