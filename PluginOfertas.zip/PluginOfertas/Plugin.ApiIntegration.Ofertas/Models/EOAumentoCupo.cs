﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    class EOAumentoCupo
    {

    }
    [DataContract]
    public class OMDMAC
    {
        [DataMember(Name = "id-cuenta")]
        public int id_cuenta { get; set; }

        [DataMember(Name = "id-cliente")]
        public int id_cliente { get; set; }

        [DataMember(Name = "id-logo")]
        public int id_logo { get; set; }

        [DataMember(Name = "cod-canal")]
        public int cod_canal { get; set; }

        [DataMember(Name = "monto")]
        public decimal monto { get; set; }
    }
}

