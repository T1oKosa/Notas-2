﻿using System;
using System.Collections.Generic;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class EOSAE
    {
        public string id { get; set; }
        public int? status { get; set; }
        public string resource { get; set; }
        public Data data { get; set; }
        public Metadata metadata { get; set; }
    }
    public class Data
    {
        public string id { get; set; }
        public Estado estado { get; set; }
        public Oferta2 oferta { get; set; }
        public int? id_cuenta { get; set; }
        public int? monto_solicitado { get; set; }
        public object monto_acumulado { get; set; }
        public object id_tarjeta { get; set; }
    }
    public class Estado
    {
        public int? id { get; set; }
        public string codigo { get; set; }
        public string estado { get; set; }
        public string mensaje { get; set; }
        public List<RechazoOMDM> rechazo_omdm { get; set; }
    }

  
    public class Oferta2
    {
        public int? id { get; set; }
        public string fecha_desde { get; set; }
        public string fecha_hasta { get; set; }
        public int? monto { get; set; }
        public int? monto_acumulado { get; set; }
        public List<string> rechazo_omdm { get; set; }
    }

    public class RechazoOMDM
    {
        public string codigo { get; set; }
        public string tipo_rechazo_descripcion { get; set; }
        public string tipo_rechazo_message { get; set; }
    }

}
