﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class SaldosCuposCuenta
    {
        public double cupo_nacional_cupo_virtual { get; set; }
    }
}
