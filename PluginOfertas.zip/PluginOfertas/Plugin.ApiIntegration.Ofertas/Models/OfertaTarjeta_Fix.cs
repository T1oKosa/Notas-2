using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class Ofertatarjeta_Fix
    {

        public Ofertatarjeta_Fix()
        {

        }

        //public List<DataTarjeta> data { get; set; }



    }
    
    public class DataTarjeta_Fix
        {
            public DataTarjeta_Fix()
            {
                this.id_grupo_servicio = this.id_grupo;
            }
            public int id_grupo_servicio { get; set; }
            public int id_cliente { get; set; }
            public int id_oferta { get; set; }
            public int id_grupo { get; set; }
            public int cupo { get; set; }
        }
}
