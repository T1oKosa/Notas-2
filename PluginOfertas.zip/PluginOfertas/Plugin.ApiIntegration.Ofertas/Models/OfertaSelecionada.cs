﻿using Org.BouncyCastle.Asn1.Mozilla;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class OfertaSelecionada
    {
        public object numero_cuenta { get; set; }
        public int codigo { get; set; }
        public int? id_oferta { get; set; }
        public string id_cuenta { get; set; }
        public Monto monto { get; set; }
        public Monto monto_oferta_neto { get; set; }
        public Monto monto_oferta_neto_ratificable { get; set; }
        public Monto monto_oferta_neto_no_ratificable { get; set; }
        public string descripcion { get; set; }
        public string productId { get; set; }
        public string producto { get; set; }
        public int? id_producto { get; set; }
        public bool requiere_simulacion { get; set; }
        public string tipo_oferta { get; set; }
        public bool categorizacion_afinidad { get; set; }
        public int? id_activo { get; set; }
        public int? id_tarjeta { get; set; }
        public object fecha_inicio { get; set; }
        public object fecha_fin { get; set; }
        public List<string> propiedades { get; set; }
        public bool seleccionable { get; set; }
        public CupoTotalCuenta cupo_total_cuenta { get; set; }
        public bool traspaso_tarjeta_cerrada { get; set; }
        public string id_cliente { get; set; }
        public string id_logo { get; set; }
        public string id_canal { get; set; }
        public string numero_tarjeta { get; set; }
        public string producto_upgrade_id { get; set; }
        public string producto_upgrade { get; set; }
        public string producto_actual_id { get; set; }
        public string producto_actual { get; set; }
        public List<AdicionalUpgrade> adicionales_upgrade { get; set; }
        public string bloqueo { get; set; }
        public string fecha_activacion { get; set; }
        public string fecha_bloqueo { get; set; }
        public string fecha_emision_tarjeta { get; set; }
        public string id_tarjeta_antigua { get; set; }
        public string fecha_vencimiento_facturacion { get; set; }
        public string pct { get; set; }
        public string url_servicio_simulacion { get; set; }
        public ReneRepa ofertaRdr { get; set; }
        public string id_grupo { get; set; }
        public string seguro_actual { get; set; }
        public string id_grupo_servicio { get; set; }
        public string url_redireccion { get; set; }
    }

    public class CupoTotalCuenta
    {
        public int? valor { get; set; }
        public string moneda { get; set; }
        public string simbolo { get; set; }
    }


    public class AdicionalUpgrade
    {
        public string id_cuenta_titular { get; set; }
        public string id_tarjeta_adicional { get; set; }
        public string id_cliente_adicional { get; set; }
        public string logo_id_adicional { get; set; }
        public string logo_codigo_adicional { get; set; }
        public string logo_descripcion_adicional { get; set; }
        public string id_producto_upgrade { get; set; }
        public string id_producto_actual { get; set; }
        public string numero_tarjeta { get; set; }
        public string numero_cuenta { get; set; }
        public string bloqueo { get; set; }
        public string fecha_activacion { get; set; }
        public string fecha_bloqueo { get; set; }
        public string fecha_emision_tarjeta { get; set; }
        public string id_tarjeta_antigua { get; set; }

        public bool? adicional_visible { get; set; }

    }

    public class Monto
    {
        public int? valor { get; set; }
        public string moneda { get; set; }
        public string simbolo { get; set; }
    }
    public class ReneRepa
    {
        public Monto monto_total_deudas { get; set; }
        public Monto pie { get; set; }
        public Monto deuda_linea_uno { get; set; }
        public Monto deuda_linea_dos { get; set; }
        public string plan_cobranza { get; set; }
        public string rut_cliente { get; set; }
        public string nombre_cliente { get; set; }
        public int? meses_gracia { get; set; }
        public string titulo { get; set; }
        public string afinidad { get; set; }
        public int? dias_mora { get; set; }
        public string tramo_mora { get; set; }
        public string numero_cuenta_ofuscado { get; set; }
        public string numero_tarjeta_ofuscado { get; set; }
        public int? id_tarjeta { get; set; }
        public string tipo_producto { get; set; }
        public string descripcion_producto { get; set; }
        public string logo { get; set; }
        public string nombre_logo { get; set; }
        public int? simulacion_cuotas { get; set; }
        public int? cuota_minima { get; set; }
        public int? cuota_maxima { get; set; }
        public float tasa_ejecutivo { get; set; }
        public string ip_cliente { get; set; }
        public ProductoSegurosResponse ProductoSeguros { get; set; }

    }
}