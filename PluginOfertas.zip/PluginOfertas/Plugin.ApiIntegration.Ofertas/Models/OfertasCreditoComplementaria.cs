﻿extern alias GComponents;

using GComponents::Axxon.GlobalComponents.Helper;
using Plugin.ApiIntegration.Ofertas.Contract;
using Plugin.ApiIntegration.Ofertas.Service;
using System;
using System.Collections.Generic;
using System.Globalization;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class OfertasCreditoComplementaria : IPlantillaProducto
    {
        public List<DataOfertaComplementaria> data { get; set; }

        public List<Plantilla> GetProducto(Producto producto, PluginContext ctx)
        {
            int contador = 0;
            List<Plantilla> lista = new List<Plantilla>();
            List<string> numerosGUID = Utils.GeneraGuidListas(this.data.Count);
            foreach (var oferta in this.data)
            {
                try
                {
                    ctx.Trace($"GetProducto - oferta.codigo - {oferta.codigo}");
                    ctx.Trace($"GetProducto - oferta.producto - {oferta.producto}");
                    string idcard = $"{oferta.producto}{numerosGUID[contador]}";
                    string json = string.Empty;
                    contador++;
                    Plantilla _plantilla = new Plantilla();

                    try
                    {
                        json = JsonSerializer.Serialize(oferta);

                    }
                    catch (Exception ex)
                    {
                        ctx.Trace($"Error al deserializar -> {ex.Message}");
                    }
                    if (oferta.producto.Contains("Reactivación Tarjeta"))
                    {
                        try
                        {
                            producto.Logo = CRMQueries.getLogoByCodigo(ctx, oferta.logo_tarjeta);

                        }
                        catch (Exception ex)
                        {
                            ctx.Trace($"Error get logo -> {ex.Message}");
                        }

                        producto.Orden = 0;
                        producto.Selecionable = false;
                        producto.Simulable = false;

                        producto.ER = "aprobado";
                        _plantilla.HTML = PlantillaHelper.CardCoplementarias(GebodyReactivacionTarjeta(oferta, producto), oferta.producto, idcard, producto);

                    }
                    else
                    {
                        try
                        {
                            producto.Logo = CRMQueries.getLogo(ctx, parseGrupo(oferta.producto));

                        }
                        catch (Exception ex)
                        {
                            ctx.Trace($"Error get logo -> {ex.Message}");
                        }

                        producto.Selecionable = false;
                        producto.Simulable = false;

                        producto.ER = "pre-aprobado";
                        _plantilla.HTML = PlantillaHelper.CardCoplementarias(Gebody(oferta, producto), oferta.producto, idcard, producto);
                    }
                    ctx.Trace($"ID -> {idcard}");

                    _plantilla.Id = idcard;
                    _plantilla.JSON = json;
                    lista.Add(_plantilla);
                }
                catch (Exception ex)
                {
                    ctx.Trace($"GetProducto - oferta.codigo - Error : {ex.Message}");
                }

            }
            return lista;
        }

        public string Gebody(DataOfertaComplementaria data, Producto producto)
        {
            char caracter = '"';
            string input = string.Empty;

            return $@"                
                <div class={caracter}row text-monto{caracter}>
                    <div class={caracter}col-5{caracter}>Monto.</div>
                    <div class={caracter}col-7{caracter}>{ Convert.ToInt32(data.monto.valor).ToString("C", new CultureInfo("es-CL"))}</div>
                </div>";             
        }

        public string GebodyReactivacionTarjeta(DataOfertaComplementaria data, Producto producto)
        {
            char caracter = '"';
            string input = string.Empty;

            return $@"                
                <div class={caracter}row text-monto{caracter}>
                    <div class={caracter}col-5{caracter}>N. de tarjeta</div>
                    <div class={caracter}col-7{caracter}>{data.numero_tarjeta}</div>
                </div>";
        }

        private int parseGrupo(string titulo)
        {
            int logo = 99;
            if (titulo.ToLower().Contains("mastercard"))
            {
                logo = 1;
            }
            if (titulo.ToLower().Contains("platinum"))
            {
                logo = 2;
            }
            if (titulo.ToLower().Contains("black"))
            {
                logo = 3;
            }
            if (titulo.ToLower().Contains("visa"))
            {
                logo = 0;
            }
            return logo;
        }

        public OfertaSelecionada ToOfertaSelecionada(DataOfertaComplementaria data, Producto producto, PluginContext ctx)
        {
            OfertaSelecionada oferta = new OfertaSelecionada();
            oferta.numero_cuenta = null;
            oferta.codigo = int.Parse(producto.Codigo);
            ctx.Trace($"Codigo -> {oferta.codigo}");
            oferta.id_oferta = int.Parse( data.id_oferta);
            ctx.Trace($"Id Oferta -> {oferta.id_oferta}");
            Plugin.ApiIntegration.Ofertas.Models.Monto monto = new Plugin.ApiIntegration.Ofertas.Models.Monto()
            {
                moneda = "CLP",
                simbolo = "$",
                valor = Convert.ToInt32(data.monto.valor)
            };
            ctx.Trace($"Monto -> {monto.valor}");
            oferta.monto = monto;
            oferta.descripcion = string.Empty;
            oferta.producto = producto.Nombre;
            ctx.Trace($"Producto -> {oferta.producto}");
            oferta.id_producto = int.Parse(producto.Codigo);
            ctx.Trace($"Id Producto -> {oferta.id_producto}");         
            oferta.tipo_oferta = !string.IsNullOrEmpty(producto.ER) ? "PRE-APROBADA" : "APROBADA";
            ctx.Trace($"Tipo Oferta -> {oferta.tipo_oferta}");
            oferta.categorizacion_afinidad = false;
            oferta.id_activo = int.Parse(data.id_activo);
            ctx.Trace($"Id Activo -> {oferta.id_activo}");
            oferta.fecha_inicio = oferta.fecha_inicio;
            ctx.Trace($"Fecha Inicio -> {oferta.fecha_inicio}");
            oferta.fecha_fin = oferta.fecha_fin;
            ctx.Trace($"Fecha Fin -> {oferta.fecha_fin}");
            oferta.seleccionable = false;
            ctx.Trace($"seleccionable -> {oferta.seleccionable}");
            oferta.traspaso_tarjeta_cerrada = false;
            oferta.productId = producto.Id.ToString();
            oferta.propiedades = new List<string>();
            return oferta;
        }

        public class DataOfertaComplementaria
        {
            public string numero_cuenta { get; set; }
            public string numero_tarjeta { get; set; }
            public string logo_tarjeta { get; set; }
            public string codigo { get; set; }
            public string id_oferta { get; set; }
            public Monto monto { get; set; }
            public string descripcion { get; set; }
            public string producto { get; set; }
            public string id_producto { get; set; }
            public string tipo_oferta { get; set; }
            public bool categorizacion_afinidad { get; set; }
            public string id_activo { get; set; }
            public string fecha_inicio { get; set; }
            public string fecha_fin { get; set; }
            public string propiedades { get; set; }
            public bool seleccionable { get; set; }
            public Monto cupo_total_cuenta { get; set; }
            public bool? traspaso_tarjeta_cerrada { get; set; }
            //public string cuota_maxima_excepcion { get; set; }
            //public string mes_diferimiento_excepcion { get; set; }
            //public Monto monto_excepcion { get; set; }
            //public string excepcion { get; set; }
            //public string total { get; set; }
            //public string groupCode { get; set; }
            //public string logoCode { get; set; }
            //public string signatureContract { get; set; }
            //public string emisionDigital { get; set; }
        }

        public class Monto
        {
            public float valor { get; set; }
            public string moneda { get; set; }
            public string simbolo { get; set; }
        }   
    }
}
