﻿extern alias GComponents;

using GComponents::Axxon.GlobalComponents.Helper;
using Microsoft.Xrm.Sdk;
using Plugin.ApiIntegration.Ofertas.Contract;
using Plugin.ApiIntegration.Ofertas.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class OfertaAutomotriz : Oferta
    {
        public DataAutomotriz data { get; set; }

        public List<Plantilla> GetProducto(Producto producto, PluginContext ctx, bool habilitada = true)
        {
            List<Plantilla> lista = new List<Plantilla>();

                string idcard = $"{producto.Id}_{1001}_{DateTime.Now.Ticks}";
                string html = PlantillaHelper.CardAutomotrizInformativa(
                    data.url,
                    producto,
                    habilitada
                );

                string json = JsonSerializer.Serialize(new OfertaSelecionada
                {
                    producto = "Seguro Automotriz Integral",
                    descripcion = "Cubre danos por colision, robo y asistencia en ruta.",
                    tipo_oferta = "APROBADA",
                    requiere_simulacion = false,
                    seleccionable = habilitada,
                    productId = producto.Id,
                    id_producto = int.TryParse(producto.Codigo, out var codigo) ? codigo : 0,
                    id_oferta = 1001,
                    monto = new Monto
                    {
                        moneda = "CLP",
                        simbolo = "$",
                        valor = 0
                    },
                    cupo_total_cuenta = new CupoTotalCuenta
                    {
                        moneda = "CLP",
                        simbolo = "",
                        valor = 0
                    },
                    url_redireccion = data.url
                });

                lista.Add(new Plantilla
                {
                    Selecionable = true,
                    Simulable = false,
                    HTML = html,
                    Id = idcard,
                    JSON = json
                });

            return lista;
        }

        public List<Plantilla> GetProductoNoHabilitado(Producto producto)
        {
            return GetProductoAviso(producto,
                "OFERTA NO HABILITADA",
                "Esta oferta no se encuentra habilitada para el cliente en su sucursal.");
        }

        public List<Plantilla> GetProductoDatosIncompletos(Producto producto, List<string> datosFaltantes)
        {
            return new List<Plantilla>
            {
                new Plantilla
                {
                    Selecionable = false,
                    Simulable = false,
                    HTML = PlantillaHelper.CardAutomotrizError(producto,
                        "Datos incompletos",
                        $"No es posible consultar la oferta, faltan datos: {string.Join(", ", datosFaltantes)}."),
                    Id = $"{producto.Id}_{1001}_{DateTime.Now.Ticks}",
                    JSON = "{}"
                }
            };
        }

        private List<Plantilla> GetProductoAviso(Producto producto, string etiqueta, string mensaje)
        {
            return new List<Plantilla>
            {
                new Plantilla
                {
                    Selecionable = false,
                    Simulable = false,
                    HTML = PlantillaHelper.CardAutomotrizAviso(producto, etiqueta, mensaje),
                    Id = $"{producto.Id}_{1001}_{DateTime.Now.Ticks}",
                    JSON = "{}"
                }
            };
        }

        public bool HabilitadoOfertaAutomotriz(PluginContext ctx, Guid personaId, Guid? sucursalId)
        {
            if (personaId == Guid.Empty || !sucursalId.HasValue || sucursalId.Value == Guid.Empty)
            {
                ctx.Trace("HabilitadoOfertaAutomotriz - sin guid de persona o sucursal");
                return false;
            }

            try
            {
                ctx.Trace("HabilitadoOfertaAutomotriz - obteniendo registro de oferta habilitada");
                ctx.Trace($"HabilitadoOfertaAutomotriz - personaId: {personaId}");
                ctx.Trace($"HabilitadoOfertaAutomotriz - sucursalId: {sucursalId.Value}");
                Entity registro = CRMQueries.ObtenerRegistroHabilitacionAutomotriz(ctx, personaId, sucursalId.Value, "axx_persona", "axx_sucursal");

                ctx.Trace("HabilitadoOfertaAutomotriz validando si se obtuvo registro");
                if (registro == null || !registro.Contains("axx_habilitadaparaofertaautomotriz"))
                {
                    ctx.Trace("HabilitadoOfertaAutomotriz - sin registro o bien no esta habilitado");
                    return false;
                }

                bool habilitado = (bool)registro["axx_habilitadaparaofertaautomotriz"];

                ctx.Trace($"HabilitadoOfertaAutomotriz - habilitado: {habilitado}");
                return (bool)habilitado;
            }
            catch (Exception ex)
            {
                ctx.Trace($"Error validando habilitacion oferta automotriz: {ex.Message}");
                return false;
            }
        }
    }

    public class DataAutomotriz
    {
        public string url { get; set; }
        public string uuid_sesion { get; set; }
    }
}
