﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class RequestSesionCharlesTaylor
    {
        public string nombreEjecutivo { get; set; }
        public string apellidoEjecutivo { get; set; }
        public string correoEjecutivo { get; set; }
        public string clientId { get; set; }
        public string codSucursal { get; set; }
        public string nombreSucursal { get; set; }
    }
}
