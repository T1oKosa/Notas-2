﻿extern alias GComponents;

using System;
using System.Collections.Generic;
using System.Globalization;
using GComponents::Axxon.GlobalComponents.Helper;
using GComponents::Axxon.GlobalComponents.Model;
using Org.BouncyCastle.Bcpg;
using Plugin.ApiIntegration.Ofertas.Contract;
using Plugin.ApiIntegration.Ofertas.Service;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class OfertaTarjeta : Oferta, IPlantillaProducto
    {    
        public string Gebody(DataTarjeta data, Producto producto, PluginContext ctx)
        {
            ctx.Trace($"Gebody");
            char caracter = '"';
            return $@"
                  <input type={caracter}hidden{caracter} data-back={caracter}{producto.Id}{GetLogo(data.id_grupo)}{caracter}>
                   <div class={caracter}row text-monto{caracter}>
                       <div class={caracter}col-5{caracter}>Monto</div>
                       <div class={caracter}col-7{caracter}>{data.cupo.ToString("C", new CultureInfo("es-CL"))}</div>
                   </div>";
        }

        public List<Plantilla> GetProducto(Producto producto, PluginContext ctx)
        {
            ctx.Trace($"GetProducto");
            List<Plantilla> lista = new List<Plantilla>();
            foreach (var oferta in this.data.ofertas)
            {
                ctx.Trace($"id_grupo Producto - servicio: {oferta.id_grupo.ToString()}");
                switch (oferta.id_grupo)
                { //validacion de purgados
                    case 4:
                        oferta.id_grupo = 1;
                        break;
                    case 5:
                        oferta.id_grupo = 2;
                        break;
                    case 6:
                        oferta.id_grupo = 3;
                        break;
                    case 7:
                        oferta.id_grupo = 1;
                        break;
                    case 8:
                        oferta.id_grupo = 2;
                        break;
                    case 9:
                        oferta.id_grupo = 3;
                        break;
                }

                ctx.Trace($"id_grupo Producto - homologado: {oferta.id_grupo.ToString()}");

                var ProductoGrupo = ctx.CachedEntities.GetProductByGrupo(oferta.id_grupo.ToString());
                ctx.Trace($"ProductoGrupo: {JsonSerializer.Serialize(ProductoGrupo)}");


                var productoUnitario = CRMQueries.GetProducto(ctx, ProductoGrupo.ProductId);
                ctx.Trace($"productoUnitario: {JsonSerializer.Serialize(productoUnitario)}");

                productoUnitario.ER = producto.ER;
                productoUnitario.Orden = producto.Orden;
                string idcard = $"{GetLogo(oferta.id_grupo)}{DateTime.Now.Ticks}";

                ctx.Trace($"idcard:{idcard}");
                string logo = productoUnitario.Nombre;
                ctx.Trace($"logo:{logo}");

                ctx.Trace($" id cliente---------> {oferta.id_cliente} ");
                string json = productoUnitario.Simulable ? JsonSerializer.Serialize<OfertaSelecionada>(ToOfertaSimulable(oferta, productoUnitario)) :
                    JsonSerializer.Serialize(ToOfertaSelecionable(oferta, productoUnitario));
                producto.Logo = CRMQueries.getLogo(ctx, parseGrupo(oferta.id_grupo));
                ctx.Trace($"{json} ");

                ctx.Trace($" seleccionable ---------> {ctx.CachedEntities.ProductoSucursal(new Guid(productoUnitario.Id), ctx.Context.UserId).Seleccionable} ");
                ctx.Trace($" Cupo---------> {oferta.cupo} ");
                if (oferta.cupo != 1)
                {

                    lista.Add(new Plantilla()
                    {
                        Selecionable = productoUnitario.Selecionable,
                        Simulable = producto.Simulable,
                        HTML = PlantillaHelper.Card(Gebody(oferta, productoUnitario, ctx), logo, idcard, productoUnitario),
                        Id = $"{productoUnitario.Id}{GetLogo(oferta.id_grupo)}",
                        JSON = json
                    });
                }
                else
                {
                    lista.Add(new Plantilla()
                    {
                        Selecionable = productoUnitario.Selecionable,
                        Simulable = producto.Simulable,
                        HTML = PlantillaHelper.Card1peso(Gebody(oferta, productoUnitario, ctx), logo, idcard, productoUnitario),
                        Id = $"{productoUnitario.Id}{GetLogo(oferta.id_grupo)}_1peso",
                        JSON = json
                    });
                }

            }
            return lista;
        }

        public string GetLogo(int id)
        {
            string logo = string.Empty;
            switch (id)
            {
                case 1:
                    logo = "Mastercard";
                    break;
                case 2:
                    logo = "Platinium";
                    break;
                case 3:
                    logo = "Black";
                    break;
            }
            return logo;
        }
        public int parseGrupo(int id)
        {
            int logo = 99;
            if (id == 1 || id == 4 || id == 7)
            {
                logo = 1;
            }
            if (id == 2 || id == 5 || id == 8)
            {
                logo = 2;
            }
            if (id == 3 || id == 6 || id == 9)
            {
                logo = 3;
            }
            return logo;
        }
        public OfertaSelecionada ToOfertaSimulable(DataTarjeta data, Producto producto)
        {
            OfertaSelecionada oferta = new OfertaSelecionada();
            oferta.numero_cuenta = "";
            oferta.codigo = int.Parse(producto?.Codigo);
            oferta.id_oferta = data?.id_oferta;
            //Monto
            Monto monto = new Monto()
            {
                moneda = "CLP",
                simbolo = "$",
                valor = data.cupo
            };
            oferta.monto = monto;
            oferta.descripcion = string.Empty;
            oferta.producto = $"{producto?.Nombre} {GetLogo(data.id_grupo)}";
            oferta.id_producto = int.Parse(producto.Codigo);
            oferta.requiere_simulacion = producto.Simulable;
            oferta.tipo_oferta = !string.IsNullOrEmpty(producto.ER) ? "PRE-APROBADA" : "APROBADA";
            oferta.categorizacion_afinidad = false;
            oferta.id_activo = data.id_oferta;
            //oferta.fecha_inicio = data.fecha_vigencia_inicial.ToString("yyyy-MM-dd");
            //oferta.fecha_fin = data.fecha_vigencia_final.ToString("yyyy-MM-dd");
            oferta.seleccionable = producto.Selecionable;
            oferta.id_grupo = !string.IsNullOrEmpty(data.id_grupo.ToString()) ? data.id_grupo.ToString() : "";
            oferta.id_grupo_servicio = !string.IsNullOrEmpty(data.id_grupo_servicio.ToString()) ? data.id_grupo_servicio.ToString() : "";
            //Cupo
            CupoTotalCuenta cupototal = new CupoTotalCuenta()
            {
                moneda = "CLP",
                simbolo = "",
                valor = data.cupo
            };
            oferta.cupo_total_cuenta = cupototal;
            oferta.traspaso_tarjeta_cerrada = false;
            oferta.productId = producto.Id;
            oferta.propiedades = new List<string>();
            return oferta;
        }
        public GComponents::Axxon.GlobalComponents.Model.Oferta ToOfertaSelecionable(DataTarjeta data, Producto producto)
        {
            GComponents::Axxon.GlobalComponents.Model.Oferta oferta = new GComponents::Axxon.GlobalComponents.Model.Oferta();
            oferta.numero_cuenta = "";
            oferta.codigo = producto.Codigo;
            oferta.id_oferta = $"{data.id_oferta}";
            //Monto
            GComponents::Axxon.GlobalComponents.Model.Currency monto = new GComponents::Axxon.GlobalComponents.Model.Currency()
            {
                moneda = "CLP",
                simbolo = "$",
                valor = data.cupo
            };
            oferta.monto = monto;
            oferta.descripcion = string.Empty;
            oferta.producto = $"{producto.Nombre}";
            oferta.id_producto = producto.Codigo;
            oferta.tipo_oferta = !string.IsNullOrEmpty(producto.ER) ? "PRE-APROBADA" : "APROBADA";
            oferta.categorizacion_afinidad = false;
            oferta.id_activo = data.id_oferta.ToString();
            //oferta.fecha_inicio = data.fecha_vigencia_inicial.ToString("yyyy-MM-dd");
            //oferta.fecha_fin = data.fecha_vigencia_final.ToString("yyyy-MM-dd");
            oferta.requiere_simulacion = $"{producto.Simulable}";
            oferta.productId = Guid.Parse(producto.Id);
            oferta.propiedades = new List<GComponents::Axxon.GlobalComponents.Model.Propiedade>();
            oferta.id_grupo = data.id_grupo.ToString();
            oferta.id_grupo_servicio = data.id_grupo_servicio.ToString();

            //Cupo
            GComponents::Axxon.GlobalComponents.Model.Currency cupototal = new GComponents::Axxon.GlobalComponents.Model.Currency()
            {
                moneda = "CLP",
                simbolo = "",
                valor = data.cupo
            };
            oferta.cupo_total_cuenta = cupototal;

            return oferta;
        }


        public Data data { get; set; }

        public class Data
        {
            public string tipo_cobertura { get; set; }
            public List<DataTarjeta> ofertas { get; set; }
        }

        public class DataTarjeta
        {
            public DataTarjeta()
            {
                this.id_grupo_servicio = this.id_grupo;
            }
            public int id_grupo_servicio { get; set; }
            public int id_cliente { get; set; }
            public int id_oferta { get; set; }
            public int id_grupo { get; set; }
            public int cupo { get; set; }
        }
    }
}