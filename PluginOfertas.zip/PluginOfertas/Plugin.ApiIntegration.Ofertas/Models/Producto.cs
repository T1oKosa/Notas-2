﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class Producto
    {
        public string Nombre { get; set; }
        public string URL { get; set; }
        public string Id { get; set; }
        public string Id_Servicio { get; set; }
        public string Logo { get; set; }
        public string Grupo { get; set; }
        public string Codigo { get; set; }
        public string ER { get; set; } //Evaluacion de Riegos
        public bool CompraDatos { get; set; } 
        public bool Selecionable { get; set; }
        public  bool Simulable { get; set; }
        public  int Orden { get; set; }
        public string Configuracion { get; set; }
        public int simulacionCuotas { get; set; }
    }
}