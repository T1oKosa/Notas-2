﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class SMSRequest
    {
        public int id_cliente { get; set; }
        public string codigo_producto { get; set; }
        public Guid IdProducto { get; set; }
        public string NumeroDocumento { get; set; }
        public string NumeroDocumentoDesencriptado { get; set; }
        public string Telefono { get; set; }
        public string Fecha { get; set; }
        public string Local_origen { get; set; }
        public string Retail_origen { get; set; }
        public Guid IdRetail_origen { get; set; }
        public string Monto_Ofertado { get; set; }
        public string Mensaje { get; set; }
        public string nombre_persona { get; set; }
        public string apellido_paterno { get; set; }
        public string apellido_materno { get; set; }
        public string nombre_completo => this.nombre_persona != "" ? (this.nombre_persona + (this.apellido_paterno != "" ? $" {this.apellido_paterno}" : "") + (this.apellido_materno != "" ? $" {this.apellido_materno}" : "")) : "";
        public string usuario_digevo { get; set; }
        public string Caja { get; set; }
        public CajaInfo cajas { get; set; }
    }

    public class CajaInfo
    {
        public string guid_caja { get; set; }
        public string codigo_sap { get; set; }
        public string sucursal { get; set; }
        public string nombre_caja { get; set; }
        public int numero_caja { get; set; }
        public string piso { get; set; }
        public string tipo_dispositivo { get; set; }
        public string mensaje_captador { get; set; }
        public long tiempo_total_ejecucion { get; set; }
    }
}
