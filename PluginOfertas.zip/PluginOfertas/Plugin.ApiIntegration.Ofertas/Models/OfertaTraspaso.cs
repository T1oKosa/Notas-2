﻿extern alias GComponents;

using GComponents::Axxon.GlobalComponents.Helper;
using Plugin.ApiIntegration.Ofertas.Contract;
using Plugin.ApiIntegration.Ofertas.Service;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class OfertaTraspaso : IPlantillaProducto
    {
        public int? maximo { get; set; }
        public int? pagina { get; set; }
        public int? cantidad_elementos { get; set; }
        public List<Contenidoot> contenido { get; set; }
        public int? cantidad_paginas { get; set; }
        public List<EstadoPreventivo> estado_preventivo { get; set; }
        public List<Plantilla> GetProducto(Producto producto, PluginContext ctx)
        {
            List<Plantilla> lista = new List<Plantilla>();
            foreach (var oferta in this.contenido)
            {
                string idcard = $"{oferta.producto}{DateTime.Now.Ticks}";
                string logo = oferta.producto;

                try
                {
                    producto.Logo = CRMQueries.getLogo(ctx, parseGrupo(oferta.producto));

                }
                catch (Exception ex)
                {
                    ctx.Trace($"Error get logo -> {ex.Message}");
                }
                lista.Add(new Plantilla()
                {
                    Selecionable = oferta.seleccionable,
                    Simulable = producto.Simulable,
                    HTML = PlantillaHelper.Card(Gebody(oferta, producto), logo, idcard, producto),
                    Id = $"{producto.Id}{oferta.producto}",
                    JSON = JsonSerializer.Serialize(ToOferta(oferta, producto,ctx))
                }); ;
            }
            return lista;
        }

        private string Gebody(Contenidoot oferta, Producto producto)
        {
            char caracter = '"';
            return $@"
                   <input type={caracter}hidden{caracter} data-back={caracter}{producto.Id}{oferta.producto}{caracter}>
                   <div class={caracter}row text-monto{caracter}>
                        <div class={caracter}col-5{caracter}>Monto</div>
                        <div class={caracter}col-7{caracter}>${oferta.monto.valor.Value.ToString("C", new CultureInfo("es-CL"))}</div>
                   </div>";
        }

        private OfertaSelecionada ToOferta(Contenidoot oferta, Producto producto, PluginContext ctx)
        {
            OfertaSelecionada _oferta = new OfertaSelecionada();
            try
            {
                _oferta.codigo = !string.IsNullOrEmpty(oferta.codigo) ? int.Parse(oferta.codigo) : 0;
                _oferta.descripcion = oferta.descripcion;
                _oferta.id_producto = !string.IsNullOrEmpty(oferta.id_producto.ToString()) ? int.Parse(oferta.id_producto.ToString()) : 0;
                _oferta.id_oferta = oferta.id_oferta;
                _oferta.id_activo = oferta.id_activo;
                _oferta.seleccionable = oferta.seleccionable;
                _oferta.propiedades = oferta.propiedades;
                _oferta.categorizacion_afinidad = oferta.categorizacion_afinidad;
                _oferta.tipo_oferta = oferta.tipo_oferta;
                _oferta.numero_cuenta = oferta.numero_cuenta;
                _oferta.traspaso_tarjeta_cerrada = oferta.traspaso_tarjeta_cerrada;
                _oferta.requiere_simulacion = producto.Simulable;
                _oferta.productId = default(Guid).ToString();
                _oferta.monto = new Monto()
                {
                    valor = oferta.monto.valor,
                    moneda = oferta.monto.moneda,
                    simbolo = oferta.monto.simbolo
                };


                _oferta.cupo_total_cuenta = new CupoTotalCuenta()
                {
                    moneda = oferta.cupo_total_cuenta.moneda,
                    valor = oferta.cupo_total_cuenta.valor,
                    simbolo = oferta.cupo_total_cuenta.simbolo
                };
                _oferta.producto = oferta.producto;

            }
            catch (Exception ex)
            {
                ctx.Trace($"{ex.Message}");
            }
            return _oferta;
        }

        private int parseGrupo(string titulo)
        {
            int logo = 99;
            if (titulo.ToLower().Contains("mastercard"))
            {
                logo = 1;
            }
            if (titulo.ToLower().Contains("platinum"))
            {
                logo = 2;
            }
            if (titulo.ToLower().Contains("black"))
            {
                logo = 3;
            }
            if (titulo.ToLower().Contains("visa"))
            {
                logo = 0;
            }
            return logo;
        }
    }
    public class Montoot
    {
        public int? valor { get; set; }
        public string moneda { get; set; }
        public string simbolo { get; set; }
    }
    public class CupoTotalCuentaot
    {
        public int? valor { get; set; }
        public string moneda { get; set; }
        public string simbolo { get; set; }
    }
    public class Contenidoot
    {
        public object numero_cuenta { get; set; }
        public string codigo { get; set; }
        public int? id_oferta { get; set; }
        public Montoot monto { get; set; }
        public string descripcion { get; set; }
        public string producto { get; set; }
        public object id_producto { get; set; }
        public string tipo_oferta { get; set; }
        public bool categorizacion_afinidad { get; set; }
        public int? id_activo { get; set; }
        //public DateTime? fecha_inicio { get; set; }
        //public DateTime? fecha_fin { get; set; }
        public List<string> propiedades { get; set; }
        public bool seleccionable { get; set; }
        public CupoTotalCuentaot cupo_total_cuenta { get; set; }
        public bool traspaso_tarjeta_cerrada { get; set; }
        public int? cuota_maxima_excepcion { get; set; }
        public int? mes_diferimiento_excepcion { get; set; }
        public MontoExcepcion monto_excepcion { get; set; }
        public bool excepcion { get; set; }
    }
    public class EstadoPreventivo
    {
        public string mensaje { get; set; }
        public string descripcion { get; set; }
    }
    public class MontoExcepcion
    {
        public int? valor { get; set; }
        public string moneda { get; set; }
        public string simbolo { get; set; }
    }
}