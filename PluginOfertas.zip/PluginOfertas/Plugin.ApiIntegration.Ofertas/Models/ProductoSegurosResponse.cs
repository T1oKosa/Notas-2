﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class SeguroProducto
    {
        public int id { get; set; }
        public string guid { get; set; }
        public int id_producto { get; set; }
        public int id_seguro { get; set; }
        public int id_canal { get; set; }
        public bool primera_simulacion { get; set; }
        public int dpc { get; set; }
        public int codigo_estado_registro { get; set; }
        public int id_usuario { get; set; }
        public string fecha_creacion { get; set; }
        public string fecha_ult_actualizacion { get; set; }
        public object fecha_baja { get; set; }
        public string guid_evento { get; set; }
        public int? dpc_deuda_tarjeta { get; set; }
        public int? dpc_deuda_credito { get; set; }
        public int? dpc_deuda_tj_cc { get; set; }
    }
    public class ProductoSegurosResponse
    {
        public List<SeguroProducto> data { get; set; }
    }
}
