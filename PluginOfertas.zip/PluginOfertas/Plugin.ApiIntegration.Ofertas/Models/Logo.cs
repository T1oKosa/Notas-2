﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class Logo
    {
        public int id { get; set; }
        public string codigo { get; set; }
        public string descripcion { get; set; }

        public static int parseGrupo(int id)
        {
            int logo = id;
            if (id == 502)
            {
                logo = 1;
            }
            if (id == 506)
            {
                logo = 2;
            }
            if (id == 516)
            {
                logo = 3;
            }
            return logo;
        }
    }

}
