﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class ReemisionAListar : ReemisionGenerica
    {

        public bool Seleccionado { get; set; }

        public int Indice { get; set; }

        /// <summary>
        /// fecha_bloqueo
        /// </summary>
        [DisplayName("Fecha Bloqueo")]
        public DateTime? Fecha_bloqueo { get; set; }

        [DisplayName("Fecha Bloqueo")]
        public string Fecha_bloqueoCorta
        {
            get { return Fecha_bloqueo != null ? Fecha_bloqueo.GetValueOrDefault().ToShortDateString() : ""; }
        }

        /// <summary>
        /// fecha_emision
        /// </summary>
        [DisplayName("Fecha Emisión Tarjeta")]
        public DateTime? Fecha_emision { get; set; }


        [DisplayName("Fecha Emisión Tarjeta")]
        public string Fecha_emisionCorta
        {
            get { return Fecha_emision != null ? Fecha_emision.GetValueOrDefault().ToShortDateString() : ""; }
        }




        /// <summary>
        /// fecha_activacion
        /// </summary>
        [DisplayName("Fecha Activación")]
        public DateTime? Fecha_activacion { get; set; }

        [DisplayName("Fecha Activación")]
        public string Fecha_activacionCorta
        {
            get { return Fecha_activacion != null ? Fecha_activacion.GetValueOrDefault().ToShortDateString() : ""; }
        }

        /// <summary>
        /// axx_solicitantereemision
        /// </summary>
        public Guid SolicitanteReemision { get; set; }

        [DisplayName("Solicitante")]
        public string SolicitanteReemisionNombre { get; set; }

        [DisplayName("RUT")]
        public string SolicitanteReemisionRUT { get; set; }

        public Guid Ejecutivo { get; set; }

        [DisplayName("Ejecutivo")]
        public string EjecutivoNombre { get; set; }

        [DisplayName("Rut ejecutivo")]
        public string EjecutivoRut { get; set; }

        public Guid Sucursal { get; set; }

        [DisplayName("Sucursal")]
        public string SucursalNombre { get; set; }

        /// <summary>
        /// axx_ruttitulartarjeta
        /// </summary>
        public string RutTitularTarjeta { get; set; }

        /// <summary>
        /// axx_nrotarjetanuevo
        /// </summary>
        public string NumeroTarjetaNuevo { get; set; }

        /// <summary>
        /// name
        /// </summary>
        [DisplayName("Tipo Tarjeta")]
        public string Name { get; set; }

        /// <summary>
        /// axx_reemisionesid
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// axx_idtarjetacatantigua
        /// </summary>
        public string IdTarjetaAntigua { get; set; }

        public string IdTarjetaNueva { get; set; }
    }
}
