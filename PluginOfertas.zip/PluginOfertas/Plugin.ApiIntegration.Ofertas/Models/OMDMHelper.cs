﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public static class OMDMHelper
    {
        /// <summary>
        /// Busqueda de la descripcion para los codigos de rechazo OMDM
        /// </summary>
        /// <param name="codigo"></param>
        /// <returns></returns>
        public static string Descripcion(List<string> rechazos)
        {
            string _rechazos = string.Empty;
            foreach (var rechazo in rechazos)
            {
                if (GetDicionarioOMDM().ContainsKey(rechazo))
                {
                    _rechazos += $"{GetDicionarioOMDM()[rechazo]} ";
                }
            }
            return _rechazos;
        }

        public static string DescripcionOMDMSAE(List<RechazoOMDM> rechazos)
        {
            string _rechazos = string.Empty;
            foreach (var rechazo in rechazos)
            {
                _rechazos += !string.IsNullOrEmpty(rechazo.tipo_rechazo_message) ? $"{rechazo.tipo_rechazo_message} "
                                : $"{rechazo.tipo_rechazo_descripcion} ";
            }

            return _rechazos;
        }

        /// <summary>
        /// Temporal mientras el equipo core despliega el mensaje en los rechazos OMDM
        /// </summary>
        /// <returns></returns>
        private static Dictionary<string, string> GetDicionarioOMDM()
        {
            return new Dictionary<string, string>() {
           {"EI" ,"Persona no cumple condición para el producto"},
            {"AZ" ,"No cumple con el nivel mínimo de aprobación crediticia previsto en el análisis de riesgo" },
            {"B6" ,"No cumple con el nivel mínimo de aprobación crediticia previsto en el análisis de riesgo" },
            {"BM" ,"No cumple con Políticas de riesgo para cupo adicional de Purgado. Derivar a PCE" },
            {"ZZ" ,"Rechazo verificación Trigger" },
            {"EA" ,"Persona no cumplen condición para Producto" },
            {"ED" ,"No cumple con el nivel mínimo de aprobación crediticia previsto en el análisis de riesgo" },
            {"FK" ,"No cumple los parámetros de endeudamiento de acuerdo a Política de Crédito" },
            {"FE" ,"Inadecuado nivel de contactabilidad que dificulta la normal recaudación y cobranza del crédito" },
            {"FG" ,"Incumplimiento previo de una obligación contraída con la Empresa, sus filiales o relacionadas" },
            {"GM" ,"Obligaciones morosas o protestadas en el sistema financiero" },
            {"FN" ,"No cumple con continuidad laboral mínima de acuerdo a Política de Crédito" },
            {"DW" ,"Cliente giró totalidad de oferta" },
            {"XZ" ,"El cliente no posee firma de contrato" },
            {"FQ" ,"Ingresos insuficientes de acuerdo a Política de Crédito" },
            {"FV" ,"Insuficiencia de patrimonio o de ingresos mensuales para pagar la operación crediticia" },
            {"FZ" ,"Solicitud rechazada por Política de Crédito de la Empresa" },
            {"GF" ,"No cumple con el nivel mínimo de aprobación crediticia previsto en el análisis de riesgo" },
            {"GG" ,"Incumplimiento de los parámetros objetivos de endeudamiento determinados en la Política de crédito de la Empresa." },
            {"GJ" ,"Solicitud rechazada por Política de Crédito de la Empresa" },
            {"GL" ,"Incumplimiento previo de una obligación contraída con la Empresa, sus filiales o relacionadas" },
            {"GO" ,"Solicitud rechazada por Política de Crédito de la Empresa" },
            {"GS" ,"Incumplimiento previo de una obligación contraída con la Empresa, sus filiales o relacionadas" },
            {"GU" ,"Solicitud rechazada por falta de capacidad del cliente para poder obligarse" },
            {"GZ" ,"Insuficiencia de patrimonio o de ingresos mensuales para pagar la operación crediticia" },
            {"HC" ,"Solicitud rechazada por Política de Crédito de la Empresa" },
            {"HD" ,"Solicitud rechazada por Política de Crédito de la Empresa" },
            {"HH" ,"Incumplimiento previo de una obligación contraída con la Empresa, sus filiales o relacionadas" },
            {"HI" ,"Incumplimiento previo de una obligación contraída con la Empresa, sus filiales o relacionadas" },
            {"TW" ,"Solicitud rechazada por Política de Crédito de la Empresa" },
            {"GQ" ,"Solicitud rechazada por Política de Crédito de la Empresa" },
            {"H2" ,"No cumple los parámetros de endeudamiento de acuerdo a Política de Crédito" },
            {"P1" ,"Incumplimiento previo de obligación con la Empresa, sus filiales o relacionadas" },
            {"P3" ,"Cliente fallecido" },
            {"SA" ,"No cumple edad mínima" },
            {"SM" ,"No cumple con el nivel mínimo de aprobación crediticia previsto en el análisis de riesgo" },
            {"SO" ,"No cumple con el nivel mínimo de aprobación crediticia previsto en el análisis de riesgo" },
            {"TB" ,"No cumple con renta mínima exigida para el Producto" },
            {"TL" ,"No cumple los parámetros de endeudamiento de acuerdo a Política de Crédito" },
            {"TP" ,"Incumplimiento previo de una obligación contraída con la Empresa, sus filiales o relacionadas." },
            {"TS" ,"Excesiva carga financiera o de endeudamiento determinada en la Política de crédito de la Empresa" },
            {"FL" ,"Incumplimiento previo de una obligación contraída con la Empresa, sus filiales o relacionadas (MI)" },
            {"B1" ,"Obligaciones morosas o protestadas en el Sistema Financiero" },
            {"DV" ,"Solicitud rechazada por falta de capacidad de la persona para poder obligarse" },
            {"FA" ,"Existencia de prohibiciones legales para otorgar la operación crediticia al solicitante" },
            {"FF" ,"Inadecuado nivel de contactabilidad que dificulta la normal recaudación y cobranza del crédito." },
            {"FO" ,"No cumple los parámetros de endeudamiento de acuerdo a Política de Crédito" },
            {"FP" ,"Incumplimiento de los parámetros objetivos de endeudamiento determinados en la Política de crédito de la Empresa" },
            {"FR" ,"Insuficiencia de patrimonio o de ingresos mensuales para pagar la operación crediticia." },
            {"GA" ,"Incumplimiento de los parámetros objetivos de endeudamiento determinados en la Política de crédito de la Empresa" },
            {"UG" ,"No cumple con el nivel mínimo de aprobación crediticia previsto en el análisis de riesgo" },
            {"UN" ,"Excesiva carga financiera o de endeudamiento determinada en la Política de crédito de la Empresa" },
            {"VC" ,"No cumple con requisito de nacionalidad de acuerdo a Política de Crédito" },
            {"8 " ,"Falta capacidad de la persona para obligarse" },
            {"12" ,"Por forma" },
            {"13" ,"Por documentación incompleta" },
            {"GD" ,"Insuficiencia de patrimonio o de ingresos mensuales para pagar la operación crediticia" },
            {"GI" ,"Incumplimiento de los parámetros objetivos de endeudamiento determinados en la Política de Crédito de la Empresa" },
            {"GN" ,"Incumplimiento del nivel de aprobación previsto en la clasificación privada para la gestión de riesgo de crédito utilizada por Banco París" },
            {"GT" ,"Insuficiencia de patrimonio o de ingresos mensuales para pagar la operación crediticia" },
            {"GX" ,"Insuficiencia de garantías, muebles o inmuebles, personales o reales, en los casos requeridos en la Política de Crédito o con posterioridad al análisis de riesgo comercial efectuado por la Empresa" },
            {"HB" ,"Insuficiencia de garantías, muebles o inmuebles, personales o reales, en los casos requeridos en la Política de Crédito o con posterioridad al análisis de riesgo comercial efectuado por la Empresa" },
            {"HG" ,"Incumplimiento de los parámetros objetivos de endeudamiento determinados en la Política de crédito de la Empresa" },
            {"HJ" ,"Insuficiencia de patrimonio o de ingresos mensuales para pagar la operación crediticia." },
            {"HF" ,"Obligaciones morosas o protestadas en el sistema financiero" },
            {"H1" ,"Ingresos insuficientes para acceder al aumento de cupo solicitado" },
            {"P2" ,"Solicitud rechazada por Política de Crédito de la Empresa" },
            {"P4" ,"Solicitud rechazada, falta de capacidad del cliente para obligarse" },
            {"SL" ,"Obligaciones morosas o protestadas en el sistema financiero" },
            {"SN" ,"No cumple con el nivel mínimo de aprobación crediticia previsto en el análisis de riesgo" },
            {"ST" ,"Excesiva carga financiera o de endeudamiento determinada en la Política de Crédito de Empresa" },
            {"TJ" ,"No cumple los parámetros de endeudamiento de acuerdo a Política de Crédito" },
            {"TO" ,"Incumplimiento previo de una obligación contraída con la Empresa, sus filiales o relacionadas" },
            {"TQ" ,"Excesiva carga financiera o de endeudamiento determinada en la Política de Crédito de la Empresa" },
            {"TT" ,"Excesiva carga financiera o de endeudamiento determinada en la Política de Crédito de la Empresa" },
            {"UI" ,"No cumple los parámetros de endeudamiento de acuerdo a Política de Crédito" },
            {"UP" ,"Insuficiencia de patrimonio o de ingresos mensuales para pagar la operación crediticia" },
            {"PA" ,"Política de Crédito de la Empresa" },
            {"TU" ,"Solicitud rechazada por Política de Crédito de la Empresa" },
            {"3" ,"Por Política de Crédito de la Empresa" },
            {"11" ,"Existencia de Procedimientos Judiciales/Administrativos" },
            {"15" ,"Por firma disconforme" },
            {"16" ,"No cumple con el nivel mínimo de aprobación" },
            {"C9" ,"Incumplimiento previo de una obligación contraída con la Empresa, sus filiales o relacionadas (BC)" },
            {"FH" ,"Obligaciones morosas o protestadas en el sistema financiero (ME)" },
            {"HQ" ,"Ingresos insuficientes de acuerdo a la Política de Crédito" },
            {"UF" ,"No cumple con el nivel mínimo de aprobación crediticia previsto en el análisis de riesgo" },
            {"EC" ,"Solicitud rechazada por Política de Crédito de la Empresa" },
            {"DZ" ,"Advertencia: Revisar fecha de nacimiento, persona menor de edad" },
            {"DY" ,"Advertencia: Persona con marca Fallecido en Registro Civil" },
            {"DX" ,"Solicitud rechazada por Política de Crédito de la Empresa" },
            {"GP" ,"Obligaciones morosas o protestadas en el sistema financiero" },
            {"DL" ,"No cumple con la antigüedad laboral de acuerdo a Política de Crédito" },
            {"S1" ,"Solicitud rechazada por falta información de Bureau (DICOM EQUIFAX)" },
            {"D6" ,"Combinación de productos no válida" },
            {"D0" ,"Incumplimiento previo de una obligación contraída con la Empresa, sus filiales o relacionadas" },
            {"HL" ,"Solicitud rechazada por Política de Crédito de la Empresa" },
            {"CM" ,"Incumplimiento de los parámetros objetivos de endeudamientos determinados en la Política de Crédito de la Empresa" }
           };
        }
    }
}
