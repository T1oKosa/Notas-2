﻿namespace Plugin.ApiIntegration.Ofertas.Models
{
    public abstract class Oferta
    {
        public string id { get; set; }
        public int status { get; set; }
        public string resource { get; set; }
        //public List<Datum> data { get; set; }
        public Metadata metadata { get; set; }
    }
    public class Metadata
    {
        // [JsonProperty("X-B3-SpanId")]
        public string XB3SpanId { get; set; }

        // [JsonProperty("X-B3-TraceId")]
        public string XB3TraceId { get; set; }
    }
}
