﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plugin.ApiIntegration.Ofertas.Models
{
    public class RequestSolicitaReemision
    {
        public string documento_identificacion_solicitante { get; set; }
        public string digito_verificador_solicitante { get; set; }
        public string motivo_reemision { get; set; }
        public string guid_solicitud { get; set; }
        public string numero_solicitud { get; set; }
        public string codigo_negocio { get; set; }
        public string codigo_sucursal { get; set; }
        public string documento_identificacion_ejecutivo { get; set; }
        public string digito_verificador_ejecutivo { get; set; }
        public string nombre_cliente { get; set; }
        public string apellido_cliente { get; set; }
    }
}
