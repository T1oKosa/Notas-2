﻿extern alias GComponents;

using GComponents::Axxon.GlobalComponents;
using GComponents::Axxon.GlobalComponents.Helper;
using GComponents::Axxon.GlobalComponents.Model;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Plugin.ApiIntegration.Ofertas.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plugin.ApiIntegration.Ofertas.Service
{
    public static class CRMQueries
    {
        public static Producto GetProducto(PluginContext ctx, Guid idProducto)
        {
            var result = ctx.CachedEntities.GetProduct(idProducto);

            Producto producto = new Producto();
            if (result != null)
            {
                producto.Nombre = result.Name;
                producto.Selecionable = GetSelecionable(ctx, idProducto);
                producto.Simulable = result.RequiereSimulacion;
                producto.Id = idProducto.ToString();
                producto.Codigo = result.Codigo;
                producto.Logo = result.Logo;
                producto.Orden = result.Orden.Value;
            }

            return producto;
        }


        public static bool GetSelecionable(PluginContext ctx, Guid idproducto)
        {
            return ctx.CachedEntities.ProductoSucursal(idproducto, ctx.Context.UserId).Seleccionable;
        }

        public static string getLogo(PluginContext ctx, int codigo)
        {
            ctx.TracingService.Trace($"obteniendo logo");
            ctx.TracingService.Trace($"obteniendo logo - > {codigo}");
            Product result = new Product();
            try
            {
                result = ctx.CachedEntities.GetProductByGrupo(codigo.ToString());
            }
            catch (Exception ex)
            {
                ctx.Trace($"Error en la busqueda del logo {ex.Message}");
            }
            ctx.TracingService.Trace($"Producto - " + result.Name);
            ctx.TracingService.Trace($"Logo - " + result.Logo);
            return result.Logo;
        }

        public static Entity GetCajaPOS(PluginContext ctx, string numeroCaja, string codigoSap)
        {
            QueryExpression queryCaja = new QueryExpression("axx_cajapos");
            queryCaja.ColumnSet = new ColumnSet("axx_codigocaja");
            queryCaja.Criteria.AddCondition("axx_codigocaja", ConditionOperator.Equal, numeroCaja);
            queryCaja.Criteria.AddCondition("axx_codigosap", ConditionOperator.Equal, codigoSap);

            return ctx.Service.RetrieveMultiple(queryCaja).Entities.FirstOrDefault();
        }

        public static Entity GetAccountPorIdCliente(PluginContext ctx, string idCliente)
        {
            QueryExpression queryContact = new QueryExpression("account");
            queryContact.ColumnSet = new ColumnSet("axx_idcliente", "mcs_numeroidentificacion");
            queryContact.Criteria.AddCondition("axx_idcliente", ConditionOperator.Equal, idCliente);

            return ctx.Service.RetrieveMultiple(queryContact).Entities.FirstOrDefault();
        }

        public static Entity GetAccountPorRutCliente(PluginContext ctx, string rut)
        {
            QueryExpression queryPersona = new QueryExpression("account");
            queryPersona.ColumnSet = new ColumnSet("axx_idcliente", "mcs_numeroidentificacion");
            queryPersona.Criteria.AddCondition("mcs_numeroidentificacion", ConditionOperator.Equal, rut);

            return ctx.Service.RetrieveMultiple(queryPersona).Entities.FirstOrDefault();
        }

        public static Entity GetSucursalPorCodigoSAP(PluginContext ctx, string codigoSAP)
        {
            QueryExpression querySucursal = new QueryExpression("mcs_sucursal");
            querySucursal.ColumnSet = new ColumnSet("mcs_name");
            querySucursal.Criteria.AddCondition("axx_codigosap", ConditionOperator.Equal, codigoSAP);

            return ctx.Service.RetrieveMultiple(querySucursal).Entities.FirstOrDefault();
        }

        public static string getLogoByCodigo(PluginContext ctx, string codigo)
        {
            ctx.TracingService.Trace($"obteniendo logo");
            ctx.TracingService.Trace($"obteniendo logo - > {codigo}");
            Product result = new Product();
            try
            {
                result = ctx.CachedEntities.GetProductByCodigoLogo(codigo.ToString());
            }
            catch (Exception ex)
            {
                ctx.Trace($"Error en la busqueda del logo {ex.Message}");
            }
            ctx.TracingService.Trace($"Producto - " + result.Name);
            ctx.TracingService.Trace($"Logo - " + result.Logo);
            return result.Logo;
        }
        public static EntityCollection GetActividadLaboral(PluginContext ctx, string codigo)
        {
            QueryExpression queryExpression = new QueryExpression("mcs_actividadlaboral")
            {
                ColumnSet = new ColumnSet("mcs_actividadlaboralid", "mcs_ocupacionid")
            };
            queryExpression.Criteria.AddCondition("mcs_clienteid", ConditionOperator.Equal, codigo);

            EntityCollection actividad = ctx.Service.RetrieveMultiple(queryExpression);

            return actividad;
        }

        public static Entity ObtenerRegistroHabilitacionAutomotriz(PluginContext ctx, Guid personaId, Guid sucursalId, string campoPersona, string campoSucursal)
        {
            try
            {
                QueryExpression query = new QueryExpression("axx_habilitadoparaofertaautomotriz")
                {
                    ColumnSet = new ColumnSet("axx_habilitadaparaofertaautomotriz")
                };
                query.Criteria.AddCondition(campoPersona, ConditionOperator.Equal, personaId.ToString());
                query.Criteria.AddCondition(campoSucursal, ConditionOperator.Equal, sucursalId.ToString());

                return ctx.Service.RetrieveMultiple(query).Entities.FirstOrDefault();
            }
            catch
            {
                return null;
            }
        }

    }


}
