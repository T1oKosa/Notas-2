﻿extern alias GComponents;

using GComponents::Axxon.GlobalComponents;
using GComponents::Axxon.GlobalComponents.Helper;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Plugin.ApiIntegration.Ofertas.Models;
using Plugin.ApiIntegration.Ofertas.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Markup;
using System.Diagnostics;

namespace Plugin.ApiIntegration.Ofertas
{
    public class OfertaSMS : IPlugin
    {
        #region Secure/Unsecure Configuration Setup
        public OfertaSMS()
        {
        }
        #endregion

        private Stopwatch _stopwatch = new Stopwatch();
        public void Execute(IServiceProvider serviceProvider)
        {
            _stopwatch.Start();
            PluginContext ctx = new PluginContext(serviceProvider);
            ctx.Trace("OfertaSMS");

            if (!ctx.Context.InputParameters.Contains("Request") || string.IsNullOrEmpty((string)ctx.Context.InputParameters["Request"]))
                throw new InvalidPluginExecutionException("Es necesario el parametro sms");

            ctx.Trace("Init sms - Get params");
            string _smshitorico = (string)ctx.Context.InputParameters["Request"];
            ctx.Trace($"json - {_smshitorico}");
            ctx.Trace($"Configuración");
            var config = new ConfiguracionesServicios(ctx.IntegrationUserService, ctx.TracingService.TracingService, ctx.Context.OrganizationName);
            string key = config.AesGCMPassword.DatoSeguro;

            ctx.Trace($"SMS Request Json to Object");
            SMSRequest _smsRequest = JsonSerializer.Deserialize<SMSRequest>(_smshitorico);

            ctx.Trace($"AESGCM Decrypt");
            try
            {
                ctx.Trace($"AESGCM Decrypt value {_smsRequest.NumeroDocumento}");
                ctx.Trace($"AESGCM Decrypt key {key}");
                _smsRequest.NumeroDocumentoDesencriptado = AesGCMCryptoService.DecryptAESGCM(_smsRequest.NumeroDocumento, key, ctx);
                ctx.Trace($"AESGCM Decrypt {_smsRequest.NumeroDocumentoDesencriptado}");
                _smsRequest.NumeroDocumentoDesencriptado = FormatearRut(_smsRequest.NumeroDocumentoDesencriptado);
                ctx.Trace($"rut desencriptado y con formato {_smsRequest.NumeroDocumentoDesencriptado}");
            }
            catch (Exception ex)
            {
                ctx.Trace($"AESGCM Decrypt ex {ex.Message}");
            }

            string _response = "";
            ctx.Trace($"Save");
            try
            {
                _response = Save(_smsRequest, ctx);

                ctx.Trace($"Save - {_response}");

                ctx.Context.OutputParameters["Response"] = $"Proceso correcto: {_response}";
            }
            catch (Exception ex)
            {
                ctx.Trace($"Save error - {ex.Message}");
                ctx.Context.OutputParameters["Error"] = $"Error: {ex.Message}";
            }

        }
        private string Save(SMSRequest request, PluginContext ctx)
        {
            ctx.Trace("Busqueda del cliente");
            Entity account = CRMQueries.GetAccountPorRutCliente(ctx, request.NumeroDocumentoDesencriptado);

            bool notificacionCreada = CrearNotificacionPosCaptadores(ctx, request, account);

            string mensajeNotificacion = notificacionCreada ? "Notificación creada correctamente" : "Notificación no se pudo crear";

            return $"'{mensajeNotificacion}'";
        }

        private bool CrearNotificacionPosCaptadores(PluginContext ctx, SMSRequest request, Entity account)
        {
            ctx.Trace("Crear Notificacion");
            try
            {
                Entity notificacionCaptadores = new Entity("axx_notificacionesposcaptadores");

                ctx.Trace("Crear Notificacion - axx_caja");
                EntityReference cajaPOSReference = ObtenerCajaPOS(ctx, request);
                if (cajaPOSReference == default || cajaPOSReference == null)
                {
                    ctx.Trace($"Notificacion - No se encontro caja");
                    return false;
                }
                notificacionCaptadores["axx_caja"] = cajaPOSReference;

                ctx.Trace("Crear Notificacion - axx_oferta");
                if (string.IsNullOrEmpty(request.codigo_producto))
                {
                    ctx.Trace("Crear Notificacion - no viene codigo producto");
                    return false;
                }
                var producto = ctx.CachedEntities.GetProductByProductNumber(request.codigo_producto);
                if (producto == null)
                {
                    ctx.Trace($"Crear Notificacion - no se encontro el producto con codigo: {request.codigo_producto}");
                    return false;
                }
                notificacionCaptadores["axx_oferta"] = new EntityReference("axx_productocat", producto.ProductId);

                notificacionCaptadores["axx_name"] = "Notificaciones POS Captadores";
                ctx.Trace("Crear Notificacion - axx_cliente");
                if (account != null && account != default)
                {
                    notificacionCaptadores["axx_cliente"] = account.ToEntityReference();
                }
                ctx.Trace("Crear Notificacion - axx_nombrecliente");
                notificacionCaptadores["axx_nombrecliente"] = request.nombre_completo;
                ctx.Trace("Crear Notificacion - axx_usuarioenviasmsdigevo");
                notificacionCaptadores["axx_usuarioenviasmsdigevo"] = request.usuario_digevo;
                ctx.Trace("Crear Notificacion - axx_rutcliente");
                notificacionCaptadores["axx_rutcliente"] = !string.IsNullOrEmpty(request.NumeroDocumentoDesencriptado) ? request.NumeroDocumentoDesencriptado : account["mcs_numeroidentificacion"].ToString();
                ;
                ctx.Trace("Crear Notificacion - axx_montoofertado");
                notificacionCaptadores["axx_montoofertado"] = new Money(Monto(request.Monto_Ofertado));

                notificacionCaptadores["axx_numerodetelefono"] = !string.IsNullOrEmpty(request.Telefono) ? request.Telefono : "";

                _stopwatch.Stop();
                long milisegundosHastaCreacionNotificacion = _stopwatch.ElapsedMilliseconds;
                ctx.Trace($"milisegundos en crear notificacion: {milisegundosHastaCreacionNotificacion}");
                milisegundosHastaCreacionNotificacion += request.cajas.tiempo_total_ejecucion;
                ctx.Trace($"milisegundos tiempo back: {request.cajas.tiempo_total_ejecucion}");
                ctx.Trace($"milisegundos en crear notificacion + tiempo back: {milisegundosHastaCreacionNotificacion}");

                ctx.Trace("milisegundos en crear notificacion");
                notificacionCaptadores["axx_milisegundosejecucionnotificacion"] = milisegundosHastaCreacionNotificacion;

                ctx.Trace("Crear Notificacion - ejecuta crear");
                ctx.Service.Create(notificacionCaptadores);

                return true;
            }
            catch (Exception ex)
            {
                ctx.Trace($"Notificacion Error - {ex.Message}");
                return false;
            }
        }

        private EntityReference ObtenerCajaPOS(PluginContext ctx, SMSRequest request)
        {
            ctx.Trace("ObtenerCajaPOS");
            EntityReference cajaPOSReference = default;

            if (!string.IsNullOrEmpty(request.cajas.guid_caja))
            {
                ctx.Trace("ObtenerCajaPOS - se recibe guid de caja");
                cajaPOSReference = new EntityReference("axx_cajapos", new Guid(request.cajas.guid_caja));
                return cajaPOSReference;
            }

            Entity cajaPOS = CRMQueries.GetCajaPOS(ctx, request.cajas.numero_caja.ToString(), request.cajas.codigo_sap);
            if (cajaPOS == null || cajaPOS == default)
            {
                ctx.Trace("ObtenerCajaPOS - procede a crear una nueva caja");
                Guid idNuevaCajaPOS = CrearCajaPOS(ctx, request);

                if(idNuevaCajaPOS != default)
                    cajaPOSReference = new EntityReference("axx_cajapos", idNuevaCajaPOS);
                return cajaPOSReference;
            }
            else
            {
                ctx.Trace("ObtenerCajaPOS - Se encuentra caja");
                cajaPOSReference = cajaPOS.ToEntityReference();
            }

            return cajaPOSReference;
        }

        private Guid CrearCajaPOS(PluginContext ctx, SMSRequest request)
        {
            ctx.Trace("Crear CajaPOS");
            try
            {
                CajaInfo caja = request.cajas;

                Entity cajaPos = new Entity("axx_cajapos");

                Entity sucursal = CRMQueries.GetSucursalPorCodigoSAP(ctx, caja.codigo_sap);
                if (sucursal != default)
                {
                    cajaPos["axx_sucursal"] = sucursal.ToEntityReference();
                }
                else
                {
                    return default(Guid);
                }

                    ctx.Trace("Crear CajaPOS - axx_name");
                cajaPos["axx_name"] = caja.nombre_caja;
                ctx.Trace("Crear CajaPOS - axx_codigocaja");
                cajaPos["axx_codigocaja"] = caja.numero_caja.ToString();
                ctx.Trace("Crear CajaPOS - axx_retail");
                if (request.IdRetail_origen != default(Guid))
                {
                    cajaPos["axx_retail"] = new EntityReference("mcs_grupo", request.IdRetail_origen);
                }
                ctx.Trace("Crear CajaPOS - axx_sucursaltexto");
                cajaPos["axx_sucursaltexto"] = caja.sucursal;

                ctx.Trace("Crear CajaPOS - axx_tipodispositivo");
                cajaPos["axx_tipodispositivo"] = caja.tipo_dispositivo;
                ctx.Trace("Crear CajaPOS - axx_piso");
                cajaPos["axx_piso"] = caja.piso;
                ctx.Trace("Crear CajaPOS - axx_codigosap");
                cajaPos["axx_codigosap"] = caja.codigo_sap;

                ctx.Trace("Crear CajaPOS - ejecuta crear");
                return ctx.Service.Create(cajaPos);
            }
            catch (Exception ex)
            {
                ctx.Trace($"Crear CajaPOS Error - {ex.Message}");
                return default(Guid);
            }
        }

        public Decimal Monto(string value)
        {
            decimal monto = 0;
            if (!string.IsNullOrEmpty(value))
            {
                decimal.TryParse(value, out monto);
            }
            return (Decimal)Math.Round(monto, 0);
        }


        public string FormatearRut(string rutSinFormato)
        {
            if (string.IsNullOrWhiteSpace(rutSinFormato) || rutSinFormato.Length < 2)
                return rutSinFormato;

            // Separar cuerpo del dígito verificador
            string cuerpo = rutSinFormato.Substring(0, rutSinFormato.Length - 1);
            string dv = rutSinFormato.Substring(rutSinFormato.Length - 1);

            // Agregar puntos cada tres dígitos desde la derecha
            cuerpo = Int64.Parse(cuerpo).ToString("N0").Replace(",", ".");

            return $"{cuerpo}-{dv}";
        }


    }
}
