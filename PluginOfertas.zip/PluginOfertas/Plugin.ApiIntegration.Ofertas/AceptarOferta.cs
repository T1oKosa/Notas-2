﻿extern alias GComponents;

using GComponents::Axxon.GlobalComponents.Cache;
using GComponents::Axxon.GlobalComponents.Helper;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Linq;
using System;
using GComponents::Axxon.GlobalComponents.Model;
using GComponents::Axxon.GlobalComponents.OptionSets;
using System.Collections.Generic;
using static GComponents::Axxon.GlobalComponents.Helper.Enums;
using System.Globalization;
using System.Web.Caching;
using System.Web.Util;
using System.Text.RegularExpressions;
using System.Text;

namespace Plugin.ApiIntegration.Ofertas
{
    public class AceptarOferta : IPlugin
    {
        #region Secure/Unsecure Configuration Setup
        private string _secureConfig = null;
        private string _unsecureConfig = null;

        public AceptarOferta(string unsecureConfig, string secureConfig)
        {
            _secureConfig = secureConfig;
            _unsecureConfig = unsecureConfig;
        }
        public AceptarOferta()
        {

        }
        #endregion
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracer = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = factory.CreateOrganizationService(context.UserId);
            PluginContext ctx = new PluginContext(serviceProvider);
            var ofertasAprobadasJson = (String)context.InputParameters["OfertasAprobadas"];
            var ofertasPreAprobadasJson = (String)context.InputParameters["OfertasPreAprobadas"];
            var ofertasComplementariasJson = (String)context.InputParameters["OfertasComplementarias"];
            int origenTabletEEFF = (int)context.InputParameters["OrigenTabletEEFF"];

            //init variables
            int autorizador = 0;
            int autorizadorVenta = 0;
            try
            {
                tracer.Trace($"Ofertas aprobadas: {ofertasAprobadasJson}");
                tracer.Trace($"Ofertas pre aprobadas: {ofertasPreAprobadasJson}");
                tracer.Trace($"Ofertas complementarias: {ofertasComplementariasJson}");

                EntityReference entity = (EntityReference)context.InputParameters["Target"];
                //No se trae de cache, por que si se valido AML y se modificaron datos del cliente, hay que traerlos de nuevo.
                var cliente = ctx.CachedEntities.GetClient(entity.Id, true);
                //De aca puedo sacar la sucursal
                List<Oferta> ofertasAprobadas = String.IsNullOrEmpty(ofertasAprobadasJson) ? new List<Oferta>() : JsonSerializer.Deserialize<List<Oferta>>(ofertasAprobadasJson);
                List<Oferta> ofertasPreAprobadas = String.IsNullOrEmpty(ofertasPreAprobadasJson) ? new List<Oferta>() : JsonSerializer.Deserialize<List<Oferta>>(ofertasPreAprobadasJson);
                List<OfertaComplementaria> ofertasComplementarias = String.IsNullOrEmpty(ofertasComplementariasJson) ? new List<OfertaComplementaria>() : JsonSerializer.Deserialize<List<OfertaComplementaria>>(ofertasComplementariasJson);
                List<Oferta> ofertas = new List<Oferta>();
                var ejecutivo = ctx.CachedEntities.GetUser(context.InitiatingUserId);
                if (ofertasAprobadas.Count > 0 && !string.IsNullOrEmpty(ofertasAprobadas.FirstOrDefault().id_ejecutivo))
                {
                    ejecutivo = ctx.CachedEntities.GetUser(new Guid(ofertasAprobadas.FirstOrDefault().id_ejecutivo));
                }
                ofertas.AddRange(ofertasAprobadas);
                ofertas.AddRange(ofertasPreAprobadas);
                ofertas.AddRange(ofertasComplementarias);
                tracer.Trace($"Cantidad ofertas: {ofertas.Count}");


                Entity datosClienteAdicionales = ctx.Service.Retrieve("account", cliente.Id, new ColumnSet("mcs_correoelectronicoprincipalid", "mcs_direccionprincipalid", "mcs_telefonoprincipalid", "mcs_profesionid", "mcs_fechanacimiento"));

                String verificacionAml = VerificarAMLOportunidad(ctx, ofertas);
                ctx.Trace("Verificacion AML: " + verificacionAml);
                if (!String.IsNullOrEmpty(verificacionAml))
                {
                    tracer.Trace("VerificarAMLOportunidad: " + verificacionAml);
                    context.OutputParameters["Error"] = verificacionAml;
                    context.OutputParameters["ValidarAML"] = true;
                    return;
                }
                //Obtener sucursal y id producto
                #region Obtener Sucursal
                string sucursal_ = ejecutivo.Sucursal.EntityReference.Id.ToString();

                var querySuc = new QueryExpression("mcs_sucursal");
                querySuc.ColumnSet.AddColumns("axx_espontaneamedianteventa");
                querySuc.Criteria.AddCondition("mcs_sucursalid", ConditionOperator.Equal, sucursal_);

                Entity resultsuc = ctx.IntegrationUserService.RetrieveMultiple(querySuc).Entities.FirstOrDefault();
                #endregion
                #region ObtencionProductoSucursal
                if (ofertas.Any())
                {
                    if (ofertas.First().monto.valor == 1)
                    {
                        tracer.Trace($"1 Peso");
                        tracer.Trace($"Ingresa a Crear Venta");
                        Guid axx_ventaId = GenerarVentaEspontanea(ctx, ofertas.First(), cliente, ejecutivo, out autorizadorVenta, datosClienteAdicionales, origenTabletEEFF, service);
                        //Añadir Actividad laboral de oportunidad en Venta:
                        tracer.Trace($"idCliente:" + cliente.Id);
                        QueryExpression queryAL = new QueryExpression("mcs_actividadlaboral");
                        queryAL.TopCount = 1;
                        queryAL.ColumnSet.AddColumns("mcs_rentadeclaradaofuscadoid", "mcs_rentaliquida", "mcs_actividadlaboralid", "axx_fechademodificacion", "mcs_actividadeconomicaid", "mcs_actividadlaboral");
                        queryAL.AddOrder("axx_fechademodificacion", OrderType.Descending);
                        queryAL.Criteria.AddCondition("mcs_clienteid", ConditionOperator.Equal, cliente.Id);
                        queryAL.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);
                        EntityCollection actividadLaboral = service.RetrieveMultiple(queryAL);
                        tracer.Trace($"Actividades laborales encontradas= {actividadLaboral.Entities.Count}");
                        if (actividadLaboral.Entities.Count > 0)
                        {
                            tracer.Trace($"Tiene actividad Laboral");
                            if (actividadLaboral[0].Id != null)
                            {
                                tracer.Trace($"Tiene actividad Laboral");
                                Entity newActividadLaboralOpt = new Entity("mcs_actividadlaboraldeoportunidad");
                                newActividadLaboralOpt["mcs_name"] = actividadLaboral[0].Attributes["mcs_actividadlaboral"].ToString();
                                newActividadLaboralOpt["axx_ventadeactividadlaboraldeoportunidad"] = new EntityReference("axx_venta", axx_ventaId);
                                newActividadLaboralOpt["mcs_actividadlaboral"] = new EntityReference("mcs_actividadlaboral", actividadLaboral[0].Id); //IdActividadLaboral
                                newActividadLaboralOpt["mcs_persona"] = new EntityReference("account", cliente.Id);//Cliente
                                newActividadLaboralOpt["ownerid"] = new EntityReference("systemuser", ejecutivo.Id); //ejecutivo
                                newActividadLaboralOpt["mcs_documentacinadjunta"] = false;
                                newActividadLaboralOpt["mcs_permiteingresarrentasdependientes"] = true;
                                Guid idNewActividadLaboralOpt = ctx.Service.Create(newActividadLaboralOpt);

                                tracer.Trace($"Genero actividad Laboral: {idNewActividadLaboralOpt}");

                                Entity venta = new Entity("axx_venta", axx_ventaId);
                                venta["axx_actividadlaboral"] = new EntityReference(actividadLaboral[0].LogicalName, actividadLaboral[0].Id);
                                venta["axx_actividadlaboralpersona"] = new EntityReference("mcs_actividadlaboraldeoportunidad", idNewActividadLaboralOpt);

                                tracer.Trace($"Se procede a actualizar venta con actividad laboral");
                                ctx.Service.Update(venta);
                                tracer.Trace($"Se actualizo venta");

                            }
                        }
                        //generar nueva logica para editar Venta añadiendo campos del nuevo ProductoOpt:
                        EditarDatosVentaProd(ctx, ofertas, cliente, ejecutivo, axx_ventaId);

                        //si aprobada movemos a Negociación LA VENTA
                        if (autorizadorVenta == (int)mcs_autorizacin.Aprobada)
                        {
                            PasarANegociacionVenta(ctx, axx_ventaId, ejecutivo.Canal?.Codigo);
                            ctx.Trace("PasarANegociacion OK...");
                        }

                        if (autorizadorVenta != (int)mcs_autorizacin.Pendiente)
                        {
                            Entity venta = new Entity("axx_venta", axx_ventaId);
                            venta["mcs_autorizacion"] = new OptionSetValue(autorizadorVenta);//OK COPIADO

                            ctx.Service.Update(venta);
                        }
                        ctx.Trace("Validaciones autorizador OK...");
                        ctx.Trace("GUID Venta: " + axx_ventaId);
                        context.OutputParameters["ResponseVenta"] = new EntityReference("axx_venta", axx_ventaId);
                    }
                    else
                    {
                        Guid id_producto = Guid.Parse(ofertas[0].productId.ToString());
                        string sucursal_ejecutivo = ejecutivo.Sucursal.EntityReference.Id.ToString();
                        tracer.Trace($"ID_Producto: {ofertas[0].productId.ToString()}");
                        tracer.Trace($"ID_Sucursal: {ejecutivo.Sucursal.EntityReference.Id.ToString()}");
                        //realizar query a mcs_productosucursal:
                        tracer.Trace($"Valida el id producto -> {id_producto}");
                        if (id_producto == Guid.Empty)
                        {
                            tracer.Trace($"GetProductByCodigo -> parametro de ingreso {ofertas[0].codigo}");
                            var producto = ctx.CachedEntities.GetProductByCodigo(ofertas[0].codigo);
                            if (producto == null)
                            {
                                tracer.Trace($"GetProductByCodigo -> Retorno -> Null");
                                String msg = $"No puede vender el producto seleccionado {ofertas[0].codigo}, no se encuentra creado en el catálogo";
                                throw new Exception(msg);
                            }
                            else
                            {
                                id_producto = producto.ProductId;
                            }
                        }
                        tracer.Trace($"Busqueda de mcs_productosucursal");
                        var prodsucursal = ctx.CachedEntities.ProductoSucursal(id_producto, ejecutivo.Id);

                        if (!prodsucursal.GenerarVenta)
                        {
                            String listErrores = VerificarCompatibilidadOportunidad(ctx, ofertas);
                            if (!String.IsNullOrEmpty(listErrores))
                            {
                                tracer.Trace("VerificarCompatibilidadOportunidad: " + listErrores);
                                context.OutputParameters["Error"] = listErrores;
                                return;
                            }
                            //CAMINO DE OPT
                            tracer.Trace($"GenerarOportunidad");
                            tracer.Trace($"GenerarOportunidad -> Parametros entrada");
                            tracer.Trace($"GenerarOportunidad -> Parametros entrada ->lista ofertas: {ofertas.Count} - Cliente: {cliente.Name} - ejecutivo: {ejecutivo.FullName} - autorizador: {autorizador} - datosClienteAdicionales: {datosClienteAdicionales}");
                            Guid opportunityId = GenerarOportunidad(ctx, ofertas, cliente, ejecutivo, out autorizador, datosClienteAdicionales);
                            tracer.Trace($"GenerarOportunidad -> Resultado -> {opportunityId}");
                            CrearProductosDeOportunidad(ctx, ofertas, cliente, ejecutivo, opportunityId, datosClienteAdicionales);
                            //si aprobada movemos a Negociación
                            if (autorizador == (int)mcs_autorizacin.Aprobada)
                            {
                                tracer.Trace($"mcs_autorizacin.Aprobada");
                                tracer.Trace($"Pasar a negocio");
                                tracer.Trace($"Pasar a negocio - > Entrada -> idoportunidad {opportunityId} - canal ejecutivo {ejecutivo.Canal?.Codigo}");
                                PasarANegociacion(ctx, opportunityId, ejecutivo.Canal?.Codigo);
                            }
                            if (autorizador != (int)mcs_autorizacin.Pendiente)
                            {
                                tracer.Trace($"mcs_autorizacin.Pendiente");
                                Entity oportunidad = new Entity("opportunity", opportunityId);
                                oportunidad["mcs_autorizacion"] = new OptionSetValue(autorizador);
                                //Actualizamos en CRM
                                ctx.Service.Update(oportunidad);
                            }
                            context.OutputParameters["Response"] = new EntityReference("opportunity", opportunityId);
                        }
                        else
                        {
                            tracer.Trace($"Generar Venta");
                            tracer.Trace($"Ofertas encontradas: {ofertas.Count()}");
                            //CAMINO DE VENTA
                            Guid axx_ventaId = GenerarVenta(ctx, ofertas.First(), cliente, ejecutivo, out autorizadorVenta, datosClienteAdicionales, origenTabletEEFF, service);
                            //Añadir Actividad laboral de oportunidad en Venta:

                            QueryExpression queryAL = new QueryExpression("mcs_actividadlaboral");
                            queryAL.TopCount = 1;
                            queryAL.ColumnSet.AddColumns("mcs_rentadeclaradaofuscadoid", "mcs_rentaliquida", "mcs_actividadlaboralid", "axx_fechademodificacion", "mcs_actividadeconomicaid", "mcs_actividadlaboral");
                            queryAL.AddOrder("axx_fechademodificacion", OrderType.Descending);
                            queryAL.Criteria.AddCondition("mcs_clienteid", ConditionOperator.Equal, cliente.Id);
                            queryAL.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);
                            EntityCollection actividadLaboral = service.RetrieveMultiple(queryAL);
                            if (actividadLaboral.Entities.Count > 0)
                            {
                                tracer.Trace($"Tiene actividad Laboral");
                                if (actividadLaboral[0].Id != null)
                                {
                                    tracer.Trace($"Tiene actividad Laboral");
                                    Entity newActividadLaboralOpt = new Entity("mcs_actividadlaboraldeoportunidad");
                                    newActividadLaboralOpt["mcs_name"] = actividadLaboral[0].Attributes["mcs_actividadlaboral"].ToString();
                                    newActividadLaboralOpt["axx_ventadeactividadlaboraldeoportunidad"] = new EntityReference("axx_venta", axx_ventaId);
                                    newActividadLaboralOpt["mcs_actividadlaboral"] = new EntityReference("mcs_actividadlaboral", actividadLaboral[0].Id); //IdActividadLaboral
                                    newActividadLaboralOpt["mcs_persona"] = new EntityReference("account", cliente.Id);//Cliente
                                    newActividadLaboralOpt["ownerid"] = new EntityReference("systemuser", ejecutivo.Id); //ejecutivo
                                    newActividadLaboralOpt["mcs_documentacinadjunta"] = false;
                                    newActividadLaboralOpt["mcs_permiteingresarrentasdependientes"] = true;
                                    Guid idNewActividadLaboralOpt = ctx.Service.Create(newActividadLaboralOpt);
                                    tracer.Trace($"idNewActividadLaboralOpt: {idNewActividadLaboralOpt}");

                                    Entity venta = new Entity("axx_venta", axx_ventaId);
                                    venta["axx_actividadlaboral"] = new EntityReference(actividadLaboral[0].LogicalName, actividadLaboral[0].Id);
                                    venta["axx_actividadlaboralpersona"] = new EntityReference("mcs_actividadlaboraldeoportunidad", idNewActividadLaboralOpt);
                                    tracer.Trace($"Actualizando actividad laboral en la venta");
                                    ctx.Service.Update(venta);
                                    tracer.Trace($"Se actualiza sin problemas");
                                }
                            }
                            //generar nueva logica para editar Venta añadiendo campos del nuevo ProductoOpt:
                            EditarDatosVentaProd(ctx, ofertas, cliente, ejecutivo, axx_ventaId);

                            //si aprobada movemos a Negociación LA VENTA
                            if (autorizadorVenta == (int)mcs_autorizacin.Aprobada)
                            {
                                PasarANegociacionVenta(ctx, axx_ventaId, ejecutivo.Canal?.Codigo);
                                ctx.Trace("PasarANegociacion OK...");
                            }

                            if (autorizadorVenta != (int)mcs_autorizacin.Pendiente)
                            {
                                Entity venta = new Entity("axx_venta", axx_ventaId);
                                venta["mcs_autorizacion"] = new OptionSetValue(autorizadorVenta);//OK COPIADO

                                ctx.Service.Update(venta);
                            }
                            ctx.Trace("Validaciones autorizador OK...");
                            ctx.Trace("GUID Venta: " + axx_ventaId);
                            context.OutputParameters["ResponseVenta"] = new EntityReference("axx_venta", axx_ventaId);
                        }
                    }
                }
                else
                {
                    if (resultsuc.GetAttributeValue<bool>("axx_espontaneamedianteventa"))
                    {
                        tracer.Trace($"Ingresa a Crear Venta");
                        Guid axx_ventaId = GenerarVentaEspontanea(ctx, null, cliente, ejecutivo, out autorizadorVenta, datosClienteAdicionales, origenTabletEEFF, service);
                        //Añadir Actividad laboral de oportunidad en Venta:
                        tracer.Trace($"idCliente:" + cliente.Id);
                        QueryExpression queryAL = new QueryExpression("mcs_actividadlaboral");
                        queryAL.TopCount = 1;
                        queryAL.ColumnSet.AddColumns("mcs_rentadeclaradaofuscadoid", "mcs_rentaliquida", "mcs_actividadlaboralid", "axx_fechademodificacion", "mcs_actividadeconomicaid", "mcs_actividadlaboral");
                        queryAL.AddOrder("axx_fechademodificacion", OrderType.Descending);
                        queryAL.Criteria.AddCondition("mcs_clienteid", ConditionOperator.Equal, cliente.Id);
                        queryAL.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);
                        EntityCollection actividadLaboral = service.RetrieveMultiple(queryAL);
                        tracer.Trace($"actividades laborales encontradas= {actividadLaboral.Entities.Count}");
                        if (actividadLaboral.Entities.Count > 0)
                        {
                            tracer.Trace($"Tiene actividad Laboral");
                            if (actividadLaboral[0].Id != null)
                            {
                                tracer.Trace($"Tiene actividad Laboral");
                                Entity newActividadLaboralOpt = new Entity("mcs_actividadlaboraldeoportunidad");
                                newActividadLaboralOpt["mcs_name"] = actividadLaboral[0].Attributes["mcs_actividadlaboral"].ToString();
                                newActividadLaboralOpt["axx_ventadeactividadlaboraldeoportunidad"] = new EntityReference("axx_venta", axx_ventaId);
                                newActividadLaboralOpt["mcs_actividadlaboral"] = new EntityReference("mcs_actividadlaboral", actividadLaboral[0].Id); //IdActividadLaboral
                                newActividadLaboralOpt["mcs_persona"] = new EntityReference("account", cliente.Id);//Cliente
                                newActividadLaboralOpt["ownerid"] = new EntityReference("systemuser", ejecutivo.Id); //ejecutivo
                                newActividadLaboralOpt["mcs_documentacinadjunta"] = false;
                                newActividadLaboralOpt["mcs_permiteingresarrentasdependientes"] = true;
                                Guid idNewActividadLaboralOpt = ctx.Service.Create(newActividadLaboralOpt);
                                tracer.Trace($"idNewActividadLaboralOpt: {idNewActividadLaboralOpt}");

                                Entity venta = new Entity("axx_venta", axx_ventaId);
                                venta["axx_actividadlaboral"] = new EntityReference(actividadLaboral[0].LogicalName, actividadLaboral[0].Id);
                                venta["axx_actividadlaboralpersona"] = new EntityReference("mcs_actividadlaboraldeoportunidad", idNewActividadLaboralOpt);
                                tracer.Trace($"Actualizando actividad laboral en la venta");
                                ctx.Service.Update(venta);
                                tracer.Trace($"Se actualiza sin problemas");
                            }
                        }
                        //generar nueva logica para editar Venta añadiendo campos del nuevo ProductoOpt:
                        EditarDatosVentaProd(ctx, ofertas, cliente, ejecutivo, axx_ventaId);

                        //si aprobada movemos a Negociación LA VENTA
                        if (autorizadorVenta == (int)mcs_autorizacin.Aprobada)
                        {
                            PasarANegociacionVenta(ctx, axx_ventaId, ejecutivo.Canal?.Codigo);
                            ctx.Trace("PasarANegociacion OK...");
                        }

                        if (autorizadorVenta != (int)mcs_autorizacin.Pendiente)
                        {
                            Entity venta = new Entity("axx_venta", axx_ventaId);
                            venta["mcs_autorizacion"] = new OptionSetValue(autorizadorVenta);//OK COPIADO

                            ctx.Service.Update(venta);
                        }
                        ctx.Trace("Validaciones autorizador OK...");
                        ctx.Trace("GUID Venta: " + axx_ventaId);
                        context.OutputParameters["ResponseVenta"] = new EntityReference("axx_venta", axx_ventaId);
                    }
                    else
                    {
                        tracer.Trace($"Ingresa a Crear Oportunidad");
                        Guid opportunityId = GenerarOportunidad(ctx, ofertas, cliente, ejecutivo, out autorizador, datosClienteAdicionales);
                        tracer.Trace($"GenerarOportunidad -> Resultado -> {opportunityId}");
                        context.OutputParameters["Response"] = new EntityReference("opportunity", opportunityId);
                    }

                }
                #endregion
            }
            catch (Exception e)
            {
                ctx.Trace("Error: " + e.Message);
                context.OutputParameters["Error"] = e.Message;
            }
        }

        /// <summary>
        /// Enumerado que contiene los estados Gestion Telefonica
        /// </summary>
        public enum StatusCodeGestionTelefonica
        {
            Vencido = 321890001,
            SinGestion = 1,
            EnGestion = 803750000,
            Cerrada = 803750001,
            Cerrado = 2,
            Cancelado = 3,
            Programado = 4
        }

        /// <summary>
        /// Enumerado que contiene los estados Gestion Telefonica
        /// </summary>
        public enum StateCodeGestionTelefonica
        {
            Abierto = 0,
            Completado = 1,
            Cancelado = 2,
            Programado = 3
        }

        /// <summary>
        /// Enumerado que contiene los Canales
        /// </summary>
        public enum Canales
        {
            EEFF = 120
        }



        public static Guid GenerarOportunidad(PluginContext ctx, List<Oferta> offers, Client cliente, User ejecutivo, out int autorizador, Entity datosClienteAdicionales)
        {
            ctx.Trace("GenerarOportunidad");
            ctx.Trace("Monto Oportunidad" + offers.First().monto.valor);
            //obtener el producto y si es aprobada o preaprobada
            int aprobadas = 0;
            int preaprobadas = 0;
            int ofertas = 0;
            foreach (var ofertaaux in offers)
            {
                var producto = ctx.CachedEntities.GetProductByCodigo(ofertaaux.codigo);
                if (producto == null)
                {
                    String msg = $"No puede vender el producto seleccionado {ofertaaux.codigo}, no se encuentra creado en el catálogo";
                    throw new Exception(msg);
                }
                else
                {
                    ofertaaux.productId = producto.ProductId;
                    if (ofertaaux.tipo_oferta == "APROBADA" || ofertaaux.GetType() == typeof(OfertaComplementaria))
                        aprobadas++;
                    else
                        preaprobadas++;
                    ofertas++;

                }
            }

            autorizador = (int)mcs_autorizacin.Pendiente; //CRM_Autorizador_Pendiente
            int origen = (int)mcs_Origen.Espontaneo; //CRM_Origen_Espontaneo
            //int estadoproducto = (int)mcs_EstadoProductodeOportunidad.RechazadaporExcepcion;
            if (ofertas > 0)
            {
                origen = (int)mcs_Origen.Ofertador;// settings.CRM_Origen_Ofertador;
            }
            if (ofertas > 0 && aprobadas > 0)
            {
                autorizador = (int)mcs_autorizacin.Aprobada;// settings.CRM_Autorizador_Aprobada;
            }

            Entity registroCRM = new Entity("opportunity");

            //Completamos otros campos de la entidad
            registroCRM["mcs_autorid"] = new EntityReference("systemuser", ctx.Context.InitiatingUserId);
            registroCRM["ownerid"] = new EntityReference("systemuser", ejecutivo.Id);
            registroCRM["customerid"] = cliente.EntityReference;
            registroCRM["mcs_canalorigen"] = ejecutivo.Canal.EntityReference;
            registroCRM["mcs_canalusuarioactual"] = ejecutivo.Canal.EntityReference;
            registroCRM["mcs_regionorigenid"] = ejecutivo.Sucursal.Region;
            registroCRM["mcs_retailorigenid"] = ejecutivo.Sucursal.Grupo;
            registroCRM["mcs_autorizacion"] = new OptionSetValue((int)mcs_autorizacin.Pendiente); //conjunto de opciones
            registroCRM["mcs_origen"] = new OptionSetValue(origen); //conjunto de opciones

            var tz = TimeZoneInfo.FindSystemTimeZoneById("Pacific SA Standard Time");
            if (tz.IsInvalidTime(DateTime.Now))
            {
                tz = TimeZoneInfo.FindSystemTimeZoneById("E. South America Standard Time");
            }
            var now = TimeZoneInfo.ConvertTime(DateTime.Now, tz);
            var mes = DateTime.Now.ToString("MMMM", new CultureInfo("es-CL"));
            mes = mes.First().ToString().ToUpper() + mes.Substring(1);

            ctx.Trace($"Fecha Texto: {now}");

            var fechaTexto = now.ToString($"dd 'de {mes} de' yyyy", new CultureInfo("es-CL"));

            if (fechaTexto.StartsWith("0"))
            {
                fechaTexto = fechaTexto.Remove(0, 1);
            }

            registroCRM["axx_fechaaperturatexto"] = fechaTexto;
            registroCRM["mcs_correoelectronicoid"] = datosClienteAdicionales.GetAttributeValue<EntityReference>("mcs_correoelectronicoprincipalid");
            registroCRM["mcs_iddireccionparticular"] = datosClienteAdicionales.GetAttributeValue<EntityReference>("mcs_direccionprincipalid");
            registroCRM["mcs_telefonoprincipalid"] = datosClienteAdicionales.GetAttributeValue<EntityReference>("mcs_telefonoprincipalid");

            Entity auxCaptador = ctx.CachedEntities.GetCaptador(ejecutivo);
            if (auxCaptador != null)
                registroCRM["mcs_captador"] = auxCaptador.ToEntityReference();
            registroCRM["mcs_sucursaldeorigenid"] = ejecutivo.Sucursal.EntityReference;


            var telefonosCliente = GetTelefonosCliente(ctx, cliente.EntityReference.Id);

            foreach (var telefono in telefonosCliente.Entities)
            {
                var tipo = telefono.GetAttributeValue<OptionSetValue>("mcs_tipotelefono")?.Value;
                var telefonoId = telefono.GetAttributeValue<Guid>("mcs_telefonoid");

                if (tipo != null)
                {
                    if (tipo == 10)
                    {
                        ctx.Trace($"Telefono fijo: {telefonoId}");
                        registroCRM["axx_telefonofijoprincipal"] = new EntityReference("mcs_telefono", telefonoId);
                    }

                    if (tipo == 20)
                    {
                        ctx.Trace($"Telefono movil: {telefonoId}");
                        registroCRM["axx_telefonomovilprincipal"] = new EntityReference("mcs_telefono", telefonoId);
                    }
                }
            }

            Guid opportunityId = ctx.Service.Create(registroCRM);
            ctx.Trace("Oportunidad creada: " + opportunityId.ToString());
            return opportunityId;
        }
        //VENTA
        #region VENTA
        public static Guid GenerarVentaEspontanea(PluginContext ctx, Oferta oferta, Client cliente, User ejecutivo, out int autorizadorVenta, Entity datosClienteAdicionales, int origenTabletEEFF, IOrganizationService service)
        {
            autorizadorVenta = (int)mcs_autorizacin.Pendiente; //CRM_Autorizador_Pendiente
            int origen = (int)mcs_Origen.Espontaneo; //CRM_Origen_Espontaneo
            Product productoGestiones = new Product();
            Entity registroCRM = new Entity("axx_venta");
            ctx.Trace("Valida Monto 1 peso");
            if (oferta != null)
            {
                ctx.Trace("Valida Monto 1 peso Valor");
                if (oferta.monto.valor == 1)
                {
                    var producto = ctx.CachedEntities.GetProductByCodigo(oferta.codigo);
                    productoGestiones = producto;
                    registroCRM["axx_productocat"] = new EntityReference("axx_productocat", producto.ProductId);
                    registroCRM["mcs_montoofertado"] = new Money((decimal)1);
                    registroCRM["axx_venta1peso"] = true;
                }

                registroCRM["axx_id_grupo"] = oferta.id_grupo;
            }
            //Completamos otros campos de la entidad
            registroCRM["createdby"] = new EntityReference("systemuser", ctx.Context.InitiatingUserId);//OK
            registroCRM["axx_ventaespontanea"] = true;
            registroCRM["axx_dispositivoorigenventa"] = new OptionSetValue(origenTabletEEFF);
            registroCRM["ownerid"] = registroCRM["createdby"];//OK
            registroCRM["axx_parentaccountid"] = cliente.EntityReference;//OK CREADO / No se pudo establecer en Personalizado su comportamiento solo jerarquico
            registroCRM["mcs_canalorigen"] = ejecutivo.Canal.EntityReference;//Copiado y OK
            registroCRM["mcs_canalusuarioactual"] = ejecutivo.Canal.EntityReference;//Copiado y OK
            registroCRM["mcs_regionorigenid"] = ejecutivo.Sucursal.Region;//Copiado y OK
            registroCRM["mcs_retailorigenid"] = ejecutivo.Sucursal.Grupo;//Copiado y OK
            registroCRM["mcs_autorizacion"] = new OptionSetValue((int)mcs_autorizacin.Pendiente); //conjunto de opciones //Copiado y OK
            registroCRM["mcs_origen"] = new OptionSetValue(origen); //conjunto de opciones //Copiado y OK  //SE-029
            registroCRM["axx_origen"] = new OptionSetValue(origen); //conjunto de opciones //Copiado y OK  //SE-029
            registroCRM["mcs_persona"] = new EntityReference("account", cliente.Id);//Cliente
            registroCRM["axx_numerodeidentificacion"] = cliente.NumeroIdentificacion; //Añadir NúmeroDeIdentificacion
                                                                                      // registroCRM["axx_idautorizacioncurseapertura"] = oferta.id_autorizacion; //Id Autorizacion
            registroCRM["transactioncurrencyid"] = cliente.TransaccionCurrency;//OK


            //Datos Titular
            var tz = TimeZoneInfo.FindSystemTimeZoneById("Pacific SA Standard Time");
            if (tz.IsInvalidTime(DateTime.Now))
            {
                tz = TimeZoneInfo.FindSystemTimeZoneById("E. South America Standard Time");
            }
            var now = TimeZoneInfo.ConvertTime(DateTime.Now, tz);
            var mes = DateTime.Now.ToString("MMMM", new CultureInfo("es-CL"));
            mes = mes.First().ToString().ToUpper() + mes.Substring(1);

            ctx.Trace($"Fecha Texto: {now}");
            var fechaTexto = now.ToString($"dd 'de {mes} de' yyyy", new CultureInfo("es-CL"));

            if (fechaTexto.StartsWith("0"))
            {
                fechaTexto = fechaTexto.Remove(0, 1);
            }
            //string palabaConTildes = "áéíóúñ";

            string _primernombre = Regex.Replace(cliente.PrimerNombre.Normalize(NormalizationForm.FormD), @"[^a-zA-z0-9 ]+", "");
            string _apelliodopaterno = Regex.Replace(cliente.ApellidoPaterno.Normalize(NormalizationForm.FormD), @"[^a-zA-z0-9 ]+", "");
            string _apelliodomaterno = Regex.Replace(cliente.ApellidoMaterno.Normalize(NormalizationForm.FormD), @"[^a-zA-z0-9 ]+", "");

            registroCRM["axx_nombreembozado"] = _primernombre.ToUpper();
            registroCRM["axx_apellidosembozado"] = _apelliodopaterno.ToUpper();


            ctx.Trace($"Primer nombre: {cliente.PrimerNombre.ToUpper()}");
            ctx.Trace($"Apellido Paterno: {cliente.ApellidoPaterno.ToUpper()}");
            ctx.Trace($"Apellido Materno: {cliente.ApellidoMaterno.ToUpper()}");

            //Datos Upgrade
            string nombreCompleto = _primernombre.ToUpper() + " " + _apelliodopaterno.ToUpper();
            registroCRM["axx_nombreembozadofinal"] = nombreCompleto;

            registroCRM["axx_fechaaperturatexto"] = fechaTexto;
            registroCRM["mcs_correoelectronicoid"] = datosClienteAdicionales.GetAttributeValue<EntityReference>("mcs_correoelectronicoprincipalid");
            registroCRM["mcs_iddireccionparticular"] = datosClienteAdicionales.GetAttributeValue<EntityReference>("mcs_direccionprincipalid");
            registroCRM["mcs_telefonoprincipalid"] = datosClienteAdicionales.GetAttributeValue<EntityReference>("mcs_telefonoprincipalid");
            registroCRM["axx_fechanacimiento"] = datosClienteAdicionales.GetAttributeValue<DateTime>("mcs_fechanacimiento");
            registroCRM["mcs_direccionfisicaenvio"] = datosClienteAdicionales.GetAttributeValue<EntityReference>("mcs_direccionprincipalid");
            registroCRM["mcs_correoelectronicoenvio"] = datosClienteAdicionales.GetAttributeValue<EntityReference>("mcs_correoelectronicoprincipalid");

            Entity auxCaptador = ctx.CachedEntities.GetCaptador(ejecutivo);

            if (auxCaptador != null)
                registroCRM["mcs_captador"] = auxCaptador.ToEntityReference();//Copiado y OK

            registroCRM["mcs_sucursaldeorigenid"] = ejecutivo.Sucursal.EntityReference;//Copiado y OK
            var telefonosCliente = GetTelefonosCliente(ctx, cliente.EntityReference.Id);

            foreach (var telefono in telefonosCliente.Entities)
            {
                var tipo = telefono.GetAttributeValue<OptionSetValue>("mcs_tipotelefono")?.Value;
                var telefonoId = telefono.GetAttributeValue<Guid>("mcs_telefonoid");

                if (tipo != null)
                {
                    if (tipo == 10)
                    {
                        ctx.Trace($"Telefono fijo: {telefonoId}");
                        registroCRM["axx_telefonofijoprincipal"] = new EntityReference("mcs_telefono", telefonoId);//CLONADO
                    }

                    if (tipo == 20)
                    {
                        ctx.Trace($"Telefono movil: {telefonoId}");
                        registroCRM["axx_telefonomovilprincipal"] = new EntityReference("mcs_telefono", telefonoId);//CLONADO
                    }
                }
            }
            registroCRM["axx_estadocivil"] = cliente.EstadoCivil;


            if (ejecutivo.Canal.Codigo == Canales.EEFF.ToString())
            {
                //crear venta con gestiones telefonicas asociada
                ctx.Trace($"Busca Gestiones Telefonicas del cliente");
                Guid guidGestionCliente = BuscarGestionesTelefonicasCliente(ctx, cliente.EntityReference.Id, productoGestiones.ProductId);
                if (!guidGestionCliente.Equals(Guid.Empty))
                {
                    ctx.Trace($"Guarda Gestion en campo axx_gestiontelefonicaasociada = " + guidGestionCliente.ToString());
                    registroCRM["axx_gestiontelefonicaasociada"] = new EntityReference("mcs_gestionejecutivo", guidGestionCliente);
                }
            }

            ctx.Trace($"Crear Venta");
            Guid axx_ventaId = ctx.Service.Create(registroCRM);

            ctx.Trace("Venta creada: " + axx_ventaId.ToString());
            return axx_ventaId;
        }
        public static Guid GenerarVenta(PluginContext ctx, Oferta oferta, Client cliente, User ejecutivo, out int autorizadorVenta, Entity datosClienteAdicionales, int origenTabletEEFF, IOrganizationService service)
        {
            ctx.Trace("GenerarVenta");
            //obtener el producto y si es aprobada o preaprobada
            int aprobadas = 0;
            int preaprobadas = 0;
            int ofertas = 0;

            autorizadorVenta = (int)mcs_autorizacin.Pendiente; //CRM_Autorizador_Pendiente
            var producto = ctx.CachedEntities.GetProductByCodigo(oferta.codigo) != null ? ctx.CachedEntities.GetProductByCodigo(oferta.codigo) : ctx.CachedEntities.GetProduct(oferta.productId);
            if (producto == null)
            {
                String msg = $"No puede vender el producto seleccionado {oferta.codigo}, no se encuentra creado en el catálogo";
                throw new Exception(msg);
            }
            else
            {
                oferta.productId = producto.ProductId;
                ctx.Trace("Tipo oferta: " + oferta.tipo_oferta);
                if (oferta.tipo_oferta == "PRE-APROBADA")
                    preaprobadas++;
                else if (oferta.tipo_oferta == "APROBADA")
                {
                    autorizadorVenta = (int)mcs_autorizacin.Aprobada;
                    aprobadas++;
                }

            }

            int origen = (int)mcs_Origen.Espontaneo; //CRM_Origen_Espontaneo
            //int estadoproducto = (int)mcs_EstadoProductodeOportunidad.RechazadaporExcepcion;
            if (ofertas > 0)
            {
                origen = (int)mcs_Origen.Ofertador;// settings.CRM_Origen_Ofertador;
            }
            if (ofertas > 0 && aprobadas > 0)
            {
                autorizadorVenta = (int)mcs_autorizacin.Aprobada;// settings.CRM_Autorizador_Aprobada;
            }
            Entity registroCRM = new Entity("axx_venta");

            //Completamos otros campos de la entidad
            registroCRM["createdby"] = new EntityReference("systemuser", ctx.Context.InitiatingUserId);//OK
            registroCRM["axx_dispositivoorigenventa"] = new OptionSetValue(origenTabletEEFF);
            registroCRM["axx_productocat"] = new EntityReference("axx_productocat", producto.ProductId);
            registroCRM["ownerid"] = registroCRM["createdby"];//OK
            registroCRM["axx_parentaccountid"] = cliente.EntityReference;//OK CREADO / No se pudo establecer en Personalizado su comportamiento solo jerarquico
            registroCRM["mcs_canalorigen"] = ejecutivo.Canal.EntityReference;//Copiado y OK
            registroCRM["mcs_canalusuarioactual"] = ejecutivo.Canal.EntityReference;//Copiado y OK
            registroCRM["mcs_regionorigenid"] = ejecutivo.Sucursal.Region;//Copiado y OK
            registroCRM["mcs_retailorigenid"] = ejecutivo.Sucursal.Grupo;//Copiado y OK
            registroCRM["mcs_autorizacion"] = new OptionSetValue(autorizadorVenta); //conjunto de opciones //Copiado y OK
            registroCRM["mcs_origen"] = new OptionSetValue(origen); //conjunto de opciones //Copiado y OK  //SE-029
            registroCRM["axx_numerodeidentificacion"] = cliente.NumeroIdentificacion; //Añadir NúmeroDeIdentificacion
            registroCRM["axx_idautorizacioncurseapertura"] = oferta.id_autorizacion; //Id Autorizacion
            registroCRM["axx_id_grupo"] = oferta.id_grupo;
            registroCRM["axx_estadocivil"] = cliente.EstadoCivil;
            registroCRM["axx_grupoidservicio"] = oferta.id_grupo_servicio;

            if (producto.ProductNumber == ((int)CodigosProductos.AumentoCupo).ToString())
            {
                ctx.Trace("Oferta es aumento de cupo");
                var montoSolicitado = ObtenerMontoSolicitado(producto, (decimal)oferta.cupo_total_cuenta.valor);
                registroCRM["mcs_montosolicitado"] = montoSolicitado;

                registroCRM["mcs_montoofertado"] = new Money((decimal)oferta.cupo_total_cuenta.valor);
                registroCRM["mcs_montootorgado"] = new Money((decimal)oferta.cupo_total_cuenta.valor);
            }

            else
            {
                registroCRM["mcs_montootorgado"] = new Money(0);
            }

            //Datos Titular
            var tz = TimeZoneInfo.FindSystemTimeZoneById("Pacific SA Standard Time");
            if (tz.IsInvalidTime(DateTime.Now))
            {
                tz = TimeZoneInfo.FindSystemTimeZoneById("E. South America Standard Time");
            }
            var now = TimeZoneInfo.ConvertTime(DateTime.Now, tz);
            var mes = DateTime.Now.ToString("MMMM", new CultureInfo("es-CL"));
            mes = mes.First().ToString().ToUpper() + mes.Substring(1);
            var fechaTexto = now.ToString($"dd 'de {mes} de' yyyy", new CultureInfo("es-CL"));

            if (fechaTexto.StartsWith("0"))
            {
                fechaTexto = fechaTexto.Remove(0, 1);
            }

            string _primernombre = Regex.Replace(cliente.PrimerNombre.Normalize(NormalizationForm.FormD), @"[^a-zA-z0-9 ]+", "").Replace('ñ', 'n').Replace('Ñ', 'N');
            string _apelliodopaterno = Regex.Replace(cliente.ApellidoPaterno.Normalize(NormalizationForm.FormD), @"[^a-zA-z0-9 ]+", "").Replace('ñ', 'n').Replace('Ñ', 'N');
            string _apelliodomaterno = Regex.Replace(cliente.ApellidoMaterno.Normalize(NormalizationForm.FormD), @"[^a-zA-z0-9 ]+", "").Replace('ñ', 'n').Replace('Ñ', 'N');

            registroCRM["axx_nombreembozado"] = _primernombre.ToUpper();
            registroCRM["axx_apellidosembozado"] = _apelliodopaterno.ToUpper();

            //Datos Upgrade
            string nombreCompleto = _primernombre.ToUpper() + " " + _apelliodopaterno.ToUpper();
            registroCRM["axx_nombreembozadofinal"] = nombreCompleto;
            registroCRM["axx_numerotarjeta"] = oferta.id_tarjeta_upgrade; //numero tarjeta del titular
            registroCRM["axx_numerologoupgrade"] = oferta.id_logo; //id de logo del titular
            registroCRM["axx_productocatupgrade"] = (oferta.producto_upgrade_id != null) ? new EntityReference("axx_productocat", new Guid(oferta.producto_upgrade_id.ToString())) : null;
            registroCRM["axx_productocatactual"] = (oferta.producto_actual_id != null) ? new EntityReference("axx_productocat", new Guid(oferta.producto_actual_id.ToString())) : null;
            ctx.Trace($"oferta.seguro_actual:{(oferta.seguro_actual)}");
            registroCRM["axx_seguroactual"] = oferta.seguro_actual != null ? oferta.seguro_actual : "";
            registroCRM["axx_idcuenta"] = oferta.id_cuenta;
            ctx.Trace($"oferta.id_cuenta:{(oferta.bloqueo)}");
            registroCRM["axx_bloqueo"] = oferta.bloqueo;

            ctx.Trace($"fecha_activacion:{(oferta.FechaActivacion)}");
            if (oferta.FechaActivacion.Year > 1753)
                registroCRM["axx_fechadeactivacion"] = oferta.FechaActivacion;

            ctx.Trace($"fecha_emision_tarjeta: {(oferta.FechaEmisionTarjeta)}");
            if (oferta.FechaEmisionTarjeta.Year > 1753)
                registroCRM["axx_fechaemisiontarjeta"] = oferta.FechaEmisionTarjeta;

            ctx.Trace($"fecha_bloqueo: {(oferta.FechaBloqueo)}");
            if (oferta.FechaBloqueo.Year > 1753)
                registroCRM["axx_fechabloqueo"] = oferta.FechaBloqueo;

            if (oferta.id_tarjeta_antigua != null)
                registroCRM["axx_tarjetaid"] = oferta.id_tarjeta_antigua;


            if (!String.IsNullOrEmpty(oferta.GetPropiedad("id_tarjeta_contratante")))
                registroCRM["axx_tarjetaid"] = oferta.GetPropiedad("id_tarjeta_contratante");

            registroCRM["axx_fechaaperturatexto"] = fechaTexto;
            registroCRM["mcs_correoelectronicoid"] = datosClienteAdicionales.GetAttributeValue<EntityReference>("mcs_correoelectronicoprincipalid");
            registroCRM["mcs_iddireccionparticular"] = datosClienteAdicionales.GetAttributeValue<EntityReference>("mcs_direccionprincipalid");
            registroCRM["mcs_telefonoprincipalid"] = datosClienteAdicionales.GetAttributeValue<EntityReference>("mcs_telefonoprincipalid");
            registroCRM["axx_fechanacimiento"] = datosClienteAdicionales.GetAttributeValue<DateTime>("mcs_fechanacimiento");
            registroCRM["mcs_direccionfisicaenvio"] = datosClienteAdicionales.GetAttributeValue<EntityReference>("mcs_direccionprincipalid");
            registroCRM["mcs_correoelectronicoenvio"] = datosClienteAdicionales.GetAttributeValue<EntityReference>("mcs_correoelectronicoprincipalid");



            Entity auxCaptador = ctx.CachedEntities.GetCaptador(ejecutivo);

            if (auxCaptador != null)
                registroCRM["mcs_captador"] = auxCaptador.ToEntityReference();//Copiado y OK

            registroCRM["mcs_sucursaldeorigenid"] = ejecutivo.Sucursal.EntityReference;//Copiado y OK
            var telefonosCliente = GetTelefonosCliente(ctx, cliente.EntityReference.Id);

            foreach (var telefono in telefonosCliente.Entities)
            {
                var tipo = telefono.GetAttributeValue<OptionSetValue>("mcs_tipotelefono")?.Value;
                var telefonoId = telefono.GetAttributeValue<Guid>("mcs_telefonoid");

                if (tipo != null)
                {
                    if (tipo == 10)
                    {
                        ctx.Trace($"Telefono fijo: {telefonoId}");
                        registroCRM["axx_telefonofijoprincipal"] = new EntityReference("mcs_telefono", telefonoId);//CLONADO
                    }

                    if (tipo == 20)
                    {
                        ctx.Trace($"Telefono movil: {telefonoId}");
                        registroCRM["axx_telefonomovilprincipal"] = new EntityReference("mcs_telefono", telefonoId);//CLONADO
                    }
                }
            }

            //Obtención del ciclo de facturacion
            Entity cicloFacturacion = new Entity("mcs_ciclosfacturacion");
            if (oferta.fecha_vencimiento_facturacion != null)
            {
                ctx.Trace($"fecha_vencimiento_facturacion: {oferta.fecha_vencimiento_facturacion}");
                if (oferta.FechaVencimientoFacturacion.Year > 1753)
                {
                    ctx.Trace($"obtener Ciclo de Facturacion: producto - {oferta.producto_actual_id}");
                    cicloFacturacion = GetCicloFacturacion(ctx, new Guid(oferta.producto_actual_id), oferta.FechaVencimientoFacturacion);
                    ctx.Trace($"ciclo de facturacion Encontrado: {cicloFacturacion.Id}");
                }
            }
            if (cicloFacturacion.Id != Guid.Empty)
            {
                ctx.Trace($"Asignacion Fecha de Facturacion");
                registroCRM["mcs_ciclodefacturacion"] = new EntityReference("mcs_ciclosfacturacion", cicloFacturacion.Id);
            }

            if (ejecutivo.Canal.Codigo == Canales.EEFF.ToString())
            {
                //crear venta con gestiones telefonicas asociada
                ctx.Trace($"Busca Gestiones Telefonicas del cliente");
                Guid guidGestionCliente = BuscarGestionesTelefonicasCliente(ctx, cliente.EntityReference.Id, producto.ProductId);
                if (!guidGestionCliente.Equals(Guid.Empty))
                {
                    ctx.Trace($"Guarda Gestion en campo axx_gestiontelefonicaasociada");
                    registroCRM["axx_gestiontelefonicaasociada"] = new EntityReference("mcs_gestionejecutivo", guidGestionCliente);
                }
            }

            ctx.Trace($"Crear Venta");
            Guid axx_ventaId = ctx.Service.Create(registroCRM);

            //Adicionales asociados al titular de upgrade
            ctx.Trace($"Adicionales Upgrade");
            if (oferta.adicionales_upgrade != null)
            {
                if (oferta.adicionales_upgrade.Count > 0)
                {
                    ctx.Trace($"Adicional : {oferta.adicionales_upgrade.Count}");
                    foreach (AdicionalUpgrade adicional in oferta.adicionales_upgrade)
                    {
                        try
                        {
                            Entity AdicionalUpgrade = GetClienteAdicionalApolo(ctx, adicional.id_cliente_adicional);
                            ctx.Trace($"Adicional id : {adicional.id_cliente_adicional}");
                            Entity adicionalVentaCRM = new Entity("axx_adicionalventa");

                            ctx.Trace($"setea nombres Adicional");
                            string primerNombreAdicional = AdicionalUpgrade.Contains("mcs_primernombre") ? AdicionalUpgrade["mcs_primernombre"].ToString().ToUpper() : "";
                            string appellidoPaternoAdicional = AdicionalUpgrade.Contains("mcs_apellidopaterno") ? AdicionalUpgrade["mcs_apellidopaterno"].ToString().ToUpper() : "";
                            string apellidoMaternoAdicional = AdicionalUpgrade.Contains("mcs_apellidomaterno") ? AdicionalUpgrade["mcs_apellidomaterno"].ToString().ToUpper() : "";

                            adicionalVentaCRM["axx_venta"] = new EntityReference("axx_venta", axx_ventaId);
                            adicionalVentaCRM["axx_nombreembozado"] = primerNombreAdicional;
                            adicionalVentaCRM["axx_apellidoembozado"] = appellidoPaternoAdicional;
                            adicionalVentaCRM["axx_nombrecompletoembozado"] = primerNombreAdicional + " " + appellidoPaternoAdicional + " " + apellidoMaternoAdicional;
                            adicionalVentaCRM["axx_origenadicional"] = false;
                            adicionalVentaCRM["axx_nrocuentatitular"] = adicional.numero_cuenta == null ? "" : adicional.numero_cuenta;
                            adicionalVentaCRM["axx_nrotarjetaadicional"] = adicional.numero_tarjeta == null ? "" : adicional.numero_tarjeta;
                            adicionalVentaCRM["axx_productocatupgrade"] = (adicional.id_producto_upgrade != null) ? new EntityReference("axx_productocat", new Guid(adicional.id_producto_upgrade.ToString())) : null;
                            adicionalVentaCRM["axx_productocatactual"] = (adicional.id_producto_actual != null) ? new EntityReference("axx_productocat", new Guid(adicional.id_producto_actual.ToString())) : null;
                            adicionalVentaCRM["axx_adicionalvisible"] = adicional.adicional_visible;

                            if (adicional.adicional_visible == false)
                                adicionalVentaCRM["axx_upgradeadicional"] = false;

                            ctx.Trace($"oferta.id_tarjeta_adicional:{(adicional.id_tarjeta_adicional)}");
                            adicionalVentaCRM["axx_idtarjeta"] = adicional.id_tarjeta_adicional;

                            ctx.Trace($"oferta.id_cuenta:{(adicional.id_cuenta_titular)}");
                            adicionalVentaCRM["axx_idcuenta"] = adicional.id_cliente_adicional;

                            ctx.Trace($"oferta.bloqueo:{(adicional.bloqueo)}");
                            adicionalVentaCRM["axx_bloqueo"] = adicional.bloqueo;

                            ctx.Trace($"Adicional: fecha_activacion:{(oferta.FechaActivacion)}");
                            if (oferta.FechaActivacion.Year > 1753)
                                adicionalVentaCRM["axx_fechadeactivacion"] = oferta.FechaActivacion;

                            ctx.Trace($"fecha_emision_tarjeta: {(adicional.FechaEmisionTarjeta)}");
                            if (oferta.FechaEmisionTarjeta.Year > 1753)
                                adicionalVentaCRM["axx_fechaemisiontarjeta"] = adicional.FechaEmisionTarjeta;

                            ctx.Trace($"fecha_bloqueo: {(oferta.FechaBloqueo)}");
                            if (oferta.FechaBloqueo.Year > 1753)
                                adicionalVentaCRM["axx_fechabloqueo"] = adicional.FechaBloqueo;
                            adicionalVentaCRM["axx_nrocuentatitular"] = adicional.id_cuenta_titular == null ? "" : adicional.id_cuenta_titular; ;
                            adicionalVentaCRM["axx_nrotarjetaadicional"] = adicional.id_tarjeta_adicional == null ? "" : adicional.id_tarjeta_adicional;

                            ctx.Trace($"Genera Adicional Venta");
                            adicionalVentaCRM["axx_persona"] = new EntityReference("account", AdicionalUpgrade.Id);
                            adicionalVentaCRM["axx_nombredeltitular"] = cliente.EntityReference;
                            Guid axx_adicionalVenta = ctx.Service.Create(adicionalVentaCRM);
                            ctx.Trace($"adicional Venta GUID: " + axx_adicionalVenta);
                        }
                        catch (Exception ex)
                        {
                            ctx.Trace($"Error : {ex.Message}");
                        }
                    }
                }
            }

            ctx.Trace("Venta creada: " + axx_ventaId.ToString());
            return axx_ventaId;
        }
        //Crear producto de Venta EN Venta
        private static void EditarDatosVentaProd(PluginContext ctx, List<Oferta> offers, Client cliente, User ejecutivo, Guid aax_ventaId)
        {
            ctx.Trace("Asociar Data de ProductoOprortunidad a Venta");
            Int32 estadoproducto = 0;

            if (offers.Count > 0)
            {
                //offers[0];
                if (offers[0].tipo_oferta == "APROBADA" || offers[0].GetType() == typeof(OfertaComplementaria))
                {
                    ctx.Trace("tipo_oferta Aprobado");
                    estadoproducto = (int)mcs_EstadoProductodeOportunidad.Aprobada;//CRM_ProductoOportunidad_Aprobado;
                }
                else
                {
                    ctx.Trace("tipo_oferta PreAprobado");
                    estadoproducto = (int)mcs_EstadoProductodeOportunidad.Pendiente;// settings.CRM_ProductoOportunidad_Pendiente;
                }

                //A continuacion se debe tomar la guid de la Venta y asociar los datos de PorductoOPT a Venta
                Guid ventaId = ModificarVentaConProdOpt(ctx, aax_ventaId, offers[0], ejecutivo, cliente);

                if (estadoproducto != (int)mcs_EstadoProductodeOportunidad.Pendiente)
                {
                    ctx.Trace("Se actualiza mcs_estadoproductodeoportunidad");
                    Entity ventaContexto = new Entity("axx_venta", ventaId);
                    ventaContexto["mcs_estadoproductodeoportunidad"] = new OptionSetValue(estadoproducto);
                    //Actualizamos en CRM
                    ctx.Service.Update(ventaContexto);
                }
            }
        }
        public static Guid ModificarVentaConProdOpt(PluginContext ctx, Guid aax_ventaId, Oferta ofertarespuesta, User ejecutivo, Client persona)
        {
            ctx.Trace($"ModificarVentaConProdOpt: Codigo producto {ofertarespuesta.codigo}, Producto: {ofertarespuesta.producto}");
            ctx.Trace($"ModificarVentaConProdOpt: Id Venta: {aax_ventaId}");
            int tipooferta = 0;
            int estadoproducto = 0;
            //var listapredeterminada = ctx.CachedEntities.GetUnidadPredeterminada();
            var producto = ctx.CachedEntities.GetProduct(ofertarespuesta.productId);

            if (ofertarespuesta.tipo_oferta == "APROBADA" || ofertarespuesta.GetType() == typeof(OfertaComplementaria))
            {
                tipooferta = (int)mcs_TipodeOferta.Aprobada;// Settings.Default.CRM_TipoOfertaAprobada;
                estadoproducto = (int)mcs_EstadoProductodeOportunidad.Aprobada;// Settings.Default.CRM_ProductoOportunidad_Aprobado;
            }

            else
            {
                tipooferta = (int)mcs_TipodeOferta.PreAprobada;// Settings.Default.CRM_TipoOfertaPreaprobada;
                estadoproducto = (int)mcs_EstadoProductodeOportunidad.Pendiente;// Settings.Default.CRM_ProductoOportunidad_Pendiente;
            }

            ctx.Trace($"ModificarVentaConProdOpt: step 1");
            Entity registroCRM = new Entity("axx_venta", aax_ventaId);

            //Completamos otros campos de la entidad
            registroCRM["mcs_montominimo"] = producto.MontoMinimo;//OK COPIADO
            registroCRM["mcs_montomaximo"] = producto.MontoMaximo;//OK COPIADO
            //registroCRM["mcs_primaryproductid"] = producto.ParentProductId;//OK COPIADO
            registroCRM["mcs_rutadejerarquia"] = producto.HierarchyPath;//OK COPIADO
            registroCRM["mcs_persona"] = persona.EntityReference;//OK COPIADO
            registroCRM["axx_productocat"] = new EntityReference("axx_productocat", ofertarespuesta.productId);
            //registroCRM["mcs_primaryproductid"] = producto.ParentProductId;//OK COPIADO
            //BUG 7148 
            registroCRM["mcs_tipodeofertas"] = new OptionSetValue(tipooferta);//OK COPIADO
            //BUG 7173
            registroCRM["mcs_estadoproductodeoportunidad"] = new OptionSetValue(estadoproducto);//OK COPIADO

            ctx.Trace($"ModificarVentaConProdOpt: step 2");
            if (ofertarespuesta.GetType() == typeof(OfertaComplementaria) && producto.ProductNumber != ((int)CodigosProductos.AumentoCupo).ToString())
            {
                ctx.Trace($"ModificarVentaConProdOpt: step 3");
                var ofertarespuestaComplementaria = ofertarespuesta as OfertaComplementaria;
                registroCRM["mcs_montosolicitado"] = new Money(0);//OK COPIADO

                registroCRM["mcs_montoofertado"] = new Money(0);//OK COPIADO
                registroCRM["mcs_montootorgado"] = new Money(0);//OK COPIADO

                Product desgravamenUF = ctx.CachedEntities.GetProductByProductNumber(((int)CodigosProductos.DesgravamenUF).ToString());
                if (ofertarespuestaComplementaria.codigo == desgravamenUF.Codigo)
                    registroCRM["mcs_preciouf"] = Utils.FormatearStringNumericoAPorcetaje(ofertarespuestaComplementaria.GetPropiedad("factor_deuda"));//OK COPIADO
                else
                    registroCRM["mcs_preciouf"] = ofertarespuestaComplementaria.monto.valor?.ToString();
                registroCRM["mcs_cuentatarjeta"] = ofertarespuestaComplementaria.GetPropiedad("nro_tarjeta_contratante");//OK COPIADO
                registroCRM["mcs_numerocuenta"] = ofertarespuestaComplementaria.GetPropiedad("nro_cuenta");//OK COPIADO

                if (ofertarespuesta.cupo_total_cuenta != null && ofertarespuesta.cupo_total_cuenta.valor != null)
                {
                    ctx.Trace($"Si tiene cupo total");
                    registroCRM["mcs_cupototal"] = new Money((decimal)ofertarespuesta.cupo_total_cuenta.valor);//OK COPIADO
                }

                Product FullAmbulatorio = ctx.CachedEntities.GetProductByProductNumber(((int)CodigosProductos.FullAmbulatorio).ToString());
                if (ofertarespuestaComplementaria.codigo == FullAmbulatorio.Codigo) //full ambulatorio guarda numero de tarjeta ofuscado para documento
                {
                    ctx.Trace($"oferta complementaria es full ambulatorio");
                    Propiedade numero_tarjeta_data = ofertarespuestaComplementaria.propiedades.FirstOrDefault(x => x.nombre == "nro_tarjeta_asegurado");
                    ofertarespuestaComplementaria.numero_tarjeta = numero_tarjeta_data != null ? numero_tarjeta_data.valor : "s/n";
                    registroCRM["axx_numerotarjeta"] = ofertarespuestaComplementaria.numero_tarjeta; //numero tarjeta del asegurado
                }


            }
            else if (producto.ProductNumber == ((int)CodigosProductos.AumentoCupo).ToString())
            {
                ctx.Trace($"ModificarVentaConProdOpt: step 3.5");
                ctx.Trace($"ofertarespuesta: {JsonSerializer.Serialize(ofertarespuesta)}");
                OrganizationRequest request = new OrganizationRequest("axx_ActionApiIntegrationConsultarActivosAumetoCupo32c1d71d987eea11a812000d3a1b1f2c");
                request.Parameters.Add("Target", persona.EntityReference);
                OrganizationResponse response = ctx.Service.Execute(request);

                ctx.Trace($"responseActivos: {response.Results["Response"]}");
                Models.ActivosResponse activos = JsonSerializer.Deserialize<Models.ActivosResponse>(response.Results["Response"].ToString());
                ctx.Trace($"activos.cantidad_elementos: {activos.cantidad_elementos}");
                int contItemsActivos = 0;
                foreach (var itemActivo in activos.contenido)
                {
                    contItemsActivos++;
                    ctx.Trace($"ofertarespuesta.id_cuenta: {ofertarespuesta.id_cuenta}");
                    if (itemActivo.id.ToString() == ofertarespuesta.id_cuenta)
                    {
                        ctx.Trace($"itemActivo{contItemsActivos}.id_cuenta: {itemActivo.id}");
                        registroCRM["mcs_numerocuenta"] = itemActivo.numero_cuenta;
                        ctx.Trace($"itemActivo{contItemsActivos}.numero_cuenta: {itemActivo.numero_cuenta}");
                        registroCRM["mcs_cupototal"] = new Money(itemActivo.cupo_actual);
                        ctx.Trace($"itemActivo{contItemsActivos}.cupo_actual: {itemActivo.cupo_actual}");
                    }
                }
            }
            else if (producto.ProductNumber == ((int)CodigosProductos.RDRRepactacion).ToString() || producto.ProductNumber == ((int)CodigosProductos.RDRRenegociacion).ToString())
            {
                ctx.Trace($"ModificarVentaConProdOpt: step 4 RDR REPA RENE");
                var montoSolicitadoL1 = ObtenerMontoSolicitado(producto, ofertarespuesta.ofertaRdr.deuda_linea_uno.valor);
                var montoSolicitadoL2 = ObtenerMontoSolicitado(producto, ofertarespuesta.ofertaRdr.deuda_linea_dos.valor);
                var montoSolicitadoL1yL2 = new Money((decimal)ofertarespuesta.ofertaRdr.monto_total_deudas.valor);
                var montoDeudaofertado = new Money((decimal)ofertarespuesta.ofertaRdr.monto_total_deudas.valor);
                ctx.Trace("1");
                if (ofertarespuesta.ofertaRdr.deuda_linea_uno.valor == 0)
                {
                    ctx.Trace("2");
                    if (ofertarespuesta.ofertaRdr.deuda_linea_dos.valor == 0)
                    {
                        registroCRM["mcs_montosolicitado"] = new Money(0);
                        ctx.Trace("3");
                    }
                    else
                    {
                        ctx.Trace("4");
                        registroCRM["axx_rdrcostototall2"] = montoSolicitadoL2;
                        registroCRM["mcs_montosolicitado"] = montoSolicitadoL2;
                        registroCRM["mcs_montoofertado"] = montoDeudaofertado;
                    }
                }
                else
                {
                    ctx.Trace("5");
                    if (ofertarespuesta.ofertaRdr.deuda_linea_dos.valor == 0)
                    {
                        ctx.Trace("6");
                        registroCRM["mcs_montosolicitado"] = montoSolicitadoL1;
                        registroCRM["axx_rdrcostototall1"] = montoSolicitadoL1;
                        registroCRM["mcs_montoofertado"] = montoDeudaofertado;
                    }
                    else
                    {
                        ctx.Trace("7");
                        ctx.Trace(montoSolicitadoL1yL2.Value.ToString());
                        registroCRM["mcs_montosolicitado"] = montoSolicitadoL1yL2;
                        registroCRM["axx_rdrcostototall1"] = montoSolicitadoL1;
                        registroCRM["axx_rdrcostototall2"] = montoSolicitadoL2;
                        registroCRM["mcs_montoofertado"] = montoDeudaofertado;
                    }
                }
                if (tipooferta == (int)mcs_TipodeOferta.PreAprobada)
                {
                    registroCRM["mcs_montootorgado"] = new Money(0);//OK COPIADO
                }
                else
                {
                    registroCRM["mcs_montootorgado"] = montoDeudaofertado;
                }
                registroCRM["mcs_numerocuenta"] = ofertarespuesta.ofertaRdr.numero_cuenta_ofuscado;


            }
            else
            {
                ctx.Trace($"ModificarVentaConProdOpt: step 4");
                //El siguiente metodo no requiere modificaciones a la logica
                var montoSolicitado = ObtenerMontoSolicitado(producto, ofertarespuesta.monto.valor);
                //registroCRM["mcs_montosolicitado"] = montoSolicitado;//OK COPIADO

                //BUG 7150
                if (ofertarespuesta.monto.valor == 1)
                {
                    registroCRM["mcs_montosolicitado"] = new Money(0);//OK COPIADO
                                                                      // registroCRM["mcs_montoofertado"] = new Money(0);//OK COPIADO

                }
                else
                {
                    registroCRM["mcs_montosolicitado"] = montoSolicitado;//OK COPIADO
                    registroCRM["mcs_montoofertado"] = new Money((decimal)ofertarespuesta.monto.valor);//OK COPIADO

                }

                //ISSUE 7250
                if (tipooferta == (int)mcs_TipodeOferta.PreAprobada)
                    registroCRM["mcs_montootorgado"] = new Money(0);//OK COPIADO
                else
                    registroCRM["mcs_montootorgado"] = montoSolicitado;

                registroCRM["mcs_numerocuenta"] = ofertarespuesta.numero_cuenta;//OK COPIADO

                if (ofertarespuesta.cupo_total_cuenta != null && ofertarespuesta.cupo_total_cuenta.valor != null)
                    registroCRM["mcs_cupototal"] = new Money((decimal)ofertarespuesta.cupo_total_cuenta.valor);//OK COPIADO
            }
            ctx.Trace($"ModificarVentaConProdOpt: step 5");
            registroCRM["mcs_descripcion"] = ofertarespuesta.descripcion;//OK COPIADO
            //registroCRM["axx_uomid"] = listapredeterminada;//Reemplazo uomid por axx_uomid
            registroCRM["mcs_ofertaid"] = ofertarespuesta.id_oferta;//OK COPIADO

            registroCRM["mcs_idactivo"] = ofertarespuesta.id_activo;//OK COPIADO
            //TASK 10295
            registroCRM["axx_productoname"] = ofertarespuesta.producto;//Reemplazo productname por axx_productoname
            registroCRM["axx_opportunityproductname"] = ofertarespuesta.producto;//Reemplazo opportunityproductname por axx_opportunityproductname
            registroCRM["mcs_nombredelproducto"] = ofertarespuesta.producto != null ? ofertarespuesta.producto : producto.Name;//OK COPIADO
            //S.E.D. 24-07-2019
            if (ofertarespuesta.FechaInicio.Year > 1753)
                registroCRM["axx_fechainiciocobertura"] = ofertarespuesta.FechaInicio;//OK COPIADO
            ctx.Trace($"ModificarVentaConProdOpt: step 6");
            if (!String.IsNullOrEmpty(ofertarespuesta.id_producto))
            {
                ctx.Trace($"ModificarVentaConProdOpt: step 7");
                ctx.Trace($"ModificarVentaConProdOpt: step 7.1 ->{ofertarespuesta.id_producto}");
                var productoT = ctx.CachedEntities.GetProductByCodigo(ofertarespuesta.id_producto) != null ? ctx.CachedEntities.GetProductByCodigo(ofertarespuesta.codigo) : ctx.CachedEntities.GetProduct(ofertarespuesta.productId);
                registroCRM["axx_productocat"] = productoT.EntityReference;//OK COPIADO
                // Obtengo los montos del producto T
                registroCRM["mcs_montominimo"] = productoT.MontoMinimo;//OK COPIADO
                registroCRM["mcs_montomaximo"] = productoT.MontoMaximo;//OK COPIADO
                ctx.Trace($"ModificarVentaConProdOpt: step 8");
            }
            if (persona != null)
            {

                ctx.Trace($"ModificarVentaConProdOpt: step 9");

                if (persona.EstadoCivil != null)
                {
                    //El estado civil en ProdOpp es un global, pero en la persona no, por eso se instancia.
                    registroCRM["axx_estadocivil"] = persona.EstadoCivil;//OK COPIADO
                }
                registroCRM["axx_primerapellidoconyugue"] = persona.ApellidoPaternoConyugue;//OK COPIADO
                registroCRM["axx_primernombreconyuge"] = persona.PrimeroNombreConyugue;//OK COPIADO
                ctx.Trace($"ModificarVentaConProdOpt: step 10");
            }
            ctx.Trace($"ModificarVentaConProdOpt: step 11");
            //Se modifica la Venta añadiendo los valores que debiesen corresponder al ProductoDeOportunidad
            ctx.Service.Update(registroCRM);
            ctx.Trace("Producto opp Añadido a Venta: " + registroCRM.Id);
            ctx.Trace($"ModificarVentaConProdOpt: step 12");
            return registroCRM.Id;
        }

        public static void PasarANegociacionVenta(PluginContext ctx, Guid idVenta, string canal)
        {
            ctx.Trace("PasarANegociacion la Venta");
            ctx.Trace($"PasarANegociacionVenta -> {idVenta}");
            var proceso = Utils.RecuperarProcesoGenerarVenta(idVenta, ctx);
            if (proceso != null)
            {
                ctx.Trace($"PasarANegociacionVenta -> !=null");
                var fase = ctx.CachedEntities.GetProcessStage(proceso.GetAttributeValue<EntityReference>("processid").Id, canal == "120" ? "Negociación Canal Espacio Financiero" : "Negociación");
                if (fase != null)
                {
                    ctx.Trace($"PasarANegociacionVenta fase -> !=null");
                    var traversedPath = (proceso["traversedpath"] ?? "").ToString();
                    traversedPath += ((traversedPath.Length > 0) ? "," : "") + fase.Id.ToString().Replace("{", "").Replace("}", "");

                    proceso["activestageid"] = new EntityReference(fase.LogicalName, fase.Id);
                    proceso["traversedpath"] = traversedPath;

                    ctx.Service.Update(proceso);
                }
                else
                {
                    ctx.Trace($"PasarANegociacionVenta -> fase == null");

                }
            }
            else
            {

                ctx.Trace($"PasarANegociacionVenta -> proceso == null");
            }
        }

        //FINAL DE LOGICA VENTA
        #endregion
        private static void CrearProductosDeOportunidad(PluginContext ctx, List<Oferta> offers, Client cliente, User ejecutivo, Guid opportunityId, Entity datosClienteAdicionales)
        {
            ctx.Trace("CrearProductosDeOportunidad");
            Int32 estadoproducto = 0;
            foreach (var ofertarespuesta in offers)
            {
                if (ofertarespuesta.tipo_oferta == "APROBADA" || ofertarespuesta.GetType() == typeof(OfertaComplementaria))
                {
                    ctx.Trace("tipo_oferta Aprobado");
                    estadoproducto = (int)mcs_EstadoProductodeOportunidad.Aprobada;//CRM_ProductoOportunidad_Aprobado;
                }

                else
                {
                    ctx.Trace("tipo_oferta PreAprobado");
                    estadoproducto = (int)mcs_EstadoProductodeOportunidad.Pendiente;// settings.CRM_ProductoOportunidad_Pendiente;
                }


                Guid opportunityProductId = CrearProductoOportunidad(ctx, opportunityId, ofertarespuesta, ejecutivo, cliente, datosClienteAdicionales);

                if (estadoproducto != (int)mcs_EstadoProductodeOportunidad.Pendiente)
                {
                    ctx.Trace("Se actualiza mcs_estadoproductodeoportunidad");
                    Entity productoOportunidad = new Entity("opportunityproduct", opportunityProductId);
                    productoOportunidad["mcs_estadoproductodeoportunidad"] = new OptionSetValue(estadoproducto);
                    //Actualizamos en CRM
                    ctx.Service.Update(productoOportunidad);
                }
            }
        }



        public static Guid CrearProductoOportunidad(PluginContext ctx, Guid opportunityId, Oferta ofertarespuesta, User ejecutivo, Client persona, Entity datosClienteAdicionales)
        {
            ctx.Trace($"CrearProductoOportunidad: Codigo producto {ofertarespuesta.codigo}, Producto: {ofertarespuesta.producto}");
            int tipooferta = 0;
            int estadoproducto = 0;
            var listapredeterminada = ctx.CachedEntities.GetUnidadPredeterminada();
            var producto = ctx.CachedEntities.GetProduct(ofertarespuesta.productId);

            if (ofertarespuesta.tipo_oferta == "APROBADA" || ofertarespuesta.GetType() == typeof(OfertaComplementaria))
            {
                tipooferta = (int)mcs_TipodeOferta.Aprobada;// Settings.Default.CRM_TipoOfertaAprobada;
                estadoproducto = (int)mcs_EstadoProductodeOportunidad.Aprobada;// Settings.Default.CRM_ProductoOportunidad_Aprobado;
            }

            else
            {
                tipooferta = (int)mcs_TipodeOferta.PreAprobada;// Settings.Default.CRM_TipoOfertaPreaprobada;
                estadoproducto = (int)mcs_EstadoProductodeOportunidad.Pendiente;// Settings.Default.CRM_ProductoOportunidad_Pendiente;
            }

            ctx.Trace($"CrearProductoOportunidad: -> step 1");
            Entity registroCRM = new Entity("opportunityproduct");

            //Completamos otros campos de la entidad
            registroCRM["mcs_montominimo"] = producto.MontoMinimo;
            registroCRM["mcs_montomaximo"] = producto.MontoMaximo;
            registroCRM["mcs_primaryproductid"] = producto.ParentProductId;
            registroCRM["mcs_rutadejerarquia"] = producto.HierarchyPath;
            registroCRM["mcs_persona"] = persona.EntityReference;
            registroCRM["ownerid"] = ejecutivo.EntityReference;
            registroCRM["opportunityid"] = new EntityReference("opportunity", opportunityId);
            registroCRM["productid"] = new EntityReference("axx_productocat", ofertarespuesta.productId);
            registroCRM["mcs_primaryproductid"] = producto.ParentProductId;
            ctx.Trace($"CrearProductoOportunidad: -> step 2");
            //BUG 7148 
            registroCRM["mcs_tipodeofertas"] = new OptionSetValue(tipooferta);
            //BUG 7173
            registroCRM["mcs_estadoproductodeoportunidad"] = new OptionSetValue(estadoproducto);
            registroCRM["mcs_correoelectronicoenvio"] = datosClienteAdicionales.GetAttributeValue<EntityReference>("mcs_correoelectronicoprincipalid");
            registroCRM["mcs_direccionprincipalpersona"] = datosClienteAdicionales.GetAttributeValue<EntityReference>("mcs_direccionprincipalid");
            registroCRM["axx_profesiondeltercero"] = datosClienteAdicionales.GetAttributeValue<EntityReference>("mcs_profesionid");

            //TASK 2875
            if (ofertarespuesta.cuota_maxima_excepcion != null)
            {
                registroCRM["axx_cuotamaximaexcepcion"] = ofertarespuesta.cuota_maxima_excepcion;
            }
            if (ofertarespuesta.mes_diferimiento_excepcion != null)
            {
                registroCRM["axx_mesdiferimientoexcepcion"] = ofertarespuesta.mes_diferimiento_excepcion;
            }
            if (ofertarespuesta.monto_excepcion?.valor != null)
            {
                registroCRM["axx_montoexcepcion"] = new Money((decimal)ofertarespuesta.monto_excepcion.valor);
            }
            registroCRM["axx_simulaexcepcion"] = ofertarespuesta.excepcion;


            //TASK 3076
            ctx.Trace($"CrearProductoOportunidad: -> step 3");
            registroCRM["axx_canal"] = new EntityReference("mcs_canal", ejecutivo.Canal.EntityReference.Id);

            if (ofertarespuesta.GetType() == typeof(OfertaComplementaria))
            {
                ctx.Trace($"CrearProductoOportunidad: -> step 4");
                var ofertarespuestaComplementaria = ofertarespuesta as OfertaComplementaria;
                registroCRM["mcs_montosolicitado"] = new Money(0);

                registroCRM["mcs_montoofertado"] = new Money(0);
                registroCRM["mcs_montootorgado"] = new Money(0);

                Product desgravamenUF = ctx.CachedEntities.GetProductByProductNumber(((int)CodigosProductos.DesgravamenUF).ToString());
                if (ofertarespuestaComplementaria.codigo == desgravamenUF.Codigo)
                    registroCRM["mcs_preciouf"] = Utils.FormatearStringNumericoAPorcetaje(ofertarespuestaComplementaria.GetPropiedad("factor_deuda"));
                else
                    registroCRM["mcs_preciouf"] = ofertarespuestaComplementaria.monto.valor?.ToString();
                registroCRM["mcs_cuentatarjeta"] = ofertarespuestaComplementaria.GetPropiedad("nro_tarjeta_contratante");
                registroCRM["mcs_numerocuenta"] = ofertarespuestaComplementaria.GetPropiedad("nro_cuenta");

                if (!String.IsNullOrEmpty(ofertarespuestaComplementaria.GetPropiedad("nro_tarjeta_asegurado")))
                    registroCRM["mcs_numerotarjetaadicional"] = ofertarespuestaComplementaria.GetPropiedad("nro_tarjeta_asegurado");

                if (!String.IsNullOrEmpty(ofertarespuestaComplementaria.GetPropiedad("rut_contratante")))
                    registroCRM["mcs_ruttitular"] = ofertarespuestaComplementaria.GetPropiedad("rut_contratante");

                if (!String.IsNullOrEmpty(ofertarespuestaComplementaria.GetPropiedad("dv_contratante")))
                    registroCRM["mcs_digitotitular"] = ofertarespuestaComplementaria.GetPropiedad("dv_contratante");

                if (!String.IsNullOrEmpty(ofertarespuestaComplementaria.GetPropiedad("rut_asegurado")))
                    registroCRM["mcs_rutadicional"] = ofertarespuestaComplementaria.GetPropiedad("rut_asegurado");

                if (!String.IsNullOrEmpty(ofertarespuestaComplementaria.GetPropiedad("dv_asegurado")))
                    registroCRM["mcs_digitoadicional"] = ofertarespuestaComplementaria.GetPropiedad("dv_asegurado");

                if (!String.IsNullOrEmpty(ofertarespuestaComplementaria.GetPropiedad("id_tarjeta_contratante")))
                    registroCRM["mcs_idtarjetatitular"] = ofertarespuestaComplementaria.GetPropiedad("id_tarjeta_contratante");

                if (!String.IsNullOrEmpty(ofertarespuestaComplementaria.GetPropiedad("id_tarjeta_asegurado")))
                    registroCRM["mcs_idtarjetaadicional"] = ofertarespuestaComplementaria.GetPropiedad("id_tarjeta_asegurado");

                if (!String.IsNullOrEmpty(ofertarespuestaComplementaria.GetPropiedad("monto_min_deuda")))
                    registroCRM["axx_montominimosd"] = Utils.FormatearStringNumericoAMoneda(ofertarespuestaComplementaria.GetPropiedad("monto_min_deuda"));
                if (!String.IsNullOrEmpty(ofertarespuestaComplementaria.GetPropiedad("prima_min")))
                    registroCRM["axx_primaminimasd"] = ofertarespuestaComplementaria.GetPropiedad("prima_min");
                if (!String.IsNullOrEmpty(ofertarespuestaComplementaria.GetPropiedad("prima_max")))
                    registroCRM["axx_primamaximasd"] = Utils.FormatearStringNumericoAMoneda(ofertarespuestaComplementaria.GetPropiedad("prima_max"));

                if (!String.IsNullOrEmpty(ofertarespuestaComplementaria.GetPropiedad("prima_min_pesos")))
                    registroCRM["axx_equivalenteminimosdd"] = new Money(decimal.Parse(ofertarespuestaComplementaria.GetPropiedad("prima_min_pesos")));

                if (!String.IsNullOrEmpty(ofertarespuestaComplementaria.GetPropiedad("prima_max_pesos")))
                    registroCRM["axx_equivalentemaximosdd"] = new Money(decimal.Parse(ofertarespuestaComplementaria.GetPropiedad("prima_max_pesos")));

                if (!String.IsNullOrEmpty(ofertarespuestaComplementaria.GetPropiedad("fecha_uf")))
                    registroCRM["axx_diaequivalencia"] = DateTime.ParseExact(ofertarespuestaComplementaria.GetPropiedad("fecha_uf"), "yyyy-MM-dd", null);

            }
            else
            {
                ctx.Trace($"CrearProductoOportunidad: -> step 5");
                var montoSolicitado = ObtenerMontoSolicitado(producto, ofertarespuesta.monto.valor);
                registroCRM["mcs_montosolicitado"] = montoSolicitado;

                //BUG 7150
                registroCRM["mcs_montoofertado"] = new Money((decimal)ofertarespuesta.monto.valor);

                //ISSUE 7250
                if (tipooferta == (int)mcs_TipodeOferta.PreAprobada)
                    registroCRM["mcs_montootorgado"] = new Money(0);
                else
                    registroCRM["mcs_montootorgado"] = montoSolicitado;

                registroCRM["mcs_numerocuenta"] = ofertarespuesta.numero_cuenta;
                registroCRM["axx_categorizacionafinidad"] = ofertarespuesta.categorizacion_afinidad;
            }
            ctx.Trace($"CrearProductoOportunidad: -> step 6");
            registroCRM["mcs_descripcion"] = ofertarespuesta.descripcion;
            registroCRM["uomid"] = listapredeterminada;
            registroCRM["mcs_ofertaid"] = ofertarespuesta.id_oferta;

            registroCRM["mcs_idactivo"] = ofertarespuesta.id_activo;
            //TASK 10295
            ctx.Trace($"CrearProductoOportunidad: -> step 6.1");
            registroCRM["productname"] = ofertarespuesta.producto;
            registroCRM["opportunityproductname"] = ofertarespuesta.producto;
            registroCRM["mcs_nombredelproducto"] = ofertarespuesta.producto != null ? ofertarespuesta.producto : producto.Name;
            if (ofertarespuesta.cupo_total_cuenta != null && ofertarespuesta.cupo_total_cuenta.valor != null)
                registroCRM["mcs_cupototal"] = new Money((decimal)ofertarespuesta.cupo_total_cuenta.valor);
            ctx.Trace($"CrearProductoOportunidad: -> step 6.2");
            //S.E.D. 24-07-2019
            if (ofertarespuesta.FechaInicio.Year > 1753)
                registroCRM["axx_fechainiciocobertura"] = ofertarespuesta.FechaInicio;
            ctx.Trace($"CrearProductoOportunidad: -> step 6.3");
            if (!String.IsNullOrEmpty(ofertarespuesta.id_producto))
            {
                ctx.Trace($"CrearProductoOportunidad: -> step 6.4");
                ctx.Trace($"CrearProductoOportunidad: -> step 6.4 -> id producto : {ofertarespuesta.id_producto}");
                var productoT = ctx.CachedEntities.GetProductByCodigo(ofertarespuesta.id_producto);
                ctx.Trace($"CrearProductoOportunidad: -> step 6.5");
                ctx.Trace($"CrearProductoOportunidad: -> step 6.5 -> {productoT?.EntityReference?.Id}");
                registroCRM["axx_productotid"] = productoT.EntityReference;
                ctx.Trace($"CrearProductoOportunidad: -> step 6.5.1");
                // Obtengo los montos del producto T
                registroCRM["axx_montominimo"] = productoT.MontoMinimo;
                ctx.Trace($"CrearProductoOportunidad: -> step 6.5.2");
                registroCRM["axx_montomximo"] = productoT.MontoMaximo;
                ctx.Trace($"CrearProductoOportunidad: -> step 6.5.3");
            }
            if (persona != null)
            {
                ctx.Trace($"CrearProductoOportunidad: -> step 6.6");
                if (persona.EstadoCivil != null)
                {
                    ctx.Trace($"CrearProductoOportunidad: -> step 6.7");
                    //El estado civil en ProdOpp es un global, pero en la persona no, por eso se instancia.
                    registroCRM["axx_estadocivil"] = persona.EstadoCivil;
                }
                ctx.Trace($"CrearProductoOportunidad: -> step 6.8");
                registroCRM["axx_primerapellidoconyugue"] = persona.ApellidoPaternoConyugue;
                registroCRM["axx_primernombreconyuge"] = persona.PrimeroNombreConyugue;
            }

            //TODO: cuando servicio devuelva los datos agregar info
            //registroCRM["axx_montominimosd"] = "monto_minimo_sd";
            //registroCRM["axx_primaminimasd"] = "pri_min";
            //registroCRM["axx_primamaximasd"] = "pri_max";



            ctx.Trace($"CrearProductoOportunidad: -> step 7");
            Guid id = default;
            try
            {
                id = ctx.Service.Create(registroCRM);

            }
            catch (Exception ex)
            {
                ctx.Trace($"CrearProductoOportunidad: -> step 8");
                ctx.Trace($"CrearProductoOportunidad: -> {ex.Message}");

            }
            ctx.Trace("Producto opp creado: " + id.ToString());
            return id;
        }

        public static Money ObtenerMontoSolicitado(Product producto, decimal? monto)
        {

            if (producto.Padre == null)
                return new Money((decimal)monto);

            ///si el productnumber es diferente a 2000 no valido nada
            if (producto.Padre.ProductNumber != ((int)CodigosProductos.Creditos).ToString())
                return new Money((decimal)monto);

            ///si es productnumber = 2000
            ///validar que el montoSolicitado no supere el montoMaximo (5'000,000.00)
            ///si es mayor devuelvo el montoMaximo
            if (monto > producto.MontoMaximo.Value)
                return producto.MontoMaximo;
            ///si no devuelvo el montoSolicitado
            return new Money((decimal)monto);

        }

        public static String VerificarCompatibilidadOportunidad(PluginContext ctx, List<Oferta> ofertas)
        {
            ctx.Trace("VerificarCompatibilidadOportunidad");
            string listErrores = String.Empty;
            EntityCollection listCompatibilidad = GetCompatibilidadProducos(ctx);
            EntityCollection listProductosCache = new EntityCollection();
            int x = 0;
            if (ofertas.Any())
            {
                // Recorro la lista de ofertas para validar
                string flagCompatibleB = String.Empty;
                foreach (var item in ofertas)
                {
                    ctx.Trace($"Oferta: {item.codigo}");
                    x = x + 1;
                    // listAux.Remove(item);
                    if (listCompatibilidad.Entities.Count > 0)
                    {
                        // Consigo el Guid de producto para comparar con la compatibilidad
                        Product productoOferta = ctx.CachedEntities.GetProductByCodigo(item.codigo);

                        string flagCompatibleA = String.Empty;

                        flagCompatibleA = productoOferta.Name;

                        for (int y = x; y < ofertas.Count; y++)
                        {

                            // Reviso si el registro de compatibilidad es para este productoOferta
                            // Recorro las ofertas para obtener las siguientes en la lista
                            // foreach (var ofertaCompatible in args.Ofertas)

                            // No valido si es el mismo producto
                            // Obtengo nombre y guid del productoOfertaActual
                            var ofertaActual = ctx.CachedEntities.GetProductByCodigo(ofertas[y].codigo);


                            flagCompatibleB = ofertaActual.Name;
                            bool flagCompatible = false;
                            foreach (var aux in listCompatibilidad.Entities)
                            {

                                // Reviso si productoOfertaActual es compatible con ProductoOferta
                                if (aux.Attributes.Contains("axx_productoid"))
                                    if (productoOferta.EntityReference.Id == ((EntityReference)aux.Attributes["axx_productoid"]).Id)
                                    {
                                        if (aux.Attributes.Contains("axx_productob"))
                                            if (ofertaActual.EntityReference.Id == ((EntityReference)aux.Attributes["axx_productob"]).Id)
                                            {
                                                // Limpio el flag y rompo el ciclo de ofertaActual
                                                // flagCompatibleA = String.Empty;
                                                flagCompatible = true;
                                                break;
                                            }
                                    }
                            }
                            if (!flagCompatible)
                                listErrores += "El producto " + flagCompatibleA + " no es compatible con el producto " + flagCompatibleB + "." + Environment.NewLine;

                            // Si el flag esta en blanco es porque se encontro compatibilidad, no sigo evaluando con este productoOferta
                            // if (String.IsNullOrEmpty(flagCompatibleA)) break;
                        }

                        // Si es distinto de Empty no es compatible y si x y count es igual es porque evaluo el ultimo item y no se toma error porque es consigo mismo
                        //if (!String.IsNullOrEmpty(flagCompatibleA) && x != args.Ofertas.Count) 
                        //    listErrores += "El producto " + flagCompatibleA + " no es compatible con el producto " + flagCompatibleB + "." + Environment.NewLine;

                    }
                    else
                    {
                        listErrores = "No se encuentra cargada la lista de compatibilidad de productos.";
                    }
                }
            }

            return listErrores;
        }

        public static String VerificarAMLOportunidad(PluginContext ctx, List<Oferta> ofertas)
        {
            int productos = 0;
            bool verificar = false;
            String resultado = null;

            foreach (var ofertaaux in ofertas)
            {
                var producto = ctx.CachedEntities.GetProductByCodigo(ofertaaux.codigo) != null ? ctx.CachedEntities.GetProductByCodigo(ofertaaux.codigo) : ctx.CachedEntities.GetProduct(ofertaaux.productId);
                if (producto == null)
                {
                    throw new InvalidPluginExecutionException("Producto no encontrado, código " + ofertaaux.codigo);
                }
                if (producto.HabilitarVerificacionAML)
                {
                    verificar = true;
                }

            }
            productos++;
            if (productos == 0)
                verificar = true;

            if (verificar)
            {
                OrganizationRequest req = new OrganizationRequest("mcs_ChequeaValidezAML");
                req["persona"] = ((EntityReference)ctx.Context.InputParameters["Target"]).Id.ToString();
                req["evento"] = "3";
                try
                {
                    OrganizationResponse aux = ctx.Service.Execute(req);
                    if (aux != null)
                    {
                        if (aux.Results["codigo"] != null && ((string)aux.Results["codigo"] == "3" || (string)aux.Results["codigo"] == "4"))
                            resultado = (string)aux.Results["resultado"];

                    }
                }
                catch (Exception ex)
                {
                    ctx.Trace("Error VerificarAMLOportunidad: " + ex.Message);
                }
            }
            return resultado;
        }

        public static EntityCollection GetCompatibilidadProducos(PluginContext ctx)
        {
            ctx.Trace("GetCompatibilidadProducos");
            string cacheKey = $"{ctx.Context.OrganizationName}///GetCompatibilidadProducos/";
            EntityCollection resultado = PluginCache.GetObject<EntityCollection>(cacheKey,
                 60 * 5,
                 () =>
                 {
                     var query = new QueryExpression("axx_compatibilidad");
                     query.NoLock = true;
                     query.ColumnSet.AddColumns("axx_productoid", "axx_productob");
                     EntityCollection result = ctx.IntegrationUserService.RetrieveMultiple(query);
                     return result;
                 }
                 );
            return resultado;
        }

        public static EntityCollection GetTelefonosCliente(PluginContext ctx, Guid clienteId)
        {
            var query = new QueryExpression("mcs_telefono");
            query.ColumnSet.AddColumns("mcs_telefonoid", "mcs_tipotelefono");
            query.Criteria.AddCondition("mcs_clienteid", ConditionOperator.Equal, clienteId);
            query.Criteria.AddCondition("mcs_principal", ConditionOperator.Equal, true);
            query.NoLock = true;

            EntityCollection result = ctx.IntegrationUserService.RetrieveMultiple(query);

            ctx.Trace($"Telefonos cliente: {result.Entities.Count}");

            return result;
        }

        public static Entity GetCicloFacturacion(PluginContext ctx, Guid productoId, DateTime fechaFencimiento)
        {
            Entity cicloFacturacion = new Entity();
            var query_mcs_fechavencimiento = fechaFencimiento;
            var query_mcs_productoid = productoId;
            var query_statecode = 0;

            var query = new QueryExpression("mcs_ciclosfacturacion");
            query.NoLock = true;
            query.ColumnSet.AddColumns("mcs_ciclosfacturacionid", "mcs_fechafacturacion", "mcs_fechavencimiento", "mcs_productoid");
            query.Criteria.AddCondition("mcs_fechavencimiento", ConditionOperator.Equal, query_mcs_fechavencimiento);
            query.Criteria.AddCondition("axx_productocat", ConditionOperator.Equal, query_mcs_productoid);
            query.Criteria.AddCondition("statecode", ConditionOperator.Equal, query_statecode);

            EntityCollection result = ctx.IntegrationUserService.RetrieveMultiple(query);

            if (result.Entities.Count > 0)
            {
                cicloFacturacion = result.Entities[0];
            }

            ctx.Trace($"Ciclo Facturacion Guid: {cicloFacturacion.Id.ToString()}");
            return cicloFacturacion;
        }


        public static Entity GetClienteAdicionalApolo(PluginContext ctx, string clienteId)
        {
            Entity adicional = new Entity("account");
            var query = new QueryExpression("account");
            query.ColumnSet.AddColumns(
                         "accountid",
                         "accountnumber",
                         "mcs_numeroidentificacion",
                         "mcs_tipodocumentoid",
                         "mcs_paisemisionid",
                         "name",
                         "mcs_primernombre",
                         "mcs_segundonombre",
                         "mcs_apellidomaterno",
                         "mcs_apellidopaterno",
                         "mcs_nacionalidadid",
                         "mcs_permanencia",
                         "mcs_fechanacimiento",
                         "mcs_estadocivil",
                         "mcs_poseecorreoelectronico",
                         "mcs_inscritopuntos",
                         "axx_idcliente",
                         "customertypecode");
            query.Criteria.AddCondition("axx_idcliente", ConditionOperator.Equal, clienteId);
            query.NoLock = true;

            EntityCollection result = ctx.IntegrationUserService.RetrieveMultiple(query);

            if (result.Entities.Count > 0)
            {
                adicional = result.Entities[0];
            }

            ctx.Trace($"Adicional Guid: {adicional.Id.ToString()}");

            return adicional;
        }

        public static Guid BuscarGestionesTelefonicasCliente(PluginContext ctx, Guid clienteid, Guid productocat)
        {

            Guid guidGestionEncontrada = Guid.Empty;

            var tz = TimeZoneInfo.FindSystemTimeZoneById("Pacific SA Standard Time");
            if (tz.IsInvalidTime(DateTime.Now))
            {
                tz = TimeZoneInfo.FindSystemTimeZoneById("E. South America Standard Time");
            }
            var now = TimeZoneInfo.ConvertTime(DateTime.Now, tz);


            var query_statecode_1 = StateCodeGestionTelefonica.Completado;
            var query_statecode_2 = StateCodeGestionTelefonica.Cancelado;
            var fechaactual = now.ToString("dd/MM/yyyy");
            var query_statuscode_1 = StatusCodeGestionTelefonica.Vencido;
            var query_statuscode_2 = StatusCodeGestionTelefonica.Cerrado;
            var query_statuscode_3 = StatusCodeGestionTelefonica.Cerrada;
            var query_statuscode_4 = StatusCodeGestionTelefonica.Cancelado;
            var query_mcs_persona = clienteid;
            ctx.Trace("BuscarGestionesTelefonicasCliente: cliente: " + clienteid.ToString() + " - Fecha: " + fechaactual);
            var query = new QueryExpression("mcs_gestionejecutivo");
            query.ColumnSet.AddColumns(
                "activityid",
                "subject",
                "createdon",
                "statecode",
                "mcs_resolucion",
                "mcs_resolucionsingestion",
                "mcs_resolucionengestion",
                "mcs_resolucioncerrado",
                "axx_fechatermino",
                "scheduledstart");
            query.Criteria.AddCondition("statecode", ConditionOperator.NotIn, query_statecode_1, query_statecode_2);
            var query_And = new FilterExpression();
            query_And.AddCondition("scheduledstart", ConditionOperator.OnOrBefore, fechaactual);
            query_And.AddCondition("axx_fechatermino", ConditionOperator.OnOrAfter, fechaactual);
            query.Criteria.AddCondition("axx_productocat", ConditionOperator.Equal, productocat);
            query.Criteria.AddCondition("statuscode", ConditionOperator.NotIn, query_statuscode_1, query_statuscode_2, query_statuscode_3, query_statuscode_4);
            query.Criteria.AddCondition("mcs_persona", ConditionOperator.Equal, query_mcs_persona);
            query.AddOrder("subject", OrderType.Ascending);

            EntityCollection gestionesEncontradas = ctx.Service.RetrieveMultiple(query);
            ctx.Trace("gestionesEncontradas: " + gestionesEncontradas.Entities.Count());
            if (gestionesEncontradas.Entities.Count() > 0)
            {

                guidGestionEncontrada = gestionesEncontradas[0].Id;
            }
            return guidGestionEncontrada;
        }

        public static void PasarANegociacion(PluginContext ctx, Guid idOportunidad, string canal)
        {
            ctx.Trace("PasarANegociacion");
            var proceso = Utils.RecuperarProcesoGenerarOportunidad(idOportunidad, ctx);

            if (proceso != null)
            {
                var fase = ctx.CachedEntities.GetProcessStage(proceso.GetAttributeValue<EntityReference>("processid").Id, canal == "120" ? "Negociación Canal Espacio Financiero" : "Negociación");
                if (fase != null)
                {
                    var traversedPath = (proceso["traversedpath"] ?? "").ToString();
                    traversedPath += ((traversedPath.Length > 0) ? "," : "") + fase.Id.ToString().Replace("{", "").Replace("}", "");

                    proceso["activestageid"] = new EntityReference(fase.LogicalName, fase.Id);
                    proceso["traversedpath"] = traversedPath;

                    ctx.Service.Update(proceso);
                }
            }


        }
    }
}