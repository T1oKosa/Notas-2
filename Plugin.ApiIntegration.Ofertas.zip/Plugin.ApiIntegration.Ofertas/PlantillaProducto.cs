﻿extern alias GComponents;

using GComponents::Axxon.GlobalComponents;
using GComponents::Axxon.GlobalComponents.Configuraciones;
using GComponents::Axxon.GlobalComponents.Helper;
using GComponents::Axxon.GlobalComponents.Model;
using GComponents::Axxon.GlobalComponents.Model.Sesion;
using Microsoft.Xrm.Sdk;
using Plugin.ApiIntegration.Ofertas.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.Remoting.Contexts;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk.Query;

namespace Plugin.ApiIntegration.Ofertas
{
    public class PlantillaProducto : PluginApiIntegrationBase
    {

        #region Secure/Unsecure Configuration Setup
        private string _secureConfig = null;
        private string _unsecureConfig = null;
        private ConfiguracionServicio configuracion = null;
        public PlantillaProducto(string unsecureConfig, string secureConfig)
        {
            _secureConfig = secureConfig;
            _unsecureConfig = unsecureConfig;
        }
        public PlantillaProducto()
        {

        }
        #endregion

        private static readonly AsyncLocal<string> _currentUrlProducto = new AsyncLocal<string>();
        public override ConfiguracionServicio GetServicio(PluginContext ctx, ConfiguracionesServicios configuraciones)
        {
            ctx.TracingService.Trace($"ConfiguracionServicio");
            string urlproducto = (string)ctx.Context.InputParameters["Api_ApiIntegration_Ofertas_PlantillaProducto_In_UrlProducto"];
            _currentUrlProducto.Value = urlproducto;
            ctx.TracingService.Trace($"ConfiguracionServicio -> urlproducto -> {urlproducto}");
            string idcliente = (string)ctx.Context.InputParameters["Api_ApiIntegration_Ofertas_PlantillaProducto_In_IdCliente"];
            ctx.TracingService.Trace($"ConfiguracionServicio -> idcliente -> {idcliente}");
            string configuracionIn = (string)ctx.Context.InputParameters["Api_ApiIntegration_Ofertas_PlantillaProducto_In_Configuracion"];
            ctx.TracingService.Trace($"ConfiguracionServicio -> configuracion -> {configuracionIn}");
            configuracion = configuraciones.ServiciosOfertador.Where(u => u.Servicio.Equals(configuracionIn)).FirstOrDefault();
            urlproducto = urlproducto.Contains("{clienteid}") ? urlproducto.Replace("{clienteid}", idcliente) : urlproducto;
            _currentUrlProducto.Value = urlproducto;
            if (urlproducto.Contains("ofertas-sae"))
            {
                var conf = configuraciones.OfertaSAE;
                conf.Url = urlproducto;
                return conf;
            }
            if (urlproducto.Contains("ofertas-ae"))
            {
                var conf = configuraciones.OfertaAE;
                conf.Url = urlproducto;
                return conf;
            }
            if (urlproducto.Contains("ofertas-aumento-cupo"))
            {
                return configuraciones.OfertaAumentoCupo;
            }

            if (urlproducto.Contains("ofertas-tarjeta/traspaso"))
            {
                ctx.TracingService.Trace("Servicio: Ofertas Tarjeta/Traspaso");
                return configuraciones.ServicioOfertaUpgrade;
            }

            if (urlproducto.Contains("ofertas-tarjeta"))
            {
                if (urlproducto.Contains("adicionales-validas"))
                {
                    ctx.TracingService.Trace("ingreso ofertas adicionales-validas");
                    return configuraciones.OfertaAdicional;
                }
                else
                {
                    return configuraciones.OfertaTarjeta;
                }
            }

            if (urlproducto.Contains("v2.0/rdr/ofertas"))
            {
                ctx.Trace("url: RDR " + urlproducto);
                ctx.TracingService.Trace("ingreso ofertas ofertas-rdr");
                var _configuraciones = configuraciones.ServicioOfertasRDR;
                _configuraciones.Url = _configuraciones.Url.Contains("{clienteid}") ? _configuraciones.Url.Replace("{clienteid}", idcliente) : _configuraciones.Url;
                return _configuraciones;
            }
            if (urlproducto.Contains("v2.0/rdr/status-curse-repactacion"))
            {
                ctx.Trace("url: RDR " + urlproducto);
                ctx.TracingService.Trace("ingreso EstadoCurseRepactacionRdr");
                var _configuraciones = configuraciones.UrlEstadoCurseRepactacionRdr;
                // _configuraciones.Url = _configuraciones.Url.Contains("{clienteid}") ? _configuraciones.Url.Replace("{clienteid}", idcliente) : _configuraciones.Url;
                return _configuraciones;
            }
            if (urlproducto.Contains("v2.0/rdr/status-curse-renegociacion"))
            {
                ctx.Trace("url: RDR " + urlproducto);
                ctx.TracingService.Trace("ingreso EstadoCurseRenegociacionRdr");
                var _configuraciones = configuraciones.UrlEstadoCurseRenegociacionRdr;
                // _configuraciones.Url = _configuraciones.Url.Contains("{clienteid}") ? _configuraciones.Url.Replace("{clienteid}", idcliente) : _configuraciones.Url;
                return _configuraciones;
            }

            if (urlproducto.Contains("/ofertas-complementarias/cesa-hosp"))
            {
                var _configuraciones = configuraciones.ServicioPorNombre("UrlOfertasComplementariasCesaHosp");
                _configuraciones.Url = _configuraciones.Url.Replace("{clienteid}", idcliente);
                return _configuraciones;
            }

            if (urlproducto.Contains("ofertas-complementarias"))
            {
                var _configuraciones = configuraciones.ServicioObtenerOfertasComplementarias;
                string numero_documento = (string)ctx.Context.InputParameters["Api_ApiIntegration_Ofertas_PlantillaProducto_In_NDocumento"];
                _configuraciones.Url = _configuraciones.Url.Replace("{numero_documento}", idcliente).Replace("{tipo_documento}", "1").Replace("{pais}", "CHL").Replace("{pagina}", "0").Replace("{maximo}", "500");
                return _configuraciones;
            }
            if (urlproducto.Contains("ofertas?tipo_documento"))
            {
                ctx.TracingService.Trace("ingreso ofertas complementarias");
                string guidCliente = (string)ctx.Context.InputParameters["Api_ApiIntegration_Ofertas_PlantillaProducto_In_GuidCliente"];
                ctx.TracingService.Trace("ingreso ofertas complementarias -> id de cliente " + guidCliente);
                var cliente = ctx.CachedEntities.GetClient(Guid.Parse(guidCliente));

                ctx.TracingService.Trace($"ingreso ofertas complementarias -> {cliente}");
                var _configuraciones = configuraciones.ServicioObtenerOfertasTraspaso;
                _configuraciones.Url = _configuraciones.Url.Replace("{numero_documento}", idcliente);
                _configuraciones.Url = _configuraciones.Url.Replace("{tipo_documento}", cliente.TipoDoc.Codigo);
                _configuraciones.Url = _configuraciones.Url.Replace("{pais}", cliente.Pais.Codigo);
                _configuraciones.Url = _configuraciones.Url.Replace("{pagina}", "0");
                _configuraciones.Url = _configuraciones.Url.Replace("{maximo}", "5000");
                ctx.TracingService.Trace($"ConfiguracionServicio -> _configuraciones.Url -> {_configuraciones.Url}");
                return _configuraciones;

            }

            if (urlproducto.Contains("/v2.0/ofertas"))
            {
                var conf = configuraciones.ServicioObtenerOfertasComplementariasV2;
                conf.Url = urlproducto;
                return conf;
            }

            if (urlproducto.Contains("charlestaylor"))
            {
                var conf = configuraciones.UrlOfertaAutomotriz;
                conf.Url = conf.Url.Contains("{clienteid}") ? conf.Url.Replace("{clienteid}", idcliente) : conf.Url; ;
                return conf;
            }

            ctx.TracingService.Trace("Return Null");
            return null;
        }
        public override bool ValidarSesion()
        {
            return false;
        }
        public override string GetHttpMethod()
        {
            string urlproducto = _currentUrlProducto.Value;
            return urlproducto != null && urlproducto.Contains("charlestaylor") ? "POST" : "GET";
        }
        public override WebHeaderCollection GetHeader(PluginContext ctx)
        {
            ctx.TracingService.Trace($"WebHeaderCollection");
            string idcliente = (string)ctx.Context.InputParameters["Api_ApiIntegration_Ofertas_PlantillaProducto_In_IdCliente"];
            string urlproducto = (string)ctx.Context.InputParameters["Api_ApiIntegration_Ofertas_PlantillaProducto_In_UrlProducto"];
            WebHeaderCollection wh = new WebHeaderCollection();
            if (urlproducto.Contains("ofertas-aumento-cupo"))
            {
                wh.Add("apikey", "3t4RDzeYOCkrVmr88U5X3PSkdmHNMdmf");
                wh.Add("id-cliente", idcliente);
            }
            if (urlproducto.Contains("ofertas-tarjeta/traspaso"))
            {
                wh.Add("mora-days", "0");
            }

            if (urlproducto.Contains("ofertas-tarjeta"))
            {
                wh.Add("id-cliente", idcliente);
            }
            if (urlproducto.Contains("adicionales-validas"))
            {
                ctx.TracingService.Trace("ingreso header adicionales-validad", idcliente);
                wh.Add("mora-days", "0");
            }
            if (urlproducto.Contains("ofertas?tipo_documento"))
            {
                string guidCliente = (string)ctx.Context.InputParameters["Api_ApiIntegration_Ofertas_PlantillaProducto_In_GuidCliente"];
                string Idproducto = (string)ctx.Context.InputParameters["Api_ApiIntegration_Ofertas_PlantillaProducto_In_Idproducto"];
                User usuario = ctx.CachedEntities.GetUser(ctx.Context.InitiatingUserId);
                Sesion sesion = Sesion.GetActive(ctx, usuario.Id, Guid.Parse(guidCliente));
                var producto = ctx.CachedEntities.GetProduct(new Guid(Idproducto));
                ctx.TracingService.Trace($"WebHeaderCollection -> x-sesion-id -> {sesion.Id}");
                //wh.Add("x-sesion-id", sesion.Id.ToString());
                //Si es traspaso, set enduro = 3000 por definicion de ms
                wh.Add("codigo-producto", "3000");
            }

            if (urlproducto.Contains("v2.0/ofertas"))
            {
                ctx.TracingService.Trace("ingreso header ofertas complementarias v2", idcliente);
                User usuario = ctx.CachedEntities.GetUser(ctx.Context.InitiatingUserId);
                wh.Add("id-cliente", idcliente);
                wh.Add("id-sucursal", usuario.Canal.Codigo);
            }
            return wh;
        }
        public override String ProcesarJson(PluginContext ctx, String json)
        {
            ctx.Trace("Inicio ProcesarJson");
            string urlER = (string)ctx.Context.InputParameters["Api_ApiIntegration_Ofertas_PlantillaProducto_In_UrlER"];
            string urlproducto = (string)ctx.Context.InputParameters["Api_ApiIntegration_Ofertas_PlantillaProducto_In_UrlProducto"];
            string Idproducto = (string)ctx.Context.InputParameters["Api_ApiIntegration_Ofertas_PlantillaProducto_In_Idproducto"];

            ctx.Trace($"IdProducto -> {Idproducto}");

            List<Plantilla> _lista = new List<Plantilla>();
            Producto _producto = Service.CRMQueries.GetProducto(ctx, Guid.Parse(Idproducto));
            _producto.ER = urlER;
            _producto.Orden = configuracion?.Orden != null ? configuracion.Orden.Value : _producto.Orden;
            _producto.Simulable = _producto.Selecionable ? _producto.Simulable : false;

            ctx.Trace("urlproducto: " + urlproducto);

            if (urlproducto.Contains("ofertas-sae"))
            {
                try
                {
                    ctx.Trace($"ofertas-sae");
                    var _ofertaSAE = JsonSerializer.Deserialize<OfertaSAE>(json);
                    ctx.Trace($"ofertas-sae - data: " + _ofertaSAE.data.Count.ToString());
                    if (_ofertaSAE.data.Count > 0)
                    {
                        ctx.Trace($"ofertas-sae - getproducto");
                        string guidCliente = (string)ctx.Context.InputParameters["Api_ApiIntegration_Ofertas_PlantillaProducto_In_GuidCliente"];
                        Client cliente = ctx.CachedEntities.GetClient(Guid.Parse(guidCliente));
                        ctx.Trace($"ofertas-sae - getproducto - rut cliente: {cliente.NumeroIdentificacion}");
                        return JsonSerializer.Serialize(_ofertaSAE.GetProductoOfertaEspecial(_producto, cliente.NumeroIdentificacion, ctx));
                    }
                    else
                    {
                        return JsonSerializer.Serialize(_lista);
                    }
                }
                catch (Exception ex)
                {
                    ctx.Trace($"error-sae: " + ex.Message);
                    ctx.Context.OutputParameters["Error"] = ex.Message;
                    return null;
                }
            }

            if (urlproducto.Contains("v2.0/rdr/ofertas"))
            {
                try
                {
                    ctx.Trace("ofertas-rdr");
                    if (!string.IsNullOrEmpty(json))
                    {
                        //ctx.Trace("json:" + json);
                        if (json != "")
                        {
                            var _ofertaTarjeta = JsonSerializer.Deserialize<OfertaRDR>(json);
                            if (_ofertaTarjeta.data != null)
                            {
                                ctx.Trace("_producto: " + _producto.Codigo);
                                string guidCliente = (string)ctx.Context.InputParameters["Api_ApiIntegration_Ofertas_PlantillaProducto_In_GuidCliente"];
                                Client cliente = ctx.CachedEntities.GetClient(Guid.Parse(guidCliente));
                                ctx.Trace($"ofertas-rdr - getproducto - rut cliente: {cliente.NumeroIdentificacion}");
                                return JsonSerializer.Serialize(_ofertaTarjeta.GetProductoOfertaEspecial(_producto, cliente.NumeroIdentificacion, ctx));
                            }
                            else
                            {
                                return JsonSerializer.Serialize(_lista);
                            }
                        }
                    }


                }
                catch (Exception ex)
                {
                    ctx.Trace($"ofertas-rdr - error - Ex: {ex.Message}");
                    ctx.Context.OutputParameters["Error"] = ex.Message;
                    return null;
                }
            }

            if (urlproducto.Contains("ofertas-ae"))
            {
                ctx.Trace($"ofertas-ae");
                try
                {
                    var _ofertaAE = JsonSerializer.Deserialize<OfertaAE>(json);
                    if (_ofertaAE.data.Count > 0)
                    {
                        ctx.Trace($"ofertas-ae - count - {_ofertaAE.data.Count}");
                        return JsonSerializer.Serialize(_ofertaAE.GetProducto(_producto, ctx));
                    }
                    else
                    {
                        return JsonSerializer.Serialize(_lista);
                    }
                }
                catch (Exception ex)
                {
                    ctx.Trace($"ofertas-ae - error - {ex.Message}");
                    ctx.Context.OutputParameters["Error"] = ex.Message;
                    return null;
                }
            }
            if (urlproducto.Contains("ofertas-aumento-cupo"))
            {
                ctx.Trace($"ofertas-aumento-cupo");
                try
                {
                    ctx.Trace($"ofertas-aumento-cupo json: {json}");
                    var _ofertaAumentoCupo = JsonSerializer.Deserialize<OfertaAumentoCupo>(json);
                    if (_ofertaAumentoCupo.data.ofertas.Count > 0)
                    {
                        ctx.Trace($"retorna _ofertaAumentoCupo");
                        return JsonSerializer.Serialize(_ofertaAumentoCupo.GetProducto(_producto, ctx));
                    }
                    else
                    {
                        ctx.Trace($"retorna _lista");
                        return JsonSerializer.Serialize(_lista);
                    }
                }
                catch (Exception ex)
                {
                    ctx.Trace($"ofertas-aumento-cupo - error - {ex.Message}");
                    ctx.Context.OutputParameters["Error"] = ex.Message;
                    return null;
                }
            }
            if (urlproducto.Contains("ofertas-tarjeta/traspaso"))
            {
                try
                {
                    var _ofertaTarjeta = JsonSerializer.Deserialize<OfertaUpgrade>(json);
                    if (_ofertaTarjeta.data.Count > 0)
                    {
                        ctx.Trace("ofertas-tarjeta/traspaso");
                        ctx.Trace($"ofertas-tarjeta/traspaso - Cantidad de registros: {_ofertaTarjeta.data.Count}");
                        return JsonSerializer.Serialize(_ofertaTarjeta.GetProducto(_producto, ctx));
                    }
                    else
                    {
                        return JsonSerializer.Serialize(_lista);
                    }
                }
                catch (Exception ex)
                {
                    ctx.Trace($"ofertas-tarjeta - error - Ex: {ex.Message}");
                    ctx.Context.OutputParameters["Error"] = ex.Message;
                    return null;
                }
            }


            if (urlproducto.Contains("ofertas-tarjeta"))
            {
                try
                {
                    if (urlproducto.Contains("adicionales-validas"))
                    {
                        var _ofertaAdicional = JsonSerializer.Deserialize<OfertasAdicionales>(json);
                        if (_ofertaAdicional.data.Count > 0)
                        {
                            ctx.Trace("ofertas adicionales-validas");
                            ctx.Trace($"ofertas-adicionales-validas- Cantidad de registros: {_ofertaAdicional.data.Count}");
                            return JsonSerializer.Serialize(_ofertaAdicional.GetProducto(_producto, ctx));
                        }
                        else
                        {
                            return JsonSerializer.Serialize(_lista);
                        }
                    }
                    else
                    {
                        ctx.Trace($"_producto: {JsonSerializer.Serialize(_producto)}");
                        ctx.Trace($"json: {json}");
                        var _ofertaTarjeta = JsonSerializer.Deserialize<OfertaTarjeta>(json);
                        ctx.Trace($"_ofertaTarjeta:");
                        foreach (var itemOferta in _ofertaTarjeta.data.ofertas)
                        {
                            ctx.Trace($"Entra en for para seteo de grupo");
                            itemOferta.id_grupo_servicio = itemOferta.id_grupo;
                        }

                        ctx.Trace($"_ofertaTarjeta: {JsonSerializer.Serialize(_ofertaTarjeta)}");

                        if (_ofertaTarjeta.data.ofertas.Count > 0)
                        {
                            ctx.Trace("ofertas-tarjeta");
                            ctx.Trace($"ofertas-tarjeta - Cantidad de registros: {_ofertaTarjeta.data.ofertas.Count}");
                            return JsonSerializer.Serialize(_ofertaTarjeta.GetProducto(_producto, ctx));
                        }
                        else
                        {
                            return JsonSerializer.Serialize(_lista);
                        }
                    }
                }
                catch (Exception ex)
                {
                    ctx.Trace($"ofertas-tarjeta - error - Ex: {ex.Message}");
                    ctx.Context.OutputParameters["Error"] = ex.Message;
                    return null;
                }
            }
            if (urlproducto.Contains("/cesa-hosp"))
            {
                try
                {
                    ctx.TracingService.Trace("Ofertas-cesa-hosp");
                    ctx.Trace(json);
                    var _ofertaCesaHosp = JsonSerializer.Deserialize<OfertasComplementariaCesaHosp>(json);
                    if (_ofertaCesaHosp.data.Count > 0)
                    {
                        return JsonSerializer.Serialize(_ofertaCesaHosp.GetProducto(_producto, ctx));
                    }
                    else
                    {
                        return JsonSerializer.Serialize(_lista);
                    }
                }
                catch (Exception ex)
                {
                    ctx.Context.OutputParameters["Error"] = ex.Message;
                    return null;
                }
            }

            if (urlproducto.Contains("ofertas-complementarias"))
            {
                try
                {
                    var _ofertacomplementarias = JsonSerializer.Deserialize<OfertasComplementaria>(json);
                    if (_ofertacomplementarias.data.Count > 0)
                    {
                        return JsonSerializer.Serialize(_ofertacomplementarias.GetProducto(_producto, ctx));
                    }
                    else
                    {
                        return JsonSerializer.Serialize(_lista);
                    }
                }
                catch (Exception ex)
                {
                    ctx.Context.OutputParameters["Error"] = ex.Message;
                    return null;
                }
            }
            if (urlproducto.Contains("ofertas?tipo_documento"))
            {
                try
                {
                    ctx.TracingService.Trace("Ofertas-Traspaso");
                    var _ofertaTraspaso = JsonSerializer.Deserialize<OfertaTraspaso>(json);
                    ctx.TracingService.Trace($"Ofertas-Traspaso - count - {_ofertaTraspaso.contenido.Count}");
                    //'2020-01-01T00:00:00Z'

                    if (_ofertaTraspaso.contenido.Count > 0)
                    {
                        ctx.TracingService.Trace($"Ofertas complementarias step 2.1 ->", _ofertaTraspaso.contenido.Count);
                        return JsonSerializer.Serialize(_ofertaTraspaso.GetProducto(_producto, ctx));
                    }
                    else
                    {
                        return JsonSerializer.Serialize(_lista);
                    }
                }
                catch (Exception ex)
                {
                    ctx.TracingService.Trace($"Ofertas-Traspaso - Error: - {ex.Message}");
                    ctx.Context.OutputParameters["Error"] = ex.Message;
                    return null;
                }
            }

            if (urlproducto.Contains("v2.0/ofertas"))
            {
                try
                {
                    ctx.Trace($"v2.0/ofertas ofertas complementarias v2");
                    ctx.Trace(json);
                    var _ofertaComplementaria = JsonSerializer.Deserialize<OfertasCreditoComplementaria>(json);
                    ctx.Trace($"ofertas complementarias v - data: " + _ofertaComplementaria.data.Count.ToString());
                    if (_ofertaComplementaria.data.Count > 0)
                    {
                        ctx.Trace($"ofertas complementarias v2 - getproducto");
                        return JsonSerializer.Serialize(_ofertaComplementaria.GetProducto(_producto, ctx));
                    }
                    else
                    {
                        return JsonSerializer.Serialize(_lista);
                    }
                }
                catch (Exception ex)
                {
                    ctx.Trace($"error-ofertas complementarias v2 : " + ex.Message);
                    ctx.Context.OutputParameters["Error"] = ex.Message;
                    return null;
                }
            }

            if (urlproducto.Contains("charlestaylor"))
            {
                try
                {
                    string guidCliente = (string)ctx.Context.InputParameters["Api_ApiIntegration_Ofertas_PlantillaProducto_In_GuidCliente"];
                    Client cliente = ctx.CachedEntities.GetClient(Guid.Parse(guidCliente));
                    User usuario = ctx.CachedEntities.GetUser(ctx.Context.InitiatingUserId);

                    Guid? sucursalId = usuario?.Sucursal?.EntityReference?.Id;

                    if (string.IsNullOrWhiteSpace(json))
                    {
                        ctx.Trace("charlestaylor - respuesta vacia o nula");
                        return JsonSerializer.Serialize(new List<Plantilla>());
                    }

                    var ofertaAutomotriz = JsonSerializer.Deserialize<OfertaAutomotriz>(json);

                    if (ofertaAutomotriz == null)
                    {
                        ctx.Trace("charlestaylor - deserialize retorno null");
                        return JsonSerializer.Serialize(new List<Plantilla>());
                    }

                    bool habilitadoAutomotriz = ofertaAutomotriz.HabilitadoOfertaAutomotriz(ctx, cliente.Id, sucursalId);
                    if (!habilitadoAutomotriz)
                    {
                        ctx.Trace("charlestaylor - no habilitado para persona/sucursal, se retorna card deshabilitada");
                    }
                    if (ofertaAutomotriz?.data != null)
                    {
                        ctx.Trace("charlestaylor - Se obtuvieron datos desde charles taylor");
                        return JsonSerializer.Serialize(ofertaAutomotriz.GetProducto(_producto, ctx, habilitadoAutomotriz));
                    }

                    return JsonSerializer.Serialize(new List<Plantilla>());
                }
                catch (Exception ex)
                {
                    ctx.Context.OutputParameters["Error"] = ex.Message;
                    return null;
                }
            }

            return string.Empty;
        }
        public override string ProcesarJsonError(PluginContext ctx, Error error)
        {
            string urlproducto = (string)ctx.Context.InputParameters["Api_ApiIntegration_Ofertas_PlantillaProducto_In_UrlProducto"];
            ResponseError responseError = JsonSerializer.Deserialize<ResponseError>(error.mensaje);

            if (urlproducto.Contains("/cesa-hosp") && responseError.status == 412)
            {
                ctx.TracingService.Trace("Error-cesa-hosp");
                var _ofertaCesaHosp = new OfertasComplementariaCesaHosp();

                ctx.Trace(JsonSerializer.Serialize(_ofertaCesaHosp.GetProductoSinActividad(ctx)));
                ctx.Context.OutputParameters["Response"] = JsonSerializer.Serialize(_ofertaCesaHosp.GetProductoSinActividad(ctx));
                return null;
            }

            return error.mensaje;
        }
        public override string EjecutarValidaciones(PluginContext ctx, Sesion sesion)
        {
            ctx.TracingService.Trace($"EjecutarValidaciones");
            string urlproducto = (string)ctx.Context.InputParameters["Api_ApiIntegration_Ofertas_PlantillaProducto_In_UrlProducto"];
            String msg = null;
            if (urlproducto.Contains("ofertas?tipo_documento"))
            {
                ctx.TracingService.Trace($"Ofertas complementarias step 3 ->");
                string guidCliente = (string)ctx.Context.InputParameters["Api_ApiIntegration_Ofertas_PlantillaProducto_In_GuidCliente"];
                var ejecutivo = ctx.CachedEntities.GetUser(ctx.Context.InitiatingUserId);
                var cliente = ctx.CachedEntities.GetClient(Guid.Parse(guidCliente));
                if (cliente.Permanencia == null
                   || cliente.Nacionalidad == null
                   || cliente.FechaNacimiento.Year <= 1753 || ejecutivo.RolPrimario == null)
                {
                    StringBuilder sb = new StringBuilder();
                    sb.Append("No cuenta con los datos mínimos para ver ofertas: ");
                    sb.Append(cliente.Permanencia == null ? "Permanencia, " : "");
                    sb.Append(cliente.Nacionalidad == null ? "Nacionalidad, " : "");
                    sb.Append(cliente.FechaNacimiento.Year <= 1753 ? "Fecha de nacimiento, " : "");
                    sb.Append(ejecutivo.RolPrimario == null ? "Rol principal, " : "");
                    msg = sb.ToString();
                    msg = msg.Substring(0, msg.Length - 2);
                    ctx.TracingService.Trace($"Ofertas complementarias step 3.1 ->", msg);
                }
            }
            ctx.TracingService.Trace($"Ofertas complementarias step 3.2 ->", msg);
            return msg;
        }
        public override String GetDato(PluginContext ctx)
        {
            ctx.TracingService.Trace($"GetDato");
            string urlproducto = (string)ctx.Context.InputParameters["Api_ApiIntegration_Ofertas_PlantillaProducto_In_UrlProducto"];
            String dato = null;
            if (urlproducto.Contains("ofertas?tipo_documento"))
            {
                dato = base.GetDato(ctx);
                ctx.TracingService.Trace($"Ofertas complementarias step 4 ->", dato);
            }

            if (urlproducto.Contains("charlestaylor"))
            {
                string clientId = (string)ctx.Context.InputParameters["Api_ApiIntegration_Ofertas_PlantillaProducto_In_IdCliente"];
                User ejecutivo = ctx.CachedEntities.GetUser(ctx.Context.InitiatingUserId);
                Entity ejecutivoEntity = ctx.Service.Retrieve("systemuser", ctx.Context.InitiatingUserId, new ColumnSet("firstname", "lastname"));

                string nombreEjecutivo = ejecutivoEntity.Contains("firstname") ? ejecutivoEntity["firstname"].ToString() : "";
                string apellidoEjecutivo = ejecutivoEntity.Contains("lastname") ? ejecutivoEntity["lastname"].ToString() : "";
                string correoEjecutivo = ejecutivo?.DomainName;

                Sucursal sucursal = ejecutivo?.Sucursal;
                string codSucursal = sucursal?.Codigo;
                string nombreSucursal = sucursal?.Name;

                if (sucursal == null)
                {
                    ctx.TracingService.Trace("charlestaylor GetDato -> ejecutivo sin sucursal, se envian datos de sucursal vacios");
                }

                RequestSesionCharlesTaylor requestAutomotriz = new RequestSesionCharlesTaylor
                {
                    nombreEjecutivo = nombreEjecutivo ?? string.Empty,
                    apellidoEjecutivo = apellidoEjecutivo ?? string.Empty,
                    correoEjecutivo = correoEjecutivo ?? string.Empty,
                    clientId = clientId ?? string.Empty,
                    codSucursal = codSucursal ?? string.Empty,
                    nombreSucursal = nombreSucursal ?? string.Empty
                };

                dato = JsonSerializer.Serialize(requestAutomotriz);
                ctx.TracingService.Trace($"charlestaylor GetDato -> {dato}");
            }

            return dato;
        }

    }
}